# HAIT - Hệ Thống Quản Lý Giám Sát Nhiễm Khuẩn Bệnh Viện

<b>CHUNG:</b><br>
Tên thư mục viết thường.<br>
Tên File:<br>
  Tên view: ViewLogin.php<br>
  Tên Controller: ControllerLogin.php<br>
  Tên Model: ModalLogin.php<br>
QUY TẮC ĐĂT TÊN:<br>
- Thẻ: Tên thẻ + Tên<br>
  VD: InputLogin<br>
- ID = Name<br>
CẤU TRÚC THƯ MỤC<br>
FONTEND:<br>
Đặt hoàn toàn trong /public<br>
-CSS<br>
-JS<br>
-FONT<br>
BACKEND: /APPLICATION<br>
