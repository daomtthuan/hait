<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class User extends MY_Controller {

	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$data['role'] = 'user';
		$data['page_title'] = 'Trang chủ';

		$data['main']= 'user/home';
		$data['script'] = '';

		$this->load->view('general/layout',$data);
	}

	public function new_form($step)
	{
		if ($step == '7-1') $step = "7_1";
		else if ($step == '7-2') $step = "7_2";

		$data['role'] = 'user';
		$data['page_title'] = 'Tạo mới biểu mẫu - Bước '.(($step == '7_1' || $step == '7_2' ) ? '7' : $step);

		$data['main'] = 'tools/form/step'.$step;

		$this->load->view('general/layout',$data);
	}



	//  TODO làm lại controller edit_form
/*
	public function edit_form($form_id)
	{
		$data['role'] = 'user';
		$data['page_title'] = 'Chỉnh sửa biểu mẫu';

		$data['main'] = 'tools/form';
		$data['script'] =
			'<script>var json = "'.base_url('ajax/get/'.$form_id).'"</script>'.
			'<script src="'.base_url('public/js/tools/edit_form.js').'"></script>';

		$this->load->view('general/layout',$data);
	}
	*/

	public function list_form()
	{
		$data['role'] = 'user';
		$data['page_title'] = 'Danh sách biểu mẫu';

		$data['main'] = 'tools/list_form';

		$this->load->view('general/layout',$data);
	}

}
