<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-08-31 09:27:58 --> Config Class Initialized
INFO - 2019-08-31 09:27:58 --> Hooks Class Initialized
DEBUG - 2019-08-31 09:27:58 --> UTF-8 Support Enabled
INFO - 2019-08-31 09:27:58 --> Utf8 Class Initialized
INFO - 2019-08-31 09:27:58 --> URI Class Initialized
DEBUG - 2019-08-31 09:27:58 --> No URI present. Default controller set.
INFO - 2019-08-31 09:27:58 --> Router Class Initialized
INFO - 2019-08-31 09:27:58 --> Output Class Initialized
INFO - 2019-08-31 09:27:58 --> Security Class Initialized
DEBUG - 2019-08-31 09:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 09:27:58 --> Input Class Initialized
INFO - 2019-08-31 09:27:58 --> Language Class Initialized
INFO - 2019-08-31 09:27:58 --> Loader Class Initialized
INFO - 2019-08-31 09:27:59 --> Helper loaded: url_helper
INFO - 2019-08-31 09:27:59 --> Database Driver Class Initialized
DEBUG - 2019-08-31 09:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 09:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 09:28:00 --> Controller Class Initialized
DEBUG - 2019-08-31 09:28:00 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/ion_auth.php
INFO - 2019-08-31 09:28:00 --> Email Class Initialized
INFO - 2019-08-31 09:28:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-08-31 09:28:00 --> Helper loaded: cookie_helper
INFO - 2019-08-31 09:28:00 --> Helper loaded: language_helper
DEBUG - 2019-08-31 09:28:00 --> Session class already loaded. Second attempt ignored.
INFO - 2019-08-31 09:28:00 --> Model "Ion_auth_model" initialized
INFO - 2019-08-31 09:28:00 --> Helper loaded: form_helper
INFO - 2019-08-31 09:28:00 --> Form Validation Class Initialized
INFO - 2019-08-31 09:28:00 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-08-31 09:28:01 --> Config Class Initialized
INFO - 2019-08-31 09:28:01 --> Hooks Class Initialized
DEBUG - 2019-08-31 09:28:01 --> UTF-8 Support Enabled
INFO - 2019-08-31 09:28:01 --> Utf8 Class Initialized
INFO - 2019-08-31 09:28:01 --> URI Class Initialized
INFO - 2019-08-31 09:28:01 --> Router Class Initialized
INFO - 2019-08-31 09:28:01 --> Output Class Initialized
INFO - 2019-08-31 09:28:01 --> Security Class Initialized
DEBUG - 2019-08-31 09:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 09:28:01 --> Input Class Initialized
INFO - 2019-08-31 09:28:01 --> Language Class Initialized
INFO - 2019-08-31 09:28:01 --> Loader Class Initialized
INFO - 2019-08-31 09:28:01 --> Helper loaded: url_helper
INFO - 2019-08-31 09:28:01 --> Database Driver Class Initialized
INFO - 2019-08-31 09:28:07 --> Config Class Initialized
INFO - 2019-08-31 09:28:07 --> Hooks Class Initialized
DEBUG - 2019-08-31 09:28:07 --> UTF-8 Support Enabled
INFO - 2019-08-31 09:28:07 --> Utf8 Class Initialized
INFO - 2019-08-31 09:28:07 --> URI Class Initialized
INFO - 2019-08-31 09:28:07 --> Router Class Initialized
INFO - 2019-08-31 09:28:07 --> Output Class Initialized
INFO - 2019-08-31 09:28:07 --> Security Class Initialized
DEBUG - 2019-08-31 09:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 09:28:07 --> Input Class Initialized
INFO - 2019-08-31 09:28:07 --> Language Class Initialized
INFO - 2019-08-31 09:28:07 --> Loader Class Initialized
INFO - 2019-08-31 09:28:07 --> Helper loaded: url_helper
INFO - 2019-08-31 09:28:07 --> Database Driver Class Initialized
DEBUG - 2019-08-31 09:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 09:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 09:28:16 --> Controller Class Initialized
INFO - 2019-08-31 09:28:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 09:28:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-08-31 09:28:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 09:28:18 --> Final output sent to browser
DEBUG - 2019-08-31 09:28:18 --> Total execution time: 10.7351
DEBUG - 2019-08-31 09:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 09:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 09:28:30 --> Controller Class Initialized
INFO - 2019-08-31 09:28:30 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 09:28:30 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-08-31 09:28:30 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 09:28:30 --> Final output sent to browser
DEBUG - 2019-08-31 09:28:30 --> Total execution time: 29.1648
INFO - 2019-08-31 10:03:33 --> Config Class Initialized
INFO - 2019-08-31 10:03:33 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:03:33 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:03:33 --> Utf8 Class Initialized
INFO - 2019-08-31 10:03:33 --> URI Class Initialized
INFO - 2019-08-31 10:03:33 --> Router Class Initialized
INFO - 2019-08-31 10:03:33 --> Output Class Initialized
INFO - 2019-08-31 10:03:33 --> Security Class Initialized
DEBUG - 2019-08-31 10:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:03:33 --> Input Class Initialized
INFO - 2019-08-31 10:03:33 --> Language Class Initialized
INFO - 2019-08-31 10:03:33 --> Loader Class Initialized
INFO - 2019-08-31 10:03:33 --> Helper loaded: url_helper
INFO - 2019-08-31 10:03:33 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:03:48 --> Controller Class Initialized
INFO - 2019-08-31 10:03:48 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 10:03:48 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-08-31 10:03:48 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 10:03:48 --> Final output sent to browser
DEBUG - 2019-08-31 10:03:48 --> Total execution time: 15.0472
INFO - 2019-08-31 10:03:53 --> Config Class Initialized
INFO - 2019-08-31 10:03:53 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:03:53 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:03:53 --> Utf8 Class Initialized
INFO - 2019-08-31 10:03:53 --> URI Class Initialized
INFO - 2019-08-31 10:03:53 --> Router Class Initialized
INFO - 2019-08-31 10:03:53 --> Output Class Initialized
INFO - 2019-08-31 10:03:53 --> Security Class Initialized
DEBUG - 2019-08-31 10:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:03:53 --> Input Class Initialized
INFO - 2019-08-31 10:03:53 --> Language Class Initialized
INFO - 2019-08-31 10:03:53 --> Loader Class Initialized
INFO - 2019-08-31 10:03:53 --> Helper loaded: url_helper
INFO - 2019-08-31 10:03:53 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:04:08 --> Controller Class Initialized
DEBUG - 2019-08-31 10:04:08 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 10:04:08 --> Helper loaded: inflector_helper
INFO - 2019-08-31 10:04:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 10:04:08 --> Model "Form_model" initialized
INFO - 2019-08-31 10:04:10 --> Final output sent to browser
DEBUG - 2019-08-31 10:04:10 --> Total execution time: 16.7586
INFO - 2019-08-31 10:04:10 --> Config Class Initialized
INFO - 2019-08-31 10:04:10 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:04:10 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:04:10 --> Utf8 Class Initialized
INFO - 2019-08-31 10:04:10 --> URI Class Initialized
INFO - 2019-08-31 10:04:10 --> Router Class Initialized
INFO - 2019-08-31 10:04:10 --> Output Class Initialized
INFO - 2019-08-31 10:04:10 --> Security Class Initialized
DEBUG - 2019-08-31 10:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:04:10 --> Input Class Initialized
INFO - 2019-08-31 10:04:10 --> Language Class Initialized
INFO - 2019-08-31 10:04:10 --> Loader Class Initialized
INFO - 2019-08-31 10:04:10 --> Helper loaded: url_helper
INFO - 2019-08-31 10:04:10 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:04:16 --> Controller Class Initialized
INFO - 2019-08-31 10:04:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 10:04:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 10:04:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 10:04:16 --> Final output sent to browser
DEBUG - 2019-08-31 10:04:16 --> Total execution time: 6.1174
INFO - 2019-08-31 10:05:28 --> Config Class Initialized
INFO - 2019-08-31 10:05:28 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:05:28 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:05:28 --> Utf8 Class Initialized
INFO - 2019-08-31 10:05:28 --> URI Class Initialized
INFO - 2019-08-31 10:05:28 --> Router Class Initialized
INFO - 2019-08-31 10:05:28 --> Output Class Initialized
INFO - 2019-08-31 10:05:28 --> Security Class Initialized
DEBUG - 2019-08-31 10:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:05:28 --> Input Class Initialized
INFO - 2019-08-31 10:05:28 --> Language Class Initialized
INFO - 2019-08-31 10:05:28 --> Loader Class Initialized
INFO - 2019-08-31 10:05:28 --> Helper loaded: url_helper
INFO - 2019-08-31 10:05:28 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:05:29 --> Controller Class Initialized
INFO - 2019-08-31 10:05:29 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 10:05:29 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 10:05:29 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 10:05:29 --> Final output sent to browser
DEBUG - 2019-08-31 10:05:29 --> Total execution time: 1.0959
INFO - 2019-08-31 10:05:29 --> Config Class Initialized
INFO - 2019-08-31 10:05:29 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:05:29 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:05:29 --> Utf8 Class Initialized
INFO - 2019-08-31 10:05:29 --> URI Class Initialized
INFO - 2019-08-31 10:05:29 --> Router Class Initialized
INFO - 2019-08-31 10:05:29 --> Output Class Initialized
INFO - 2019-08-31 10:05:29 --> Security Class Initialized
DEBUG - 2019-08-31 10:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:05:29 --> Input Class Initialized
INFO - 2019-08-31 10:05:29 --> Language Class Initialized
INFO - 2019-08-31 10:05:29 --> Loader Class Initialized
INFO - 2019-08-31 10:05:29 --> Helper loaded: url_helper
INFO - 2019-08-31 10:05:29 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:05:30 --> Controller Class Initialized
DEBUG - 2019-08-31 10:05:30 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 10:05:30 --> Helper loaded: inflector_helper
INFO - 2019-08-31 10:05:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 10:05:30 --> Model "Template_model" initialized
INFO - 2019-08-31 10:05:30 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 10:05:31 --> Final output sent to browser
DEBUG - 2019-08-31 10:05:31 --> Total execution time: 1.5688
INFO - 2019-08-31 10:09:51 --> Config Class Initialized
INFO - 2019-08-31 10:09:51 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:09:51 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:09:51 --> Utf8 Class Initialized
INFO - 2019-08-31 10:09:51 --> URI Class Initialized
INFO - 2019-08-31 10:09:51 --> Router Class Initialized
INFO - 2019-08-31 10:09:51 --> Output Class Initialized
INFO - 2019-08-31 10:09:51 --> Security Class Initialized
DEBUG - 2019-08-31 10:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:09:51 --> Input Class Initialized
INFO - 2019-08-31 10:09:51 --> Language Class Initialized
INFO - 2019-08-31 10:09:51 --> Loader Class Initialized
INFO - 2019-08-31 10:09:51 --> Helper loaded: url_helper
INFO - 2019-08-31 10:09:51 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:09:52 --> Controller Class Initialized
INFO - 2019-08-31 10:09:52 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 10:09:52 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 10:09:52 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 10:09:52 --> Final output sent to browser
DEBUG - 2019-08-31 10:09:52 --> Total execution time: 1.1269
INFO - 2019-08-31 10:09:53 --> Config Class Initialized
INFO - 2019-08-31 10:09:53 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:09:53 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:09:53 --> Utf8 Class Initialized
INFO - 2019-08-31 10:09:53 --> URI Class Initialized
INFO - 2019-08-31 10:09:53 --> Router Class Initialized
INFO - 2019-08-31 10:09:53 --> Output Class Initialized
INFO - 2019-08-31 10:09:53 --> Security Class Initialized
DEBUG - 2019-08-31 10:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:09:53 --> Input Class Initialized
INFO - 2019-08-31 10:09:53 --> Language Class Initialized
INFO - 2019-08-31 10:09:53 --> Loader Class Initialized
INFO - 2019-08-31 10:09:53 --> Helper loaded: url_helper
INFO - 2019-08-31 10:09:53 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:10:03 --> Controller Class Initialized
DEBUG - 2019-08-31 10:10:03 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 10:10:03 --> Helper loaded: inflector_helper
INFO - 2019-08-31 10:10:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 10:10:03 --> Model "Template_model" initialized
INFO - 2019-08-31 10:10:03 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 10:10:03 --> Final output sent to browser
DEBUG - 2019-08-31 10:10:03 --> Total execution time: 9.3783
INFO - 2019-08-31 10:13:41 --> Config Class Initialized
INFO - 2019-08-31 10:13:41 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:13:41 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:13:41 --> Utf8 Class Initialized
INFO - 2019-08-31 10:13:41 --> URI Class Initialized
INFO - 2019-08-31 10:13:41 --> Router Class Initialized
INFO - 2019-08-31 10:13:41 --> Output Class Initialized
INFO - 2019-08-31 10:13:41 --> Security Class Initialized
DEBUG - 2019-08-31 10:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:13:41 --> Input Class Initialized
INFO - 2019-08-31 10:13:41 --> Language Class Initialized
INFO - 2019-08-31 10:13:41 --> Loader Class Initialized
INFO - 2019-08-31 10:13:41 --> Helper loaded: url_helper
INFO - 2019-08-31 10:13:41 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:13:50 --> Controller Class Initialized
INFO - 2019-08-31 10:13:50 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 10:13:50 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 10:13:50 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 10:13:50 --> Final output sent to browser
DEBUG - 2019-08-31 10:13:50 --> Total execution time: 9.0504
INFO - 2019-08-31 10:13:50 --> Config Class Initialized
INFO - 2019-08-31 10:13:50 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:13:50 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:13:50 --> Utf8 Class Initialized
INFO - 2019-08-31 10:13:50 --> URI Class Initialized
INFO - 2019-08-31 10:13:50 --> Router Class Initialized
INFO - 2019-08-31 10:13:50 --> Output Class Initialized
INFO - 2019-08-31 10:13:50 --> Security Class Initialized
DEBUG - 2019-08-31 10:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:13:50 --> Input Class Initialized
INFO - 2019-08-31 10:13:50 --> Language Class Initialized
INFO - 2019-08-31 10:13:50 --> Loader Class Initialized
INFO - 2019-08-31 10:13:50 --> Helper loaded: url_helper
INFO - 2019-08-31 10:13:50 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:14:20 --> Controller Class Initialized
DEBUG - 2019-08-31 10:14:20 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 10:14:20 --> Helper loaded: inflector_helper
INFO - 2019-08-31 10:14:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 10:14:20 --> Model "Template_model" initialized
INFO - 2019-08-31 10:14:20 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 10:14:20 --> Final output sent to browser
DEBUG - 2019-08-31 10:14:20 --> Total execution time: 29.8859
INFO - 2019-08-31 10:30:37 --> Config Class Initialized
INFO - 2019-08-31 10:30:37 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:30:37 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:30:37 --> Utf8 Class Initialized
INFO - 2019-08-31 10:30:37 --> URI Class Initialized
INFO - 2019-08-31 10:30:37 --> Router Class Initialized
INFO - 2019-08-31 10:30:37 --> Output Class Initialized
INFO - 2019-08-31 10:30:37 --> Security Class Initialized
DEBUG - 2019-08-31 10:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:30:37 --> Input Class Initialized
INFO - 2019-08-31 10:30:37 --> Language Class Initialized
INFO - 2019-08-31 10:30:37 --> Loader Class Initialized
INFO - 2019-08-31 10:30:37 --> Helper loaded: url_helper
INFO - 2019-08-31 10:30:37 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:30:44 --> Controller Class Initialized
INFO - 2019-08-31 10:30:44 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 10:30:44 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 10:30:44 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 10:30:44 --> Final output sent to browser
DEBUG - 2019-08-31 10:30:44 --> Total execution time: 6.4311
INFO - 2019-08-31 10:30:45 --> Config Class Initialized
INFO - 2019-08-31 10:30:45 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:30:45 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:30:45 --> Utf8 Class Initialized
INFO - 2019-08-31 10:30:45 --> URI Class Initialized
INFO - 2019-08-31 10:30:45 --> Router Class Initialized
INFO - 2019-08-31 10:30:45 --> Output Class Initialized
INFO - 2019-08-31 10:30:45 --> Security Class Initialized
DEBUG - 2019-08-31 10:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:30:45 --> Input Class Initialized
INFO - 2019-08-31 10:30:45 --> Language Class Initialized
INFO - 2019-08-31 10:30:45 --> Loader Class Initialized
INFO - 2019-08-31 10:30:45 --> Helper loaded: url_helper
INFO - 2019-08-31 10:30:45 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:30:54 --> Controller Class Initialized
DEBUG - 2019-08-31 10:30:54 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 10:30:54 --> Helper loaded: inflector_helper
INFO - 2019-08-31 10:30:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 10:30:54 --> Model "Template_model" initialized
INFO - 2019-08-31 10:30:54 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 10:30:54 --> Final output sent to browser
DEBUG - 2019-08-31 10:30:54 --> Total execution time: 9.5833
INFO - 2019-08-31 10:32:46 --> Config Class Initialized
INFO - 2019-08-31 10:32:46 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:32:46 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:32:46 --> Utf8 Class Initialized
INFO - 2019-08-31 10:32:46 --> URI Class Initialized
INFO - 2019-08-31 10:32:46 --> Router Class Initialized
INFO - 2019-08-31 10:32:46 --> Output Class Initialized
INFO - 2019-08-31 10:32:46 --> Security Class Initialized
DEBUG - 2019-08-31 10:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:32:46 --> Input Class Initialized
INFO - 2019-08-31 10:32:46 --> Language Class Initialized
INFO - 2019-08-31 10:32:46 --> Loader Class Initialized
INFO - 2019-08-31 10:32:46 --> Helper loaded: url_helper
INFO - 2019-08-31 10:32:46 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:32:47 --> Controller Class Initialized
INFO - 2019-08-31 10:32:47 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 10:32:47 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 10:32:47 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 10:32:47 --> Final output sent to browser
DEBUG - 2019-08-31 10:32:47 --> Total execution time: 1.1119
INFO - 2019-08-31 10:32:50 --> Config Class Initialized
INFO - 2019-08-31 10:32:50 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:32:50 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:32:50 --> Utf8 Class Initialized
INFO - 2019-08-31 10:32:50 --> URI Class Initialized
INFO - 2019-08-31 10:32:50 --> Router Class Initialized
INFO - 2019-08-31 10:32:50 --> Output Class Initialized
INFO - 2019-08-31 10:32:50 --> Security Class Initialized
DEBUG - 2019-08-31 10:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:32:50 --> Input Class Initialized
INFO - 2019-08-31 10:32:50 --> Language Class Initialized
INFO - 2019-08-31 10:32:50 --> Loader Class Initialized
INFO - 2019-08-31 10:32:50 --> Helper loaded: url_helper
INFO - 2019-08-31 10:32:50 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:33:05 --> Controller Class Initialized
INFO - 2019-08-31 10:33:05 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 10:33:05 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 10:33:05 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 10:33:05 --> Final output sent to browser
DEBUG - 2019-08-31 10:33:05 --> Total execution time: 15.1525
INFO - 2019-08-31 10:33:06 --> Config Class Initialized
INFO - 2019-08-31 10:33:06 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:33:06 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:33:06 --> Utf8 Class Initialized
INFO - 2019-08-31 10:33:06 --> URI Class Initialized
INFO - 2019-08-31 10:33:06 --> Router Class Initialized
INFO - 2019-08-31 10:33:06 --> Output Class Initialized
INFO - 2019-08-31 10:33:06 --> Security Class Initialized
DEBUG - 2019-08-31 10:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:33:06 --> Input Class Initialized
INFO - 2019-08-31 10:33:06 --> Language Class Initialized
INFO - 2019-08-31 10:33:06 --> Loader Class Initialized
INFO - 2019-08-31 10:33:06 --> Helper loaded: url_helper
INFO - 2019-08-31 10:33:06 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:33:12 --> Controller Class Initialized
DEBUG - 2019-08-31 10:33:12 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 10:33:12 --> Helper loaded: inflector_helper
INFO - 2019-08-31 10:33:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 10:33:12 --> Model "Template_model" initialized
INFO - 2019-08-31 10:33:12 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 10:33:12 --> Final output sent to browser
DEBUG - 2019-08-31 10:33:12 --> Total execution time: 6.5041
INFO - 2019-08-31 10:37:08 --> Config Class Initialized
INFO - 2019-08-31 10:37:08 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:37:08 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:37:08 --> Utf8 Class Initialized
INFO - 2019-08-31 10:37:08 --> URI Class Initialized
INFO - 2019-08-31 10:37:08 --> Router Class Initialized
INFO - 2019-08-31 10:37:08 --> Output Class Initialized
INFO - 2019-08-31 10:37:08 --> Security Class Initialized
DEBUG - 2019-08-31 10:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:37:08 --> Input Class Initialized
INFO - 2019-08-31 10:37:08 --> Language Class Initialized
INFO - 2019-08-31 10:37:08 --> Loader Class Initialized
INFO - 2019-08-31 10:37:08 --> Helper loaded: url_helper
INFO - 2019-08-31 10:37:08 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:37:17 --> Controller Class Initialized
INFO - 2019-08-31 10:37:17 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 10:37:17 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 10:37:17 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 10:37:17 --> Final output sent to browser
DEBUG - 2019-08-31 10:37:17 --> Total execution time: 9.1094
INFO - 2019-08-31 10:37:18 --> Config Class Initialized
INFO - 2019-08-31 10:37:18 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:37:18 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:37:18 --> Utf8 Class Initialized
INFO - 2019-08-31 10:37:18 --> URI Class Initialized
INFO - 2019-08-31 10:37:18 --> Router Class Initialized
INFO - 2019-08-31 10:37:18 --> Output Class Initialized
INFO - 2019-08-31 10:37:18 --> Security Class Initialized
DEBUG - 2019-08-31 10:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:37:18 --> Input Class Initialized
INFO - 2019-08-31 10:37:18 --> Language Class Initialized
INFO - 2019-08-31 10:37:18 --> Loader Class Initialized
INFO - 2019-08-31 10:37:18 --> Helper loaded: url_helper
INFO - 2019-08-31 10:37:18 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:37:24 --> Controller Class Initialized
DEBUG - 2019-08-31 10:37:24 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 10:37:24 --> Helper loaded: inflector_helper
INFO - 2019-08-31 10:37:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 10:37:24 --> Model "Template_model" initialized
INFO - 2019-08-31 10:37:24 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 10:37:27 --> Final output sent to browser
DEBUG - 2019-08-31 10:37:27 --> Total execution time: 9.5201
INFO - 2019-08-31 10:38:24 --> Config Class Initialized
INFO - 2019-08-31 10:38:24 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:38:24 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:38:24 --> Utf8 Class Initialized
INFO - 2019-08-31 10:38:24 --> URI Class Initialized
INFO - 2019-08-31 10:38:24 --> Router Class Initialized
INFO - 2019-08-31 10:38:24 --> Output Class Initialized
INFO - 2019-08-31 10:38:24 --> Security Class Initialized
DEBUG - 2019-08-31 10:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:38:24 --> Input Class Initialized
INFO - 2019-08-31 10:38:24 --> Language Class Initialized
INFO - 2019-08-31 10:38:24 --> Loader Class Initialized
INFO - 2019-08-31 10:38:24 --> Helper loaded: url_helper
INFO - 2019-08-31 10:38:24 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:38:54 --> Controller Class Initialized
INFO - 2019-08-31 10:38:54 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 10:38:54 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 10:38:54 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 10:38:54 --> Final output sent to browser
DEBUG - 2019-08-31 10:38:54 --> Total execution time: 29.1539
INFO - 2019-08-31 10:39:37 --> Config Class Initialized
INFO - 2019-08-31 10:39:37 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:39:37 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:39:37 --> Utf8 Class Initialized
INFO - 2019-08-31 10:39:37 --> URI Class Initialized
INFO - 2019-08-31 10:39:37 --> Router Class Initialized
INFO - 2019-08-31 10:39:37 --> Output Class Initialized
INFO - 2019-08-31 10:39:37 --> Security Class Initialized
DEBUG - 2019-08-31 10:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:39:37 --> Input Class Initialized
INFO - 2019-08-31 10:39:37 --> Language Class Initialized
INFO - 2019-08-31 10:39:37 --> Loader Class Initialized
INFO - 2019-08-31 10:39:37 --> Helper loaded: url_helper
INFO - 2019-08-31 10:39:37 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:39:38 --> Controller Class Initialized
INFO - 2019-08-31 10:39:38 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 10:39:38 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 10:39:38 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 10:39:38 --> Final output sent to browser
DEBUG - 2019-08-31 10:39:38 --> Total execution time: 1.1169
INFO - 2019-08-31 10:39:39 --> Config Class Initialized
INFO - 2019-08-31 10:39:39 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:39:39 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:39:39 --> Utf8 Class Initialized
INFO - 2019-08-31 10:39:39 --> URI Class Initialized
INFO - 2019-08-31 10:39:39 --> Router Class Initialized
INFO - 2019-08-31 10:39:39 --> Output Class Initialized
INFO - 2019-08-31 10:39:39 --> Security Class Initialized
DEBUG - 2019-08-31 10:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:39:39 --> Input Class Initialized
INFO - 2019-08-31 10:39:39 --> Language Class Initialized
INFO - 2019-08-31 10:39:39 --> Loader Class Initialized
INFO - 2019-08-31 10:39:39 --> Helper loaded: url_helper
INFO - 2019-08-31 10:39:39 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:39:40 --> Controller Class Initialized
DEBUG - 2019-08-31 10:39:40 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 10:39:40 --> Helper loaded: inflector_helper
INFO - 2019-08-31 10:39:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 10:39:40 --> Model "Template_model" initialized
INFO - 2019-08-31 10:39:40 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 10:39:40 --> Final output sent to browser
DEBUG - 2019-08-31 10:39:40 --> Total execution time: 1.3861
INFO - 2019-08-31 10:48:10 --> Config Class Initialized
INFO - 2019-08-31 10:48:10 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:48:10 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:48:10 --> Utf8 Class Initialized
INFO - 2019-08-31 10:48:10 --> URI Class Initialized
INFO - 2019-08-31 10:48:10 --> Router Class Initialized
INFO - 2019-08-31 10:48:10 --> Output Class Initialized
INFO - 2019-08-31 10:48:10 --> Security Class Initialized
DEBUG - 2019-08-31 10:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:48:10 --> Input Class Initialized
INFO - 2019-08-31 10:48:10 --> Language Class Initialized
INFO - 2019-08-31 10:48:10 --> Loader Class Initialized
INFO - 2019-08-31 10:48:10 --> Helper loaded: url_helper
INFO - 2019-08-31 10:48:10 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:48:11 --> Controller Class Initialized
INFO - 2019-08-31 10:48:11 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 10:48:11 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 10:48:11 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 10:48:11 --> Final output sent to browser
DEBUG - 2019-08-31 10:48:11 --> Total execution time: 1.2024
INFO - 2019-08-31 10:48:13 --> Config Class Initialized
INFO - 2019-08-31 10:48:13 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:48:13 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:48:13 --> Utf8 Class Initialized
INFO - 2019-08-31 10:48:13 --> URI Class Initialized
INFO - 2019-08-31 10:48:13 --> Router Class Initialized
INFO - 2019-08-31 10:48:13 --> Output Class Initialized
INFO - 2019-08-31 10:48:13 --> Security Class Initialized
DEBUG - 2019-08-31 10:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:48:13 --> Input Class Initialized
INFO - 2019-08-31 10:48:13 --> Language Class Initialized
INFO - 2019-08-31 10:48:13 --> Loader Class Initialized
INFO - 2019-08-31 10:48:13 --> Helper loaded: url_helper
INFO - 2019-08-31 10:48:13 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:48:14 --> Controller Class Initialized
DEBUG - 2019-08-31 10:48:14 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 10:48:14 --> Helper loaded: inflector_helper
INFO - 2019-08-31 10:48:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 10:48:14 --> Model "Template_model" initialized
INFO - 2019-08-31 10:48:14 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 10:48:16 --> Final output sent to browser
DEBUG - 2019-08-31 10:48:16 --> Total execution time: 3.0888
INFO - 2019-08-31 10:58:03 --> Config Class Initialized
INFO - 2019-08-31 10:58:03 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:58:03 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:58:03 --> Utf8 Class Initialized
INFO - 2019-08-31 10:58:03 --> URI Class Initialized
INFO - 2019-08-31 10:58:03 --> Router Class Initialized
INFO - 2019-08-31 10:58:03 --> Output Class Initialized
INFO - 2019-08-31 10:58:03 --> Security Class Initialized
DEBUG - 2019-08-31 10:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:58:03 --> Input Class Initialized
INFO - 2019-08-31 10:58:03 --> Language Class Initialized
INFO - 2019-08-31 10:58:03 --> Loader Class Initialized
INFO - 2019-08-31 10:58:03 --> Helper loaded: url_helper
INFO - 2019-08-31 10:58:03 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:58:18 --> Controller Class Initialized
INFO - 2019-08-31 10:58:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 10:58:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 10:58:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 10:58:18 --> Final output sent to browser
DEBUG - 2019-08-31 10:58:18 --> Total execution time: 15.1033
INFO - 2019-08-31 10:58:33 --> Config Class Initialized
INFO - 2019-08-31 10:58:33 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:58:33 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:58:33 --> Utf8 Class Initialized
INFO - 2019-08-31 10:58:33 --> URI Class Initialized
INFO - 2019-08-31 10:58:33 --> Router Class Initialized
INFO - 2019-08-31 10:58:33 --> Output Class Initialized
INFO - 2019-08-31 10:58:33 --> Security Class Initialized
DEBUG - 2019-08-31 10:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:58:33 --> Input Class Initialized
INFO - 2019-08-31 10:58:33 --> Language Class Initialized
INFO - 2019-08-31 10:58:33 --> Loader Class Initialized
INFO - 2019-08-31 10:58:33 --> Helper loaded: url_helper
INFO - 2019-08-31 10:58:33 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:59:02 --> Controller Class Initialized
INFO - 2019-08-31 10:59:02 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 10:59:02 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 10:59:02 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 10:59:02 --> Final output sent to browser
DEBUG - 2019-08-31 10:59:02 --> Total execution time: 29.0945
INFO - 2019-08-31 10:59:03 --> Config Class Initialized
INFO - 2019-08-31 10:59:03 --> Hooks Class Initialized
DEBUG - 2019-08-31 10:59:03 --> UTF-8 Support Enabled
INFO - 2019-08-31 10:59:03 --> Utf8 Class Initialized
INFO - 2019-08-31 10:59:03 --> URI Class Initialized
INFO - 2019-08-31 10:59:03 --> Router Class Initialized
INFO - 2019-08-31 10:59:03 --> Output Class Initialized
INFO - 2019-08-31 10:59:03 --> Security Class Initialized
DEBUG - 2019-08-31 10:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 10:59:03 --> Input Class Initialized
INFO - 2019-08-31 10:59:03 --> Language Class Initialized
INFO - 2019-08-31 10:59:03 --> Loader Class Initialized
INFO - 2019-08-31 10:59:03 --> Helper loaded: url_helper
INFO - 2019-08-31 10:59:03 --> Database Driver Class Initialized
DEBUG - 2019-08-31 10:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 10:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 10:59:09 --> Controller Class Initialized
DEBUG - 2019-08-31 10:59:09 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 10:59:09 --> Helper loaded: inflector_helper
INFO - 2019-08-31 10:59:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 10:59:09 --> Model "Template_model" initialized
INFO - 2019-08-31 10:59:09 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 10:59:15 --> Final output sent to browser
DEBUG - 2019-08-31 10:59:15 --> Total execution time: 11.4341
INFO - 2019-08-31 11:02:37 --> Config Class Initialized
INFO - 2019-08-31 11:02:37 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:02:37 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:02:37 --> Utf8 Class Initialized
INFO - 2019-08-31 11:02:37 --> URI Class Initialized
INFO - 2019-08-31 11:02:37 --> Router Class Initialized
INFO - 2019-08-31 11:02:37 --> Output Class Initialized
INFO - 2019-08-31 11:02:37 --> Security Class Initialized
DEBUG - 2019-08-31 11:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:02:37 --> Input Class Initialized
INFO - 2019-08-31 11:02:37 --> Language Class Initialized
INFO - 2019-08-31 11:02:37 --> Loader Class Initialized
INFO - 2019-08-31 11:02:37 --> Helper loaded: url_helper
INFO - 2019-08-31 11:02:37 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:03:06 --> Controller Class Initialized
INFO - 2019-08-31 11:03:06 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:03:06 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:03:06 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:03:06 --> Final output sent to browser
DEBUG - 2019-08-31 11:03:06 --> Total execution time: 29.1458
INFO - 2019-08-31 11:06:47 --> Config Class Initialized
INFO - 2019-08-31 11:06:47 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:06:47 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:06:47 --> Utf8 Class Initialized
INFO - 2019-08-31 11:06:47 --> URI Class Initialized
INFO - 2019-08-31 11:06:47 --> Router Class Initialized
INFO - 2019-08-31 11:06:47 --> Output Class Initialized
INFO - 2019-08-31 11:06:47 --> Security Class Initialized
DEBUG - 2019-08-31 11:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:06:47 --> Input Class Initialized
INFO - 2019-08-31 11:06:47 --> Language Class Initialized
INFO - 2019-08-31 11:06:47 --> Loader Class Initialized
INFO - 2019-08-31 11:06:47 --> Helper loaded: url_helper
INFO - 2019-08-31 11:06:47 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:06:49 --> Controller Class Initialized
INFO - 2019-08-31 11:06:49 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:06:49 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:06:49 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:06:49 --> Final output sent to browser
DEBUG - 2019-08-31 11:06:49 --> Total execution time: 1.8340
INFO - 2019-08-31 11:06:50 --> Config Class Initialized
INFO - 2019-08-31 11:06:50 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:06:50 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:06:50 --> Utf8 Class Initialized
INFO - 2019-08-31 11:06:50 --> URI Class Initialized
INFO - 2019-08-31 11:06:50 --> Router Class Initialized
INFO - 2019-08-31 11:06:50 --> Output Class Initialized
INFO - 2019-08-31 11:06:50 --> Security Class Initialized
DEBUG - 2019-08-31 11:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:06:50 --> Input Class Initialized
INFO - 2019-08-31 11:06:50 --> Language Class Initialized
INFO - 2019-08-31 11:06:50 --> Loader Class Initialized
INFO - 2019-08-31 11:06:50 --> Helper loaded: url_helper
INFO - 2019-08-31 11:06:50 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:06:51 --> Controller Class Initialized
DEBUG - 2019-08-31 11:06:51 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:06:51 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:06:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:06:51 --> Model "Template_model" initialized
INFO - 2019-08-31 11:06:51 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 11:06:55 --> Final output sent to browser
DEBUG - 2019-08-31 11:06:55 --> Total execution time: 5.1113
INFO - 2019-08-31 11:10:48 --> Config Class Initialized
INFO - 2019-08-31 11:10:48 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:10:48 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:10:48 --> Utf8 Class Initialized
INFO - 2019-08-31 11:10:48 --> URI Class Initialized
INFO - 2019-08-31 11:10:48 --> Router Class Initialized
INFO - 2019-08-31 11:10:48 --> Output Class Initialized
INFO - 2019-08-31 11:10:48 --> Security Class Initialized
DEBUG - 2019-08-31 11:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:10:48 --> Input Class Initialized
INFO - 2019-08-31 11:10:48 --> Language Class Initialized
INFO - 2019-08-31 11:10:48 --> Loader Class Initialized
INFO - 2019-08-31 11:10:48 --> Helper loaded: url_helper
INFO - 2019-08-31 11:10:48 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:10:54 --> Controller Class Initialized
INFO - 2019-08-31 11:10:54 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:10:54 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:10:54 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:10:54 --> Final output sent to browser
DEBUG - 2019-08-31 11:10:54 --> Total execution time: 6.1622
INFO - 2019-08-31 11:10:55 --> Config Class Initialized
INFO - 2019-08-31 11:10:55 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:10:55 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:10:55 --> Utf8 Class Initialized
INFO - 2019-08-31 11:10:55 --> URI Class Initialized
INFO - 2019-08-31 11:10:55 --> Router Class Initialized
INFO - 2019-08-31 11:10:55 --> Output Class Initialized
INFO - 2019-08-31 11:10:55 --> Security Class Initialized
DEBUG - 2019-08-31 11:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:10:55 --> Input Class Initialized
INFO - 2019-08-31 11:10:55 --> Language Class Initialized
INFO - 2019-08-31 11:10:55 --> Loader Class Initialized
INFO - 2019-08-31 11:10:55 --> Helper loaded: url_helper
INFO - 2019-08-31 11:10:55 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:11:24 --> Controller Class Initialized
DEBUG - 2019-08-31 11:11:24 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:11:24 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:11:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:11:24 --> Model "Template_model" initialized
INFO - 2019-08-31 11:11:24 --> Model "Khang_sinh_model" initialized
ERROR - 2019-08-31 11:11:27 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 307
INFO - 2019-08-31 11:11:38 --> Config Class Initialized
INFO - 2019-08-31 11:11:38 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:11:38 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:11:38 --> Utf8 Class Initialized
INFO - 2019-08-31 11:11:38 --> URI Class Initialized
INFO - 2019-08-31 11:11:38 --> Router Class Initialized
INFO - 2019-08-31 11:11:38 --> Output Class Initialized
INFO - 2019-08-31 11:11:38 --> Security Class Initialized
DEBUG - 2019-08-31 11:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:11:38 --> Input Class Initialized
INFO - 2019-08-31 11:11:38 --> Language Class Initialized
INFO - 2019-08-31 11:11:38 --> Loader Class Initialized
INFO - 2019-08-31 11:11:38 --> Helper loaded: url_helper
INFO - 2019-08-31 11:11:38 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:11:40 --> Controller Class Initialized
INFO - 2019-08-31 11:11:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:11:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 11:11:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:11:40 --> Final output sent to browser
DEBUG - 2019-08-31 11:11:40 --> Total execution time: 1.5328
INFO - 2019-08-31 11:11:48 --> Config Class Initialized
INFO - 2019-08-31 11:11:48 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:11:48 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:11:48 --> Utf8 Class Initialized
INFO - 2019-08-31 11:11:48 --> URI Class Initialized
INFO - 2019-08-31 11:11:48 --> Router Class Initialized
INFO - 2019-08-31 11:11:48 --> Output Class Initialized
INFO - 2019-08-31 11:11:48 --> Security Class Initialized
DEBUG - 2019-08-31 11:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:11:48 --> Input Class Initialized
INFO - 2019-08-31 11:11:48 --> Language Class Initialized
INFO - 2019-08-31 11:11:48 --> Loader Class Initialized
INFO - 2019-08-31 11:11:48 --> Helper loaded: url_helper
INFO - 2019-08-31 11:11:48 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:12:03 --> Controller Class Initialized
INFO - 2019-08-31 11:12:03 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:12:03 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:12:03 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:12:03 --> Final output sent to browser
DEBUG - 2019-08-31 11:12:03 --> Total execution time: 14.9324
INFO - 2019-08-31 11:12:03 --> Config Class Initialized
INFO - 2019-08-31 11:12:03 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:12:03 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:12:03 --> Utf8 Class Initialized
INFO - 2019-08-31 11:12:03 --> URI Class Initialized
INFO - 2019-08-31 11:12:03 --> Router Class Initialized
INFO - 2019-08-31 11:12:03 --> Output Class Initialized
INFO - 2019-08-31 11:12:03 --> Security Class Initialized
DEBUG - 2019-08-31 11:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:12:03 --> Input Class Initialized
INFO - 2019-08-31 11:12:03 --> Language Class Initialized
INFO - 2019-08-31 11:12:03 --> Loader Class Initialized
INFO - 2019-08-31 11:12:03 --> Helper loaded: url_helper
INFO - 2019-08-31 11:12:03 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:12:05 --> Controller Class Initialized
DEBUG - 2019-08-31 11:12:05 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:12:05 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:12:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:12:05 --> Model "Template_model" initialized
INFO - 2019-08-31 11:12:05 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 11:12:09 --> Final output sent to browser
DEBUG - 2019-08-31 11:12:09 --> Total execution time: 5.7467
INFO - 2019-08-31 11:15:55 --> Config Class Initialized
INFO - 2019-08-31 11:15:55 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:15:55 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:15:55 --> Utf8 Class Initialized
INFO - 2019-08-31 11:15:55 --> URI Class Initialized
INFO - 2019-08-31 11:15:55 --> Router Class Initialized
INFO - 2019-08-31 11:15:55 --> Output Class Initialized
INFO - 2019-08-31 11:15:55 --> Security Class Initialized
DEBUG - 2019-08-31 11:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:15:55 --> Input Class Initialized
INFO - 2019-08-31 11:15:55 --> Language Class Initialized
INFO - 2019-08-31 11:15:55 --> Loader Class Initialized
INFO - 2019-08-31 11:15:55 --> Helper loaded: url_helper
INFO - 2019-08-31 11:15:55 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:16:01 --> Controller Class Initialized
INFO - 2019-08-31 11:16:01 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:16:01 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:16:01 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:16:01 --> Final output sent to browser
DEBUG - 2019-08-31 11:16:01 --> Total execution time: 6.1597
INFO - 2019-08-31 11:16:02 --> Config Class Initialized
INFO - 2019-08-31 11:16:02 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:16:02 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:16:02 --> Utf8 Class Initialized
INFO - 2019-08-31 11:16:02 --> URI Class Initialized
INFO - 2019-08-31 11:16:02 --> Router Class Initialized
INFO - 2019-08-31 11:16:02 --> Output Class Initialized
INFO - 2019-08-31 11:16:02 --> Security Class Initialized
DEBUG - 2019-08-31 11:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:16:02 --> Input Class Initialized
INFO - 2019-08-31 11:16:02 --> Language Class Initialized
INFO - 2019-08-31 11:16:02 --> Loader Class Initialized
INFO - 2019-08-31 11:16:02 --> Helper loaded: url_helper
INFO - 2019-08-31 11:16:02 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:16:03 --> Controller Class Initialized
DEBUG - 2019-08-31 11:16:03 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:16:03 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:16:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:16:03 --> Model "Template_model" initialized
INFO - 2019-08-31 11:16:03 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 11:16:05 --> Final output sent to browser
DEBUG - 2019-08-31 11:16:05 --> Total execution time: 3.3650
INFO - 2019-08-31 11:16:51 --> Config Class Initialized
INFO - 2019-08-31 11:16:51 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:16:51 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:16:51 --> Utf8 Class Initialized
INFO - 2019-08-31 11:16:51 --> URI Class Initialized
INFO - 2019-08-31 11:16:51 --> Router Class Initialized
INFO - 2019-08-31 11:16:51 --> Output Class Initialized
INFO - 2019-08-31 11:16:51 --> Security Class Initialized
DEBUG - 2019-08-31 11:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:16:51 --> Input Class Initialized
INFO - 2019-08-31 11:16:51 --> Language Class Initialized
INFO - 2019-08-31 11:16:51 --> Loader Class Initialized
INFO - 2019-08-31 11:16:51 --> Helper loaded: url_helper
INFO - 2019-08-31 11:16:51 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:16:52 --> Controller Class Initialized
INFO - 2019-08-31 11:16:52 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:16:52 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 11:16:52 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:16:52 --> Final output sent to browser
DEBUG - 2019-08-31 11:16:52 --> Total execution time: 1.1790
INFO - 2019-08-31 11:16:57 --> Config Class Initialized
INFO - 2019-08-31 11:16:57 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:16:57 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:16:57 --> Utf8 Class Initialized
INFO - 2019-08-31 11:16:57 --> URI Class Initialized
INFO - 2019-08-31 11:16:57 --> Router Class Initialized
INFO - 2019-08-31 11:16:57 --> Output Class Initialized
INFO - 2019-08-31 11:16:57 --> Security Class Initialized
DEBUG - 2019-08-31 11:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:16:57 --> Input Class Initialized
INFO - 2019-08-31 11:16:57 --> Language Class Initialized
INFO - 2019-08-31 11:16:57 --> Loader Class Initialized
INFO - 2019-08-31 11:16:57 --> Helper loaded: url_helper
INFO - 2019-08-31 11:16:57 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:16:58 --> Controller Class Initialized
INFO - 2019-08-31 11:16:58 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:16:58 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:16:58 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:16:58 --> Final output sent to browser
DEBUG - 2019-08-31 11:16:58 --> Total execution time: 1.1475
INFO - 2019-08-31 11:16:59 --> Config Class Initialized
INFO - 2019-08-31 11:16:59 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:16:59 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:16:59 --> Utf8 Class Initialized
INFO - 2019-08-31 11:16:59 --> URI Class Initialized
INFO - 2019-08-31 11:16:59 --> Router Class Initialized
INFO - 2019-08-31 11:16:59 --> Output Class Initialized
INFO - 2019-08-31 11:16:59 --> Security Class Initialized
DEBUG - 2019-08-31 11:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:16:59 --> Input Class Initialized
INFO - 2019-08-31 11:16:59 --> Language Class Initialized
INFO - 2019-08-31 11:16:59 --> Loader Class Initialized
INFO - 2019-08-31 11:16:59 --> Helper loaded: url_helper
INFO - 2019-08-31 11:16:59 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:17:08 --> Controller Class Initialized
DEBUG - 2019-08-31 11:17:08 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:17:08 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:17:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:17:08 --> Model "Template_model" initialized
INFO - 2019-08-31 11:17:08 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 11:17:18 --> Final output sent to browser
DEBUG - 2019-08-31 11:17:18 --> Total execution time: 19.3217
INFO - 2019-08-31 11:17:21 --> Config Class Initialized
INFO - 2019-08-31 11:17:21 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:17:21 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:17:21 --> Utf8 Class Initialized
INFO - 2019-08-31 11:17:21 --> URI Class Initialized
INFO - 2019-08-31 11:17:21 --> Router Class Initialized
INFO - 2019-08-31 11:17:21 --> Output Class Initialized
INFO - 2019-08-31 11:17:21 --> Security Class Initialized
DEBUG - 2019-08-31 11:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:17:21 --> Input Class Initialized
INFO - 2019-08-31 11:17:21 --> Language Class Initialized
INFO - 2019-08-31 11:17:21 --> Loader Class Initialized
INFO - 2019-08-31 11:17:21 --> Helper loaded: url_helper
INFO - 2019-08-31 11:17:21 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:17:28 --> Controller Class Initialized
INFO - 2019-08-31 11:17:28 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:17:28 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 11:17:28 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:17:28 --> Final output sent to browser
DEBUG - 2019-08-31 11:17:28 --> Total execution time: 6.1312
INFO - 2019-08-31 11:17:58 --> Config Class Initialized
INFO - 2019-08-31 11:17:58 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:17:58 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:17:58 --> Utf8 Class Initialized
INFO - 2019-08-31 11:17:58 --> URI Class Initialized
INFO - 2019-08-31 11:17:58 --> Router Class Initialized
INFO - 2019-08-31 11:17:58 --> Output Class Initialized
INFO - 2019-08-31 11:17:58 --> Security Class Initialized
DEBUG - 2019-08-31 11:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:17:58 --> Input Class Initialized
INFO - 2019-08-31 11:17:58 --> Language Class Initialized
INFO - 2019-08-31 11:17:58 --> Loader Class Initialized
INFO - 2019-08-31 11:17:58 --> Helper loaded: url_helper
INFO - 2019-08-31 11:17:58 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:18:04 --> Controller Class Initialized
INFO - 2019-08-31 11:18:04 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:18:04 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 11:18:04 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:18:04 --> Final output sent to browser
DEBUG - 2019-08-31 11:18:04 --> Total execution time: 6.0381
INFO - 2019-08-31 11:18:45 --> Config Class Initialized
INFO - 2019-08-31 11:18:45 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:18:45 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:18:45 --> Utf8 Class Initialized
INFO - 2019-08-31 11:18:45 --> URI Class Initialized
INFO - 2019-08-31 11:18:45 --> Router Class Initialized
INFO - 2019-08-31 11:18:45 --> Output Class Initialized
INFO - 2019-08-31 11:18:45 --> Security Class Initialized
DEBUG - 2019-08-31 11:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:18:45 --> Input Class Initialized
INFO - 2019-08-31 11:18:45 --> Language Class Initialized
INFO - 2019-08-31 11:18:45 --> Loader Class Initialized
INFO - 2019-08-31 11:18:45 --> Helper loaded: url_helper
INFO - 2019-08-31 11:18:45 --> Database Driver Class Initialized
INFO - 2019-08-31 11:19:11 --> Config Class Initialized
INFO - 2019-08-31 11:19:11 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:19:11 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:19:11 --> Utf8 Class Initialized
INFO - 2019-08-31 11:19:11 --> URI Class Initialized
INFO - 2019-08-31 11:19:11 --> Router Class Initialized
INFO - 2019-08-31 11:19:11 --> Output Class Initialized
INFO - 2019-08-31 11:19:11 --> Security Class Initialized
DEBUG - 2019-08-31 11:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:19:11 --> Input Class Initialized
INFO - 2019-08-31 11:19:11 --> Language Class Initialized
INFO - 2019-08-31 11:19:11 --> Loader Class Initialized
INFO - 2019-08-31 11:19:11 --> Helper loaded: url_helper
INFO - 2019-08-31 11:19:11 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:19:14 --> Controller Class Initialized
INFO - 2019-08-31 11:19:14 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:19:14 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:19:14 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:19:14 --> Final output sent to browser
DEBUG - 2019-08-31 11:19:14 --> Total execution time: 29.0979
DEBUG - 2019-08-31 11:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:19:40 --> Controller Class Initialized
INFO - 2019-08-31 11:19:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:19:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 11:19:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:19:40 --> Final output sent to browser
DEBUG - 2019-08-31 11:19:40 --> Total execution time: 29.1147
INFO - 2019-08-31 11:20:01 --> Config Class Initialized
INFO - 2019-08-31 11:20:01 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:20:01 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:20:01 --> Utf8 Class Initialized
INFO - 2019-08-31 11:20:01 --> URI Class Initialized
INFO - 2019-08-31 11:20:01 --> Router Class Initialized
INFO - 2019-08-31 11:20:01 --> Output Class Initialized
INFO - 2019-08-31 11:20:01 --> Security Class Initialized
DEBUG - 2019-08-31 11:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:20:01 --> Input Class Initialized
INFO - 2019-08-31 11:20:01 --> Language Class Initialized
INFO - 2019-08-31 11:20:01 --> Loader Class Initialized
INFO - 2019-08-31 11:20:01 --> Helper loaded: url_helper
INFO - 2019-08-31 11:20:01 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:20:07 --> Controller Class Initialized
INFO - 2019-08-31 11:20:07 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:20:07 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:20:07 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:20:07 --> Final output sent to browser
DEBUG - 2019-08-31 11:20:07 --> Total execution time: 6.1653
INFO - 2019-08-31 11:20:08 --> Config Class Initialized
INFO - 2019-08-31 11:20:08 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:20:08 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:20:08 --> Utf8 Class Initialized
INFO - 2019-08-31 11:20:08 --> URI Class Initialized
INFO - 2019-08-31 11:20:08 --> Router Class Initialized
INFO - 2019-08-31 11:20:08 --> Output Class Initialized
INFO - 2019-08-31 11:20:08 --> Security Class Initialized
DEBUG - 2019-08-31 11:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:20:08 --> Input Class Initialized
INFO - 2019-08-31 11:20:08 --> Language Class Initialized
INFO - 2019-08-31 11:20:08 --> Loader Class Initialized
INFO - 2019-08-31 11:20:08 --> Helper loaded: url_helper
INFO - 2019-08-31 11:20:08 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:20:09 --> Controller Class Initialized
DEBUG - 2019-08-31 11:20:09 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:20:09 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:20:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:20:09 --> Model "Template_model" initialized
INFO - 2019-08-31 11:20:09 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 11:20:13 --> Final output sent to browser
DEBUG - 2019-08-31 11:20:13 --> Total execution time: 5.1566
INFO - 2019-08-31 11:20:30 --> Config Class Initialized
INFO - 2019-08-31 11:20:30 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:20:30 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:20:30 --> Utf8 Class Initialized
INFO - 2019-08-31 11:20:30 --> URI Class Initialized
INFO - 2019-08-31 11:20:30 --> Router Class Initialized
INFO - 2019-08-31 11:20:30 --> Output Class Initialized
INFO - 2019-08-31 11:20:30 --> Security Class Initialized
DEBUG - 2019-08-31 11:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:20:30 --> Input Class Initialized
INFO - 2019-08-31 11:20:30 --> Language Class Initialized
INFO - 2019-08-31 11:20:30 --> Loader Class Initialized
INFO - 2019-08-31 11:20:30 --> Helper loaded: url_helper
INFO - 2019-08-31 11:20:30 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:20:59 --> Controller Class Initialized
INFO - 2019-08-31 11:20:59 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:20:59 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 11:20:59 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:20:59 --> Final output sent to browser
DEBUG - 2019-08-31 11:20:59 --> Total execution time: 29.0557
INFO - 2019-08-31 11:24:22 --> Config Class Initialized
INFO - 2019-08-31 11:24:22 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:24:22 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:24:22 --> Utf8 Class Initialized
INFO - 2019-08-31 11:24:22 --> URI Class Initialized
INFO - 2019-08-31 11:24:22 --> Router Class Initialized
INFO - 2019-08-31 11:24:22 --> Output Class Initialized
INFO - 2019-08-31 11:24:22 --> Security Class Initialized
DEBUG - 2019-08-31 11:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:24:22 --> Input Class Initialized
INFO - 2019-08-31 11:24:22 --> Language Class Initialized
INFO - 2019-08-31 11:24:22 --> Loader Class Initialized
INFO - 2019-08-31 11:24:22 --> Helper loaded: url_helper
INFO - 2019-08-31 11:24:22 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:24:24 --> Controller Class Initialized
INFO - 2019-08-31 11:24:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:24:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 11:24:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:24:24 --> Final output sent to browser
DEBUG - 2019-08-31 11:24:24 --> Total execution time: 1.7108
INFO - 2019-08-31 11:24:53 --> Config Class Initialized
INFO - 2019-08-31 11:24:53 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:24:53 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:24:53 --> Utf8 Class Initialized
INFO - 2019-08-31 11:24:53 --> URI Class Initialized
INFO - 2019-08-31 11:24:53 --> Router Class Initialized
INFO - 2019-08-31 11:24:53 --> Output Class Initialized
INFO - 2019-08-31 11:24:53 --> Security Class Initialized
DEBUG - 2019-08-31 11:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:24:53 --> Input Class Initialized
INFO - 2019-08-31 11:24:53 --> Language Class Initialized
INFO - 2019-08-31 11:24:53 --> Loader Class Initialized
INFO - 2019-08-31 11:24:53 --> Helper loaded: url_helper
INFO - 2019-08-31 11:24:53 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:24:54 --> Controller Class Initialized
INFO - 2019-08-31 11:24:54 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:24:54 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:24:54 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:24:54 --> Final output sent to browser
DEBUG - 2019-08-31 11:24:54 --> Total execution time: 1.1002
INFO - 2019-08-31 11:24:55 --> Config Class Initialized
INFO - 2019-08-31 11:24:55 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:24:55 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:24:55 --> Utf8 Class Initialized
INFO - 2019-08-31 11:24:55 --> URI Class Initialized
INFO - 2019-08-31 11:24:55 --> Router Class Initialized
INFO - 2019-08-31 11:24:55 --> Output Class Initialized
INFO - 2019-08-31 11:24:55 --> Security Class Initialized
DEBUG - 2019-08-31 11:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:24:55 --> Input Class Initialized
INFO - 2019-08-31 11:24:55 --> Language Class Initialized
INFO - 2019-08-31 11:24:55 --> Loader Class Initialized
INFO - 2019-08-31 11:24:55 --> Helper loaded: url_helper
INFO - 2019-08-31 11:24:55 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:24:56 --> Controller Class Initialized
DEBUG - 2019-08-31 11:24:56 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:24:56 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:24:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:24:56 --> Model "Template_model" initialized
INFO - 2019-08-31 11:24:56 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 11:24:57 --> Final output sent to browser
DEBUG - 2019-08-31 11:24:57 --> Total execution time: 2.3000
INFO - 2019-08-31 11:28:27 --> Config Class Initialized
INFO - 2019-08-31 11:28:27 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:28:27 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:28:27 --> Utf8 Class Initialized
INFO - 2019-08-31 11:28:27 --> URI Class Initialized
INFO - 2019-08-31 11:28:27 --> Router Class Initialized
INFO - 2019-08-31 11:28:27 --> Output Class Initialized
INFO - 2019-08-31 11:28:27 --> Security Class Initialized
DEBUG - 2019-08-31 11:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:28:27 --> Input Class Initialized
INFO - 2019-08-31 11:28:27 --> Language Class Initialized
INFO - 2019-08-31 11:28:27 --> Loader Class Initialized
INFO - 2019-08-31 11:28:27 --> Helper loaded: url_helper
INFO - 2019-08-31 11:28:27 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:28:56 --> Controller Class Initialized
INFO - 2019-08-31 11:28:56 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:28:56 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:28:56 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:28:56 --> Final output sent to browser
DEBUG - 2019-08-31 11:28:56 --> Total execution time: 29.2549
INFO - 2019-08-31 11:28:57 --> Config Class Initialized
INFO - 2019-08-31 11:28:57 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:28:57 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:28:57 --> Utf8 Class Initialized
INFO - 2019-08-31 11:28:57 --> URI Class Initialized
INFO - 2019-08-31 11:28:57 --> Router Class Initialized
INFO - 2019-08-31 11:28:57 --> Output Class Initialized
INFO - 2019-08-31 11:28:57 --> Security Class Initialized
DEBUG - 2019-08-31 11:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:28:57 --> Input Class Initialized
INFO - 2019-08-31 11:28:57 --> Language Class Initialized
INFO - 2019-08-31 11:28:57 --> Loader Class Initialized
INFO - 2019-08-31 11:28:57 --> Helper loaded: url_helper
INFO - 2019-08-31 11:28:57 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:29:03 --> Controller Class Initialized
DEBUG - 2019-08-31 11:29:03 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:29:03 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:29:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:29:03 --> Model "Template_model" initialized
INFO - 2019-08-31 11:29:03 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 11:29:05 --> Final output sent to browser
DEBUG - 2019-08-31 11:29:05 --> Total execution time: 7.6201
INFO - 2019-08-31 11:29:53 --> Config Class Initialized
INFO - 2019-08-31 11:29:53 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:29:53 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:29:53 --> Utf8 Class Initialized
INFO - 2019-08-31 11:29:53 --> URI Class Initialized
INFO - 2019-08-31 11:29:53 --> Router Class Initialized
INFO - 2019-08-31 11:29:53 --> Output Class Initialized
INFO - 2019-08-31 11:29:53 --> Security Class Initialized
DEBUG - 2019-08-31 11:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:29:53 --> Input Class Initialized
INFO - 2019-08-31 11:29:53 --> Language Class Initialized
INFO - 2019-08-31 11:29:53 --> Loader Class Initialized
INFO - 2019-08-31 11:29:53 --> Helper loaded: url_helper
INFO - 2019-08-31 11:29:53 --> Database Driver Class Initialized
INFO - 2019-08-31 11:30:12 --> Config Class Initialized
INFO - 2019-08-31 11:30:12 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:30:12 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:30:12 --> Utf8 Class Initialized
INFO - 2019-08-31 11:30:12 --> URI Class Initialized
INFO - 2019-08-31 11:30:12 --> Router Class Initialized
INFO - 2019-08-31 11:30:12 --> Output Class Initialized
INFO - 2019-08-31 11:30:12 --> Security Class Initialized
DEBUG - 2019-08-31 11:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:30:12 --> Input Class Initialized
INFO - 2019-08-31 11:30:12 --> Language Class Initialized
INFO - 2019-08-31 11:30:12 --> Loader Class Initialized
INFO - 2019-08-31 11:30:12 --> Helper loaded: url_helper
INFO - 2019-08-31 11:30:12 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:30:16 --> Controller Class Initialized
INFO - 2019-08-31 11:30:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:30:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 11:30:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:30:16 --> Final output sent to browser
DEBUG - 2019-08-31 11:30:16 --> Total execution time: 23.1832
DEBUG - 2019-08-31 11:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:30:27 --> Controller Class Initialized
INFO - 2019-08-31 11:30:27 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:30:27 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:30:27 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:30:27 --> Final output sent to browser
DEBUG - 2019-08-31 11:30:27 --> Total execution time: 15.0716
INFO - 2019-08-31 11:30:28 --> Config Class Initialized
INFO - 2019-08-31 11:30:28 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:30:28 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:30:28 --> Utf8 Class Initialized
INFO - 2019-08-31 11:30:28 --> URI Class Initialized
INFO - 2019-08-31 11:30:28 --> Router Class Initialized
INFO - 2019-08-31 11:30:28 --> Output Class Initialized
INFO - 2019-08-31 11:30:28 --> Security Class Initialized
DEBUG - 2019-08-31 11:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:30:28 --> Input Class Initialized
INFO - 2019-08-31 11:30:28 --> Language Class Initialized
INFO - 2019-08-31 11:30:28 --> Loader Class Initialized
INFO - 2019-08-31 11:30:28 --> Helper loaded: url_helper
INFO - 2019-08-31 11:30:28 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:30:57 --> Controller Class Initialized
DEBUG - 2019-08-31 11:30:57 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:30:57 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:30:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:30:57 --> Model "Template_model" initialized
INFO - 2019-08-31 11:30:57 --> Model "Khang_sinh_model" initialized
ERROR - 2019-08-31 11:31:08 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 307
INFO - 2019-08-31 11:32:25 --> Config Class Initialized
INFO - 2019-08-31 11:32:25 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:32:25 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:32:25 --> Utf8 Class Initialized
INFO - 2019-08-31 11:32:25 --> URI Class Initialized
INFO - 2019-08-31 11:32:25 --> Router Class Initialized
INFO - 2019-08-31 11:32:25 --> Output Class Initialized
INFO - 2019-08-31 11:32:25 --> Security Class Initialized
DEBUG - 2019-08-31 11:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:32:25 --> Input Class Initialized
INFO - 2019-08-31 11:32:25 --> Language Class Initialized
INFO - 2019-08-31 11:32:25 --> Loader Class Initialized
INFO - 2019-08-31 11:32:25 --> Helper loaded: url_helper
INFO - 2019-08-31 11:32:25 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:32:26 --> Controller Class Initialized
INFO - 2019-08-31 11:32:26 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:32:26 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:32:26 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:32:26 --> Final output sent to browser
DEBUG - 2019-08-31 11:32:26 --> Total execution time: 1.1332
INFO - 2019-08-31 11:32:26 --> Config Class Initialized
INFO - 2019-08-31 11:32:26 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:32:26 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:32:26 --> Utf8 Class Initialized
INFO - 2019-08-31 11:32:26 --> URI Class Initialized
INFO - 2019-08-31 11:32:26 --> Router Class Initialized
INFO - 2019-08-31 11:32:26 --> Output Class Initialized
INFO - 2019-08-31 11:32:26 --> Security Class Initialized
DEBUG - 2019-08-31 11:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:32:26 --> Input Class Initialized
INFO - 2019-08-31 11:32:26 --> Language Class Initialized
INFO - 2019-08-31 11:32:26 --> Loader Class Initialized
INFO - 2019-08-31 11:32:26 --> Helper loaded: url_helper
INFO - 2019-08-31 11:32:26 --> Database Driver Class Initialized
INFO - 2019-08-31 11:32:31 --> Config Class Initialized
INFO - 2019-08-31 11:32:31 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:32:31 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:32:31 --> Utf8 Class Initialized
INFO - 2019-08-31 11:32:31 --> URI Class Initialized
INFO - 2019-08-31 11:32:31 --> Router Class Initialized
INFO - 2019-08-31 11:32:31 --> Output Class Initialized
INFO - 2019-08-31 11:32:31 --> Security Class Initialized
DEBUG - 2019-08-31 11:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:32:31 --> Input Class Initialized
INFO - 2019-08-31 11:32:31 --> Language Class Initialized
INFO - 2019-08-31 11:32:31 --> Loader Class Initialized
INFO - 2019-08-31 11:32:31 --> Helper loaded: url_helper
INFO - 2019-08-31 11:32:31 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:32:32 --> Controller Class Initialized
INFO - 2019-08-31 11:32:32 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:32:32 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:32:32 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:32:32 --> Final output sent to browser
DEBUG - 2019-08-31 11:32:32 --> Total execution time: 1.1012
INFO - 2019-08-31 11:32:32 --> Config Class Initialized
INFO - 2019-08-31 11:32:32 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:32:32 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:32:32 --> Utf8 Class Initialized
INFO - 2019-08-31 11:32:32 --> URI Class Initialized
INFO - 2019-08-31 11:32:32 --> Router Class Initialized
INFO - 2019-08-31 11:32:32 --> Output Class Initialized
INFO - 2019-08-31 11:32:32 --> Security Class Initialized
DEBUG - 2019-08-31 11:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:32:32 --> Input Class Initialized
INFO - 2019-08-31 11:32:32 --> Language Class Initialized
INFO - 2019-08-31 11:32:32 --> Loader Class Initialized
INFO - 2019-08-31 11:32:32 --> Helper loaded: url_helper
INFO - 2019-08-31 11:32:32 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:32:42 --> Controller Class Initialized
DEBUG - 2019-08-31 11:32:42 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:32:42 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:32:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:32:42 --> Model "Template_model" initialized
INFO - 2019-08-31 11:32:42 --> Model "Khang_sinh_model" initialized
DEBUG - 2019-08-31 11:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:32:56 --> Config Class Initialized
INFO - 2019-08-31 11:32:56 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:32:56 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:32:56 --> Utf8 Class Initialized
INFO - 2019-08-31 11:32:56 --> URI Class Initialized
INFO - 2019-08-31 11:32:56 --> Router Class Initialized
INFO - 2019-08-31 11:32:56 --> Output Class Initialized
INFO - 2019-08-31 11:32:56 --> Security Class Initialized
DEBUG - 2019-08-31 11:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:32:56 --> Input Class Initialized
INFO - 2019-08-31 11:32:56 --> Language Class Initialized
INFO - 2019-08-31 11:32:56 --> Loader Class Initialized
INFO - 2019-08-31 11:32:56 --> Helper loaded: url_helper
INFO - 2019-08-31 11:32:56 --> Database Driver Class Initialized
ERROR - 2019-08-31 11:32:59 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 307
INFO - 2019-08-31 11:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:32:59 --> Controller Class Initialized
DEBUG - 2019-08-31 11:32:59 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:32:59 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:32:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:32:59 --> Model "Template_model" initialized
INFO - 2019-08-31 11:32:59 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 11:33:00 --> Final output sent to browser
DEBUG - 2019-08-31 11:33:00 --> Total execution time: 27.5329
DEBUG - 2019-08-31 11:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:33:12 --> Controller Class Initialized
INFO - 2019-08-31 11:33:12 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:33:12 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 11:33:12 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:33:12 --> Final output sent to browser
DEBUG - 2019-08-31 11:33:12 --> Total execution time: 15.1211
INFO - 2019-08-31 11:33:17 --> Config Class Initialized
INFO - 2019-08-31 11:33:17 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:33:17 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:33:17 --> Utf8 Class Initialized
INFO - 2019-08-31 11:33:17 --> URI Class Initialized
INFO - 2019-08-31 11:33:17 --> Router Class Initialized
INFO - 2019-08-31 11:33:17 --> Output Class Initialized
INFO - 2019-08-31 11:33:17 --> Security Class Initialized
DEBUG - 2019-08-31 11:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:33:17 --> Input Class Initialized
INFO - 2019-08-31 11:33:17 --> Language Class Initialized
INFO - 2019-08-31 11:33:17 --> Loader Class Initialized
INFO - 2019-08-31 11:33:17 --> Helper loaded: url_helper
INFO - 2019-08-31 11:33:17 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:33:18 --> Controller Class Initialized
INFO - 2019-08-31 11:33:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:33:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:33:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:33:18 --> Final output sent to browser
DEBUG - 2019-08-31 11:33:18 --> Total execution time: 1.1135
INFO - 2019-08-31 11:33:18 --> Config Class Initialized
INFO - 2019-08-31 11:33:18 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:33:18 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:33:18 --> Utf8 Class Initialized
INFO - 2019-08-31 11:33:18 --> URI Class Initialized
INFO - 2019-08-31 11:33:18 --> Router Class Initialized
INFO - 2019-08-31 11:33:18 --> Output Class Initialized
INFO - 2019-08-31 11:33:18 --> Security Class Initialized
DEBUG - 2019-08-31 11:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:33:18 --> Input Class Initialized
INFO - 2019-08-31 11:33:18 --> Language Class Initialized
INFO - 2019-08-31 11:33:18 --> Loader Class Initialized
INFO - 2019-08-31 11:33:18 --> Helper loaded: url_helper
INFO - 2019-08-31 11:33:18 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:33:47 --> Controller Class Initialized
DEBUG - 2019-08-31 11:33:47 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:33:47 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:33:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:33:47 --> Model "Template_model" initialized
INFO - 2019-08-31 11:33:47 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 11:33:48 --> Final output sent to browser
DEBUG - 2019-08-31 11:33:48 --> Total execution time: 29.7514
INFO - 2019-08-31 11:34:55 --> Config Class Initialized
INFO - 2019-08-31 11:34:55 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:34:55 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:34:55 --> Utf8 Class Initialized
INFO - 2019-08-31 11:34:55 --> URI Class Initialized
INFO - 2019-08-31 11:34:55 --> Router Class Initialized
INFO - 2019-08-31 11:34:55 --> Output Class Initialized
INFO - 2019-08-31 11:34:55 --> Security Class Initialized
DEBUG - 2019-08-31 11:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:34:55 --> Input Class Initialized
INFO - 2019-08-31 11:34:55 --> Language Class Initialized
INFO - 2019-08-31 11:34:55 --> Loader Class Initialized
INFO - 2019-08-31 11:34:55 --> Helper loaded: url_helper
INFO - 2019-08-31 11:34:55 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:35:24 --> Controller Class Initialized
INFO - 2019-08-31 11:35:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:35:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 11:35:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:35:24 --> Final output sent to browser
DEBUG - 2019-08-31 11:35:24 --> Total execution time: 29.1288
INFO - 2019-08-31 11:36:18 --> Config Class Initialized
INFO - 2019-08-31 11:36:18 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:36:18 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:36:18 --> Utf8 Class Initialized
INFO - 2019-08-31 11:36:18 --> URI Class Initialized
INFO - 2019-08-31 11:36:18 --> Router Class Initialized
INFO - 2019-08-31 11:36:18 --> Output Class Initialized
INFO - 2019-08-31 11:36:18 --> Security Class Initialized
DEBUG - 2019-08-31 11:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:36:18 --> Input Class Initialized
INFO - 2019-08-31 11:36:18 --> Language Class Initialized
INFO - 2019-08-31 11:36:18 --> Loader Class Initialized
INFO - 2019-08-31 11:36:18 --> Helper loaded: url_helper
INFO - 2019-08-31 11:36:18 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:36:19 --> Controller Class Initialized
INFO - 2019-08-31 11:36:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:36:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 11:36:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:36:19 --> Final output sent to browser
DEBUG - 2019-08-31 11:36:19 --> Total execution time: 1.3792
INFO - 2019-08-31 11:36:22 --> Config Class Initialized
INFO - 2019-08-31 11:36:22 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:36:22 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:36:22 --> Utf8 Class Initialized
INFO - 2019-08-31 11:36:22 --> URI Class Initialized
INFO - 2019-08-31 11:36:22 --> Router Class Initialized
INFO - 2019-08-31 11:36:22 --> Output Class Initialized
INFO - 2019-08-31 11:36:22 --> Security Class Initialized
DEBUG - 2019-08-31 11:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:36:22 --> Input Class Initialized
INFO - 2019-08-31 11:36:22 --> Language Class Initialized
INFO - 2019-08-31 11:36:22 --> Loader Class Initialized
INFO - 2019-08-31 11:36:22 --> Helper loaded: url_helper
INFO - 2019-08-31 11:36:22 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:36:51 --> Controller Class Initialized
INFO - 2019-08-31 11:36:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:36:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:36:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:36:51 --> Final output sent to browser
DEBUG - 2019-08-31 11:36:51 --> Total execution time: 29.2173
INFO - 2019-08-31 11:36:51 --> Config Class Initialized
INFO - 2019-08-31 11:36:51 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:36:51 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:36:51 --> Utf8 Class Initialized
INFO - 2019-08-31 11:36:51 --> URI Class Initialized
INFO - 2019-08-31 11:36:51 --> Router Class Initialized
INFO - 2019-08-31 11:36:51 --> Output Class Initialized
INFO - 2019-08-31 11:36:51 --> Security Class Initialized
DEBUG - 2019-08-31 11:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:36:51 --> Input Class Initialized
INFO - 2019-08-31 11:36:51 --> Language Class Initialized
INFO - 2019-08-31 11:36:51 --> Loader Class Initialized
INFO - 2019-08-31 11:36:51 --> Helper loaded: url_helper
INFO - 2019-08-31 11:36:51 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:36:52 --> Controller Class Initialized
DEBUG - 2019-08-31 11:36:52 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:36:52 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:36:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:36:52 --> Model "Template_model" initialized
INFO - 2019-08-31 11:36:52 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 11:36:55 --> Final output sent to browser
DEBUG - 2019-08-31 11:36:55 --> Total execution time: 4.5883
INFO - 2019-08-31 11:37:06 --> Config Class Initialized
INFO - 2019-08-31 11:37:06 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:37:06 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:37:06 --> Utf8 Class Initialized
INFO - 2019-08-31 11:37:06 --> URI Class Initialized
INFO - 2019-08-31 11:37:06 --> Router Class Initialized
INFO - 2019-08-31 11:37:06 --> Output Class Initialized
INFO - 2019-08-31 11:37:06 --> Security Class Initialized
DEBUG - 2019-08-31 11:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:37:06 --> Input Class Initialized
INFO - 2019-08-31 11:37:06 --> Language Class Initialized
INFO - 2019-08-31 11:37:06 --> Loader Class Initialized
INFO - 2019-08-31 11:37:06 --> Helper loaded: url_helper
INFO - 2019-08-31 11:37:06 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:37:07 --> Controller Class Initialized
INFO - 2019-08-31 11:37:07 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:37:07 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 11:37:07 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:37:07 --> Final output sent to browser
DEBUG - 2019-08-31 11:37:07 --> Total execution time: 1.0835
INFO - 2019-08-31 11:37:21 --> Config Class Initialized
INFO - 2019-08-31 11:37:21 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:37:21 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:37:21 --> Utf8 Class Initialized
INFO - 2019-08-31 11:37:21 --> URI Class Initialized
INFO - 2019-08-31 11:37:21 --> Router Class Initialized
INFO - 2019-08-31 11:37:21 --> Output Class Initialized
INFO - 2019-08-31 11:37:21 --> Security Class Initialized
DEBUG - 2019-08-31 11:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:37:21 --> Input Class Initialized
INFO - 2019-08-31 11:37:21 --> Language Class Initialized
INFO - 2019-08-31 11:37:21 --> Loader Class Initialized
INFO - 2019-08-31 11:37:21 --> Helper loaded: url_helper
INFO - 2019-08-31 11:37:21 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:37:22 --> Controller Class Initialized
INFO - 2019-08-31 11:37:22 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:37:22 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:37:22 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:37:22 --> Final output sent to browser
DEBUG - 2019-08-31 11:37:22 --> Total execution time: 1.0655
INFO - 2019-08-31 11:37:22 --> Config Class Initialized
INFO - 2019-08-31 11:37:22 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:37:22 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:37:22 --> Utf8 Class Initialized
INFO - 2019-08-31 11:37:22 --> URI Class Initialized
INFO - 2019-08-31 11:37:22 --> Router Class Initialized
INFO - 2019-08-31 11:37:22 --> Output Class Initialized
INFO - 2019-08-31 11:37:22 --> Security Class Initialized
DEBUG - 2019-08-31 11:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:37:22 --> Input Class Initialized
INFO - 2019-08-31 11:37:22 --> Language Class Initialized
INFO - 2019-08-31 11:37:22 --> Loader Class Initialized
INFO - 2019-08-31 11:37:22 --> Helper loaded: url_helper
INFO - 2019-08-31 11:37:22 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:37:24 --> Controller Class Initialized
DEBUG - 2019-08-31 11:37:24 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:37:24 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:37:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:37:24 --> Model "Template_model" initialized
INFO - 2019-08-31 11:37:24 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 11:37:24 --> Final output sent to browser
DEBUG - 2019-08-31 11:37:24 --> Total execution time: 1.7080
INFO - 2019-08-31 11:38:08 --> Config Class Initialized
INFO - 2019-08-31 11:38:08 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:38:08 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:38:08 --> Utf8 Class Initialized
INFO - 2019-08-31 11:38:08 --> URI Class Initialized
INFO - 2019-08-31 11:38:08 --> Router Class Initialized
INFO - 2019-08-31 11:38:08 --> Output Class Initialized
INFO - 2019-08-31 11:38:08 --> Security Class Initialized
DEBUG - 2019-08-31 11:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:38:08 --> Input Class Initialized
INFO - 2019-08-31 11:38:08 --> Language Class Initialized
INFO - 2019-08-31 11:38:08 --> Loader Class Initialized
INFO - 2019-08-31 11:38:08 --> Helper loaded: url_helper
INFO - 2019-08-31 11:38:08 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:38:23 --> Controller Class Initialized
INFO - 2019-08-31 11:38:23 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:38:23 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:38:23 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:38:23 --> Final output sent to browser
DEBUG - 2019-08-31 11:38:23 --> Total execution time: 15.1274
INFO - 2019-08-31 11:38:40 --> Config Class Initialized
INFO - 2019-08-31 11:38:40 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:38:40 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:38:40 --> Utf8 Class Initialized
INFO - 2019-08-31 11:38:40 --> URI Class Initialized
INFO - 2019-08-31 11:38:40 --> Router Class Initialized
INFO - 2019-08-31 11:38:40 --> Output Class Initialized
INFO - 2019-08-31 11:38:40 --> Security Class Initialized
DEBUG - 2019-08-31 11:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:38:40 --> Input Class Initialized
INFO - 2019-08-31 11:38:40 --> Language Class Initialized
INFO - 2019-08-31 11:38:40 --> Loader Class Initialized
INFO - 2019-08-31 11:38:40 --> Helper loaded: url_helper
INFO - 2019-08-31 11:38:40 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:38:49 --> Controller Class Initialized
INFO - 2019-08-31 11:38:49 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:38:49 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:38:49 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:38:49 --> Final output sent to browser
DEBUG - 2019-08-31 11:38:49 --> Total execution time: 9.0891
INFO - 2019-08-31 11:39:44 --> Config Class Initialized
INFO - 2019-08-31 11:39:44 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:39:44 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:39:44 --> Utf8 Class Initialized
INFO - 2019-08-31 11:39:44 --> URI Class Initialized
INFO - 2019-08-31 11:39:44 --> Router Class Initialized
INFO - 2019-08-31 11:39:44 --> Output Class Initialized
INFO - 2019-08-31 11:39:44 --> Security Class Initialized
DEBUG - 2019-08-31 11:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:39:44 --> Input Class Initialized
INFO - 2019-08-31 11:39:44 --> Language Class Initialized
INFO - 2019-08-31 11:39:44 --> Loader Class Initialized
INFO - 2019-08-31 11:39:44 --> Helper loaded: url_helper
INFO - 2019-08-31 11:39:44 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:39:45 --> Controller Class Initialized
INFO - 2019-08-31 11:39:45 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:39:45 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:39:45 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:39:45 --> Final output sent to browser
DEBUG - 2019-08-31 11:39:45 --> Total execution time: 1.1312
INFO - 2019-08-31 11:39:46 --> Config Class Initialized
INFO - 2019-08-31 11:39:46 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:39:46 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:39:46 --> Utf8 Class Initialized
INFO - 2019-08-31 11:39:46 --> URI Class Initialized
INFO - 2019-08-31 11:39:46 --> Router Class Initialized
INFO - 2019-08-31 11:39:46 --> Output Class Initialized
INFO - 2019-08-31 11:39:46 --> Security Class Initialized
DEBUG - 2019-08-31 11:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:39:46 --> Input Class Initialized
INFO - 2019-08-31 11:39:46 --> Language Class Initialized
INFO - 2019-08-31 11:39:46 --> Loader Class Initialized
INFO - 2019-08-31 11:39:46 --> Helper loaded: url_helper
INFO - 2019-08-31 11:39:46 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:40:15 --> Controller Class Initialized
DEBUG - 2019-08-31 11:40:15 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:40:15 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:40:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:40:15 --> Model "Template_model" initialized
INFO - 2019-08-31 11:40:15 --> Model "Khang_sinh_model" initialized
ERROR - 2019-08-31 11:40:16 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 307
INFO - 2019-08-31 11:41:45 --> Config Class Initialized
INFO - 2019-08-31 11:41:45 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:41:45 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:41:45 --> Utf8 Class Initialized
INFO - 2019-08-31 11:41:45 --> URI Class Initialized
INFO - 2019-08-31 11:41:45 --> Router Class Initialized
INFO - 2019-08-31 11:41:45 --> Output Class Initialized
INFO - 2019-08-31 11:41:45 --> Security Class Initialized
DEBUG - 2019-08-31 11:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:41:45 --> Input Class Initialized
INFO - 2019-08-31 11:41:45 --> Language Class Initialized
INFO - 2019-08-31 11:41:45 --> Loader Class Initialized
INFO - 2019-08-31 11:41:45 --> Helper loaded: url_helper
INFO - 2019-08-31 11:41:45 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:41:51 --> Controller Class Initialized
INFO - 2019-08-31 11:41:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:41:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:41:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:41:51 --> Final output sent to browser
DEBUG - 2019-08-31 11:41:51 --> Total execution time: 6.1123
INFO - 2019-08-31 11:41:52 --> Config Class Initialized
INFO - 2019-08-31 11:41:52 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:41:52 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:41:52 --> Utf8 Class Initialized
INFO - 2019-08-31 11:41:52 --> URI Class Initialized
INFO - 2019-08-31 11:41:52 --> Router Class Initialized
INFO - 2019-08-31 11:41:52 --> Output Class Initialized
INFO - 2019-08-31 11:41:52 --> Security Class Initialized
DEBUG - 2019-08-31 11:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:41:52 --> Input Class Initialized
INFO - 2019-08-31 11:41:52 --> Language Class Initialized
INFO - 2019-08-31 11:41:52 --> Loader Class Initialized
INFO - 2019-08-31 11:41:52 --> Helper loaded: url_helper
INFO - 2019-08-31 11:41:52 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:41:53 --> Controller Class Initialized
DEBUG - 2019-08-31 11:41:53 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:41:53 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:41:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:41:53 --> Model "Template_model" initialized
INFO - 2019-08-31 11:41:53 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 11:41:53 --> Final output sent to browser
DEBUG - 2019-08-31 11:41:53 --> Total execution time: 1.6802
INFO - 2019-08-31 11:43:02 --> Config Class Initialized
INFO - 2019-08-31 11:43:02 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:43:02 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:43:02 --> Utf8 Class Initialized
INFO - 2019-08-31 11:43:02 --> URI Class Initialized
INFO - 2019-08-31 11:43:02 --> Router Class Initialized
INFO - 2019-08-31 11:43:02 --> Output Class Initialized
INFO - 2019-08-31 11:43:02 --> Security Class Initialized
DEBUG - 2019-08-31 11:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:43:02 --> Input Class Initialized
INFO - 2019-08-31 11:43:02 --> Language Class Initialized
INFO - 2019-08-31 11:43:02 --> Loader Class Initialized
INFO - 2019-08-31 11:43:02 --> Helper loaded: url_helper
INFO - 2019-08-31 11:43:02 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:43:08 --> Controller Class Initialized
INFO - 2019-08-31 11:43:08 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:43:08 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 11:43:08 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:43:08 --> Final output sent to browser
DEBUG - 2019-08-31 11:43:08 --> Total execution time: 6.0433
INFO - 2019-08-31 11:45:22 --> Config Class Initialized
INFO - 2019-08-31 11:45:22 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:45:22 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:45:22 --> Utf8 Class Initialized
INFO - 2019-08-31 11:45:22 --> URI Class Initialized
INFO - 2019-08-31 11:45:22 --> Router Class Initialized
INFO - 2019-08-31 11:45:22 --> Output Class Initialized
INFO - 2019-08-31 11:45:22 --> Security Class Initialized
DEBUG - 2019-08-31 11:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:45:22 --> Input Class Initialized
INFO - 2019-08-31 11:45:22 --> Language Class Initialized
INFO - 2019-08-31 11:45:22 --> Loader Class Initialized
INFO - 2019-08-31 11:45:22 --> Helper loaded: url_helper
INFO - 2019-08-31 11:45:22 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:45:23 --> Controller Class Initialized
INFO - 2019-08-31 11:45:23 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:45:23 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-08-31 11:45:23 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:45:23 --> Final output sent to browser
DEBUG - 2019-08-31 11:45:23 --> Total execution time: 1.0818
INFO - 2019-08-31 11:45:29 --> Config Class Initialized
INFO - 2019-08-31 11:45:29 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:45:29 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:45:29 --> Utf8 Class Initialized
INFO - 2019-08-31 11:45:29 --> URI Class Initialized
INFO - 2019-08-31 11:45:29 --> Router Class Initialized
INFO - 2019-08-31 11:45:29 --> Output Class Initialized
INFO - 2019-08-31 11:45:29 --> Security Class Initialized
DEBUG - 2019-08-31 11:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:45:29 --> Input Class Initialized
INFO - 2019-08-31 11:45:29 --> Language Class Initialized
INFO - 2019-08-31 11:45:29 --> Loader Class Initialized
INFO - 2019-08-31 11:45:29 --> Helper loaded: url_helper
INFO - 2019-08-31 11:45:29 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:45:35 --> Controller Class Initialized
INFO - 2019-08-31 11:45:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:45:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 11:45:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:45:35 --> Final output sent to browser
DEBUG - 2019-08-31 11:45:35 --> Total execution time: 6.1282
INFO - 2019-08-31 11:45:44 --> Config Class Initialized
INFO - 2019-08-31 11:45:44 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:45:44 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:45:44 --> Utf8 Class Initialized
INFO - 2019-08-31 11:45:44 --> URI Class Initialized
INFO - 2019-08-31 11:45:44 --> Router Class Initialized
INFO - 2019-08-31 11:45:44 --> Output Class Initialized
INFO - 2019-08-31 11:45:44 --> Security Class Initialized
DEBUG - 2019-08-31 11:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:45:44 --> Input Class Initialized
INFO - 2019-08-31 11:45:44 --> Language Class Initialized
INFO - 2019-08-31 11:45:44 --> Loader Class Initialized
INFO - 2019-08-31 11:45:44 --> Helper loaded: url_helper
INFO - 2019-08-31 11:45:44 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:45:50 --> Controller Class Initialized
INFO - 2019-08-31 11:45:50 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:45:50 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:45:50 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:45:50 --> Final output sent to browser
DEBUG - 2019-08-31 11:45:50 --> Total execution time: 6.0813
INFO - 2019-08-31 11:45:51 --> Config Class Initialized
INFO - 2019-08-31 11:45:51 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:45:51 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:45:51 --> Utf8 Class Initialized
INFO - 2019-08-31 11:45:51 --> URI Class Initialized
INFO - 2019-08-31 11:45:51 --> Router Class Initialized
INFO - 2019-08-31 11:45:51 --> Output Class Initialized
INFO - 2019-08-31 11:45:51 --> Security Class Initialized
DEBUG - 2019-08-31 11:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:45:51 --> Input Class Initialized
INFO - 2019-08-31 11:45:51 --> Language Class Initialized
INFO - 2019-08-31 11:45:51 --> Loader Class Initialized
INFO - 2019-08-31 11:45:51 --> Helper loaded: url_helper
INFO - 2019-08-31 11:45:51 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:46:20 --> Controller Class Initialized
DEBUG - 2019-08-31 11:46:20 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:46:20 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:46:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:46:20 --> Model "Template_model" initialized
INFO - 2019-08-31 11:46:20 --> Model "Khang_sinh_model" initialized
ERROR - 2019-08-31 11:46:21 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 307
INFO - 2019-08-31 11:48:38 --> Config Class Initialized
INFO - 2019-08-31 11:48:38 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:48:38 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:48:38 --> Utf8 Class Initialized
INFO - 2019-08-31 11:48:38 --> URI Class Initialized
INFO - 2019-08-31 11:48:38 --> Router Class Initialized
INFO - 2019-08-31 11:48:38 --> Output Class Initialized
INFO - 2019-08-31 11:48:38 --> Security Class Initialized
DEBUG - 2019-08-31 11:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:48:38 --> Input Class Initialized
INFO - 2019-08-31 11:48:38 --> Language Class Initialized
INFO - 2019-08-31 11:48:38 --> Loader Class Initialized
INFO - 2019-08-31 11:48:38 --> Helper loaded: url_helper
INFO - 2019-08-31 11:48:38 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:49:01 --> Controller Class Initialized
INFO - 2019-08-31 11:49:01 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:49:01 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:49:01 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:49:01 --> Final output sent to browser
DEBUG - 2019-08-31 11:49:01 --> Total execution time: 23.1048
INFO - 2019-08-31 11:49:02 --> Config Class Initialized
INFO - 2019-08-31 11:49:02 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:49:02 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:49:02 --> Utf8 Class Initialized
INFO - 2019-08-31 11:49:02 --> URI Class Initialized
INFO - 2019-08-31 11:49:02 --> Router Class Initialized
INFO - 2019-08-31 11:49:02 --> Output Class Initialized
INFO - 2019-08-31 11:49:02 --> Security Class Initialized
DEBUG - 2019-08-31 11:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:49:02 --> Input Class Initialized
INFO - 2019-08-31 11:49:02 --> Language Class Initialized
INFO - 2019-08-31 11:49:02 --> Loader Class Initialized
INFO - 2019-08-31 11:49:02 --> Helper loaded: url_helper
INFO - 2019-08-31 11:49:02 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:49:03 --> Controller Class Initialized
DEBUG - 2019-08-31 11:49:03 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:49:03 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:49:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:49:03 --> Model "Template_model" initialized
INFO - 2019-08-31 11:49:03 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 11:49:04 --> Final output sent to browser
DEBUG - 2019-08-31 11:49:04 --> Total execution time: 1.8731
INFO - 2019-08-31 11:50:00 --> Config Class Initialized
INFO - 2019-08-31 11:50:00 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:50:00 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:50:00 --> Utf8 Class Initialized
INFO - 2019-08-31 11:50:00 --> URI Class Initialized
INFO - 2019-08-31 11:50:00 --> Router Class Initialized
INFO - 2019-08-31 11:50:00 --> Output Class Initialized
INFO - 2019-08-31 11:50:00 --> Security Class Initialized
DEBUG - 2019-08-31 11:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:50:00 --> Input Class Initialized
INFO - 2019-08-31 11:50:00 --> Language Class Initialized
INFO - 2019-08-31 11:50:00 --> Loader Class Initialized
INFO - 2019-08-31 11:50:00 --> Helper loaded: url_helper
INFO - 2019-08-31 11:50:00 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:50:09 --> Controller Class Initialized
INFO - 2019-08-31 11:50:09 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:50:09 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:50:09 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:50:09 --> Final output sent to browser
DEBUG - 2019-08-31 11:50:09 --> Total execution time: 9.1052
INFO - 2019-08-31 11:50:10 --> Config Class Initialized
INFO - 2019-08-31 11:50:10 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:50:10 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:50:10 --> Utf8 Class Initialized
INFO - 2019-08-31 11:50:10 --> URI Class Initialized
INFO - 2019-08-31 11:50:10 --> Router Class Initialized
INFO - 2019-08-31 11:50:10 --> Output Class Initialized
INFO - 2019-08-31 11:50:10 --> Security Class Initialized
DEBUG - 2019-08-31 11:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:50:10 --> Input Class Initialized
INFO - 2019-08-31 11:50:10 --> Language Class Initialized
INFO - 2019-08-31 11:50:10 --> Loader Class Initialized
INFO - 2019-08-31 11:50:10 --> Helper loaded: url_helper
INFO - 2019-08-31 11:50:10 --> Database Driver Class Initialized
INFO - 2019-08-31 11:50:31 --> Config Class Initialized
INFO - 2019-08-31 11:50:31 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:50:31 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:50:31 --> Utf8 Class Initialized
INFO - 2019-08-31 11:50:31 --> URI Class Initialized
INFO - 2019-08-31 11:50:31 --> Router Class Initialized
INFO - 2019-08-31 11:50:31 --> Output Class Initialized
INFO - 2019-08-31 11:50:31 --> Security Class Initialized
DEBUG - 2019-08-31 11:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:50:31 --> Input Class Initialized
INFO - 2019-08-31 11:50:31 --> Language Class Initialized
INFO - 2019-08-31 11:50:31 --> Loader Class Initialized
INFO - 2019-08-31 11:50:31 --> Helper loaded: url_helper
INFO - 2019-08-31 11:50:31 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:50:32 --> Controller Class Initialized
INFO - 2019-08-31 11:50:32 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:50:32 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:50:32 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:50:32 --> Final output sent to browser
DEBUG - 2019-08-31 11:50:32 --> Total execution time: 1.1416
INFO - 2019-08-31 11:50:32 --> Config Class Initialized
INFO - 2019-08-31 11:50:32 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:50:32 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:50:32 --> Utf8 Class Initialized
INFO - 2019-08-31 11:50:32 --> URI Class Initialized
INFO - 2019-08-31 11:50:32 --> Router Class Initialized
INFO - 2019-08-31 11:50:32 --> Output Class Initialized
INFO - 2019-08-31 11:50:32 --> Security Class Initialized
DEBUG - 2019-08-31 11:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:50:32 --> Input Class Initialized
INFO - 2019-08-31 11:50:32 --> Language Class Initialized
INFO - 2019-08-31 11:50:32 --> Loader Class Initialized
INFO - 2019-08-31 11:50:32 --> Helper loaded: url_helper
INFO - 2019-08-31 11:50:32 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:50:39 --> Controller Class Initialized
DEBUG - 2019-08-31 11:50:39 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:50:39 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:50:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:50:39 --> Model "Template_model" initialized
INFO - 2019-08-31 11:50:39 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 11:50:39 --> Final output sent to browser
DEBUG - 2019-08-31 11:50:39 --> Total execution time: 29.2668
DEBUG - 2019-08-31 11:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:51:02 --> Controller Class Initialized
DEBUG - 2019-08-31 11:51:02 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:51:02 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:51:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:51:02 --> Model "Template_model" initialized
INFO - 2019-08-31 11:51:02 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 11:51:02 --> Final output sent to browser
DEBUG - 2019-08-31 11:51:02 --> Total execution time: 29.3385
INFO - 2019-08-31 11:52:04 --> Config Class Initialized
INFO - 2019-08-31 11:52:04 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:52:04 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:52:04 --> Utf8 Class Initialized
INFO - 2019-08-31 11:52:04 --> URI Class Initialized
INFO - 2019-08-31 11:52:04 --> Router Class Initialized
INFO - 2019-08-31 11:52:04 --> Output Class Initialized
INFO - 2019-08-31 11:52:04 --> Security Class Initialized
DEBUG - 2019-08-31 11:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:52:04 --> Input Class Initialized
INFO - 2019-08-31 11:52:04 --> Language Class Initialized
INFO - 2019-08-31 11:52:04 --> Loader Class Initialized
INFO - 2019-08-31 11:52:04 --> Helper loaded: url_helper
INFO - 2019-08-31 11:52:04 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:52:05 --> Controller Class Initialized
INFO - 2019-08-31 11:52:05 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:52:05 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 11:52:05 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:52:05 --> Final output sent to browser
DEBUG - 2019-08-31 11:52:05 --> Total execution time: 1.1711
INFO - 2019-08-31 11:53:26 --> Config Class Initialized
INFO - 2019-08-31 11:53:26 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:53:26 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:53:26 --> Utf8 Class Initialized
INFO - 2019-08-31 11:53:26 --> URI Class Initialized
INFO - 2019-08-31 11:53:26 --> Router Class Initialized
INFO - 2019-08-31 11:53:26 --> Output Class Initialized
INFO - 2019-08-31 11:53:26 --> Security Class Initialized
DEBUG - 2019-08-31 11:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:53:27 --> Input Class Initialized
INFO - 2019-08-31 11:53:27 --> Language Class Initialized
INFO - 2019-08-31 11:53:27 --> Loader Class Initialized
INFO - 2019-08-31 11:53:27 --> Helper loaded: url_helper
INFO - 2019-08-31 11:53:27 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:53:28 --> Controller Class Initialized
INFO - 2019-08-31 11:53:28 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:53:28 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:53:28 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:53:28 --> Final output sent to browser
DEBUG - 2019-08-31 11:53:28 --> Total execution time: 1.1139
INFO - 2019-08-31 11:53:31 --> Config Class Initialized
INFO - 2019-08-31 11:53:31 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:53:31 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:53:31 --> Utf8 Class Initialized
INFO - 2019-08-31 11:53:31 --> URI Class Initialized
INFO - 2019-08-31 11:53:31 --> Router Class Initialized
INFO - 2019-08-31 11:53:31 --> Output Class Initialized
INFO - 2019-08-31 11:53:31 --> Security Class Initialized
DEBUG - 2019-08-31 11:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:53:31 --> Input Class Initialized
INFO - 2019-08-31 11:53:31 --> Language Class Initialized
INFO - 2019-08-31 11:53:31 --> Loader Class Initialized
INFO - 2019-08-31 11:53:31 --> Helper loaded: url_helper
INFO - 2019-08-31 11:53:31 --> Database Driver Class Initialized
INFO - 2019-08-31 11:53:32 --> Config Class Initialized
INFO - 2019-08-31 11:53:32 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:53:32 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:53:32 --> Utf8 Class Initialized
INFO - 2019-08-31 11:53:32 --> URI Class Initialized
INFO - 2019-08-31 11:53:32 --> Router Class Initialized
INFO - 2019-08-31 11:53:32 --> Output Class Initialized
INFO - 2019-08-31 11:53:32 --> Security Class Initialized
DEBUG - 2019-08-31 11:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:53:32 --> Input Class Initialized
INFO - 2019-08-31 11:53:32 --> Language Class Initialized
INFO - 2019-08-31 11:53:32 --> Loader Class Initialized
INFO - 2019-08-31 11:53:32 --> Helper loaded: url_helper
INFO - 2019-08-31 11:53:32 --> Database Driver Class Initialized
INFO - 2019-08-31 11:53:32 --> Config Class Initialized
INFO - 2019-08-31 11:53:32 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:53:32 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:53:32 --> Utf8 Class Initialized
INFO - 2019-08-31 11:53:32 --> URI Class Initialized
INFO - 2019-08-31 11:53:32 --> Router Class Initialized
INFO - 2019-08-31 11:53:32 --> Output Class Initialized
INFO - 2019-08-31 11:53:32 --> Security Class Initialized
DEBUG - 2019-08-31 11:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:53:32 --> Input Class Initialized
INFO - 2019-08-31 11:53:32 --> Language Class Initialized
INFO - 2019-08-31 11:53:32 --> Loader Class Initialized
INFO - 2019-08-31 11:53:32 --> Helper loaded: url_helper
INFO - 2019-08-31 11:53:32 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:53:33 --> Controller Class Initialized
INFO - 2019-08-31 11:53:33 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:53:33 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 11:53:33 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:53:33 --> Final output sent to browser
DEBUG - 2019-08-31 11:53:33 --> Total execution time: 1.1917
DEBUG - 2019-08-31 11:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:53:40 --> Controller Class Initialized
INFO - 2019-08-31 11:53:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:53:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:53:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:53:40 --> Final output sent to browser
DEBUG - 2019-08-31 11:53:40 --> Total execution time: 9.2280
DEBUG - 2019-08-31 11:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:53:42 --> Controller Class Initialized
INFO - 2019-08-31 11:53:42 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:53:42 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:53:42 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:53:42 --> Final output sent to browser
DEBUG - 2019-08-31 11:53:42 --> Total execution time: 9.2367
INFO - 2019-08-31 11:53:47 --> Config Class Initialized
INFO - 2019-08-31 11:53:47 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:53:47 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:53:47 --> Utf8 Class Initialized
INFO - 2019-08-31 11:53:47 --> URI Class Initialized
INFO - 2019-08-31 11:53:47 --> Router Class Initialized
INFO - 2019-08-31 11:53:47 --> Output Class Initialized
INFO - 2019-08-31 11:53:47 --> Security Class Initialized
DEBUG - 2019-08-31 11:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:53:47 --> Input Class Initialized
INFO - 2019-08-31 11:53:47 --> Language Class Initialized
INFO - 2019-08-31 11:53:47 --> Loader Class Initialized
INFO - 2019-08-31 11:53:47 --> Helper loaded: url_helper
INFO - 2019-08-31 11:53:47 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:53:56 --> Controller Class Initialized
INFO - 2019-08-31 11:53:56 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:53:56 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 11:53:56 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:53:56 --> Final output sent to browser
DEBUG - 2019-08-31 11:53:56 --> Total execution time: 9.1909
INFO - 2019-08-31 11:54:18 --> Config Class Initialized
INFO - 2019-08-31 11:54:18 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:54:18 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:54:18 --> Utf8 Class Initialized
INFO - 2019-08-31 11:54:18 --> URI Class Initialized
INFO - 2019-08-31 11:54:18 --> Router Class Initialized
INFO - 2019-08-31 11:54:18 --> Output Class Initialized
INFO - 2019-08-31 11:54:18 --> Security Class Initialized
DEBUG - 2019-08-31 11:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:54:18 --> Input Class Initialized
INFO - 2019-08-31 11:54:18 --> Language Class Initialized
INFO - 2019-08-31 11:54:18 --> Loader Class Initialized
INFO - 2019-08-31 11:54:18 --> Helper loaded: url_helper
INFO - 2019-08-31 11:54:18 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:54:19 --> Controller Class Initialized
INFO - 2019-08-31 11:54:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:54:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:54:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:54:19 --> Final output sent to browser
DEBUG - 2019-08-31 11:54:19 --> Total execution time: 1.1921
INFO - 2019-08-31 11:54:19 --> Config Class Initialized
INFO - 2019-08-31 11:54:19 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:54:19 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:54:19 --> Utf8 Class Initialized
INFO - 2019-08-31 11:54:19 --> URI Class Initialized
INFO - 2019-08-31 11:54:19 --> Router Class Initialized
INFO - 2019-08-31 11:54:19 --> Output Class Initialized
INFO - 2019-08-31 11:54:19 --> Security Class Initialized
DEBUG - 2019-08-31 11:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:54:19 --> Input Class Initialized
INFO - 2019-08-31 11:54:19 --> Language Class Initialized
INFO - 2019-08-31 11:54:19 --> Loader Class Initialized
INFO - 2019-08-31 11:54:19 --> Helper loaded: url_helper
INFO - 2019-08-31 11:54:19 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:54:26 --> Controller Class Initialized
DEBUG - 2019-08-31 11:54:26 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:54:26 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:54:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:54:26 --> Model "Template_model" initialized
INFO - 2019-08-31 11:54:26 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 11:54:26 --> Final output sent to browser
DEBUG - 2019-08-31 11:54:26 --> Total execution time: 6.5276
INFO - 2019-08-31 11:57:57 --> Config Class Initialized
INFO - 2019-08-31 11:57:57 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:57:57 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:57:57 --> Utf8 Class Initialized
INFO - 2019-08-31 11:57:57 --> URI Class Initialized
INFO - 2019-08-31 11:57:57 --> Router Class Initialized
INFO - 2019-08-31 11:57:57 --> Output Class Initialized
INFO - 2019-08-31 11:57:57 --> Security Class Initialized
DEBUG - 2019-08-31 11:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:57:57 --> Input Class Initialized
INFO - 2019-08-31 11:57:57 --> Language Class Initialized
INFO - 2019-08-31 11:57:57 --> Loader Class Initialized
INFO - 2019-08-31 11:57:57 --> Helper loaded: url_helper
INFO - 2019-08-31 11:57:57 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:57:58 --> Controller Class Initialized
INFO - 2019-08-31 11:57:58 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:57:58 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step3.php
INFO - 2019-08-31 11:57:58 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:57:58 --> Final output sent to browser
DEBUG - 2019-08-31 11:57:58 --> Total execution time: 1.0630
INFO - 2019-08-31 11:58:53 --> Config Class Initialized
INFO - 2019-08-31 11:58:53 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:58:53 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:58:53 --> Utf8 Class Initialized
INFO - 2019-08-31 11:58:53 --> URI Class Initialized
INFO - 2019-08-31 11:58:53 --> Router Class Initialized
INFO - 2019-08-31 11:58:53 --> Output Class Initialized
INFO - 2019-08-31 11:58:53 --> Security Class Initialized
DEBUG - 2019-08-31 11:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:58:53 --> Input Class Initialized
INFO - 2019-08-31 11:58:53 --> Language Class Initialized
INFO - 2019-08-31 11:58:53 --> Loader Class Initialized
INFO - 2019-08-31 11:58:53 --> Helper loaded: url_helper
INFO - 2019-08-31 11:58:53 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:58:59 --> Controller Class Initialized
INFO - 2019-08-31 11:58:59 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 11:58:59 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 11:58:59 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 11:58:59 --> Final output sent to browser
DEBUG - 2019-08-31 11:58:59 --> Total execution time: 6.2246
INFO - 2019-08-31 11:58:59 --> Config Class Initialized
INFO - 2019-08-31 11:58:59 --> Hooks Class Initialized
DEBUG - 2019-08-31 11:58:59 --> UTF-8 Support Enabled
INFO - 2019-08-31 11:58:59 --> Utf8 Class Initialized
INFO - 2019-08-31 11:58:59 --> URI Class Initialized
INFO - 2019-08-31 11:58:59 --> Router Class Initialized
INFO - 2019-08-31 11:58:59 --> Output Class Initialized
INFO - 2019-08-31 11:58:59 --> Security Class Initialized
DEBUG - 2019-08-31 11:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 11:58:59 --> Input Class Initialized
INFO - 2019-08-31 11:58:59 --> Language Class Initialized
INFO - 2019-08-31 11:58:59 --> Loader Class Initialized
INFO - 2019-08-31 11:58:59 --> Helper loaded: url_helper
INFO - 2019-08-31 11:58:59 --> Database Driver Class Initialized
DEBUG - 2019-08-31 11:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 11:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 11:59:19 --> Controller Class Initialized
DEBUG - 2019-08-31 11:59:19 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 11:59:19 --> Helper loaded: inflector_helper
INFO - 2019-08-31 11:59:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 11:59:19 --> Model "Template_model" initialized
INFO - 2019-08-31 11:59:19 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 11:59:20 --> Final output sent to browser
DEBUG - 2019-08-31 11:59:20 --> Total execution time: 20.7750
INFO - 2019-08-31 12:03:56 --> Config Class Initialized
INFO - 2019-08-31 12:03:56 --> Hooks Class Initialized
DEBUG - 2019-08-31 12:03:56 --> UTF-8 Support Enabled
INFO - 2019-08-31 12:03:56 --> Utf8 Class Initialized
INFO - 2019-08-31 12:03:56 --> URI Class Initialized
INFO - 2019-08-31 12:03:56 --> Router Class Initialized
INFO - 2019-08-31 12:03:56 --> Output Class Initialized
INFO - 2019-08-31 12:03:56 --> Security Class Initialized
DEBUG - 2019-08-31 12:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 12:03:56 --> Input Class Initialized
INFO - 2019-08-31 12:03:56 --> Language Class Initialized
INFO - 2019-08-31 12:03:56 --> Loader Class Initialized
INFO - 2019-08-31 12:03:56 --> Helper loaded: url_helper
INFO - 2019-08-31 12:03:56 --> Database Driver Class Initialized
DEBUG - 2019-08-31 12:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 12:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 12:04:02 --> Controller Class Initialized
INFO - 2019-08-31 12:04:02 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 12:04:02 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 12:04:02 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 12:04:02 --> Final output sent to browser
DEBUG - 2019-08-31 12:04:02 --> Total execution time: 6.1048
INFO - 2019-08-31 12:04:34 --> Config Class Initialized
INFO - 2019-08-31 12:04:34 --> Hooks Class Initialized
DEBUG - 2019-08-31 12:04:34 --> UTF-8 Support Enabled
INFO - 2019-08-31 12:04:34 --> Utf8 Class Initialized
INFO - 2019-08-31 12:04:34 --> URI Class Initialized
INFO - 2019-08-31 12:04:34 --> Router Class Initialized
INFO - 2019-08-31 12:04:34 --> Output Class Initialized
INFO - 2019-08-31 12:04:34 --> Security Class Initialized
DEBUG - 2019-08-31 12:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 12:04:34 --> Input Class Initialized
INFO - 2019-08-31 12:04:34 --> Language Class Initialized
INFO - 2019-08-31 12:04:34 --> Loader Class Initialized
INFO - 2019-08-31 12:04:34 --> Helper loaded: url_helper
INFO - 2019-08-31 12:04:34 --> Database Driver Class Initialized
DEBUG - 2019-08-31 12:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 12:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 12:04:35 --> Controller Class Initialized
INFO - 2019-08-31 12:04:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 12:04:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 12:04:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 12:04:35 --> Final output sent to browser
DEBUG - 2019-08-31 12:04:35 --> Total execution time: 1.1091
INFO - 2019-08-31 12:04:35 --> Config Class Initialized
INFO - 2019-08-31 12:04:35 --> Hooks Class Initialized
DEBUG - 2019-08-31 12:04:35 --> UTF-8 Support Enabled
INFO - 2019-08-31 12:04:35 --> Utf8 Class Initialized
INFO - 2019-08-31 12:04:35 --> URI Class Initialized
INFO - 2019-08-31 12:04:35 --> Router Class Initialized
INFO - 2019-08-31 12:04:35 --> Output Class Initialized
INFO - 2019-08-31 12:04:35 --> Security Class Initialized
DEBUG - 2019-08-31 12:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 12:04:35 --> Input Class Initialized
INFO - 2019-08-31 12:04:35 --> Language Class Initialized
INFO - 2019-08-31 12:04:35 --> Loader Class Initialized
INFO - 2019-08-31 12:04:35 --> Helper loaded: url_helper
INFO - 2019-08-31 12:04:35 --> Database Driver Class Initialized
DEBUG - 2019-08-31 12:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 12:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 12:04:42 --> Controller Class Initialized
DEBUG - 2019-08-31 12:04:42 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 12:04:42 --> Helper loaded: inflector_helper
INFO - 2019-08-31 12:04:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 12:04:42 --> Model "Template_model" initialized
INFO - 2019-08-31 12:04:42 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 12:04:42 --> Final output sent to browser
DEBUG - 2019-08-31 12:04:42 --> Total execution time: 6.9920
INFO - 2019-08-31 12:09:12 --> Config Class Initialized
INFO - 2019-08-31 12:09:12 --> Hooks Class Initialized
DEBUG - 2019-08-31 12:09:12 --> UTF-8 Support Enabled
INFO - 2019-08-31 12:09:12 --> Utf8 Class Initialized
INFO - 2019-08-31 12:09:12 --> URI Class Initialized
INFO - 2019-08-31 12:09:12 --> Router Class Initialized
INFO - 2019-08-31 12:09:12 --> Output Class Initialized
INFO - 2019-08-31 12:09:12 --> Security Class Initialized
DEBUG - 2019-08-31 12:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 12:09:12 --> Input Class Initialized
INFO - 2019-08-31 12:09:12 --> Language Class Initialized
INFO - 2019-08-31 12:09:12 --> Loader Class Initialized
INFO - 2019-08-31 12:09:12 --> Helper loaded: url_helper
INFO - 2019-08-31 12:09:12 --> Database Driver Class Initialized
DEBUG - 2019-08-31 12:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 12:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 12:09:27 --> Controller Class Initialized
INFO - 2019-08-31 12:09:27 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 12:09:27 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-31 12:09:27 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 12:09:27 --> Final output sent to browser
DEBUG - 2019-08-31 12:09:27 --> Total execution time: 15.1981
INFO - 2019-08-31 12:09:44 --> Config Class Initialized
INFO - 2019-08-31 12:09:44 --> Hooks Class Initialized
DEBUG - 2019-08-31 12:09:44 --> UTF-8 Support Enabled
INFO - 2019-08-31 12:09:44 --> Utf8 Class Initialized
INFO - 2019-08-31 12:09:44 --> URI Class Initialized
INFO - 2019-08-31 12:09:44 --> Router Class Initialized
INFO - 2019-08-31 12:09:44 --> Output Class Initialized
INFO - 2019-08-31 12:09:44 --> Security Class Initialized
DEBUG - 2019-08-31 12:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 12:09:44 --> Input Class Initialized
INFO - 2019-08-31 12:09:44 --> Language Class Initialized
INFO - 2019-08-31 12:09:44 --> Loader Class Initialized
INFO - 2019-08-31 12:09:44 --> Helper loaded: url_helper
INFO - 2019-08-31 12:09:44 --> Database Driver Class Initialized
DEBUG - 2019-08-31 12:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 12:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 12:09:51 --> Controller Class Initialized
INFO - 2019-08-31 12:09:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 12:09:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-31 12:09:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 12:09:51 --> Final output sent to browser
DEBUG - 2019-08-31 12:09:51 --> Total execution time: 6.3080
INFO - 2019-08-31 12:09:51 --> Config Class Initialized
INFO - 2019-08-31 12:09:51 --> Hooks Class Initialized
DEBUG - 2019-08-31 12:09:51 --> UTF-8 Support Enabled
INFO - 2019-08-31 12:09:51 --> Utf8 Class Initialized
INFO - 2019-08-31 12:09:51 --> URI Class Initialized
INFO - 2019-08-31 12:09:51 --> Router Class Initialized
INFO - 2019-08-31 12:09:51 --> Output Class Initialized
INFO - 2019-08-31 12:09:51 --> Security Class Initialized
DEBUG - 2019-08-31 12:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 12:09:51 --> Input Class Initialized
INFO - 2019-08-31 12:09:51 --> Language Class Initialized
INFO - 2019-08-31 12:09:51 --> Loader Class Initialized
INFO - 2019-08-31 12:09:51 --> Helper loaded: url_helper
INFO - 2019-08-31 12:09:51 --> Database Driver Class Initialized
DEBUG - 2019-08-31 12:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 12:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 12:09:52 --> Controller Class Initialized
DEBUG - 2019-08-31 12:09:52 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-31 12:09:52 --> Helper loaded: inflector_helper
INFO - 2019-08-31 12:09:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-31 12:09:52 --> Model "Template_model" initialized
INFO - 2019-08-31 12:09:52 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-31 12:09:53 --> Final output sent to browser
DEBUG - 2019-08-31 12:09:53 --> Total execution time: 1.8738
INFO - 2019-08-31 12:10:45 --> Config Class Initialized
INFO - 2019-08-31 12:10:45 --> Hooks Class Initialized
DEBUG - 2019-08-31 12:10:45 --> UTF-8 Support Enabled
INFO - 2019-08-31 12:10:45 --> Utf8 Class Initialized
INFO - 2019-08-31 12:10:45 --> URI Class Initialized
INFO - 2019-08-31 12:10:45 --> Router Class Initialized
INFO - 2019-08-31 12:10:45 --> Output Class Initialized
INFO - 2019-08-31 12:10:45 --> Security Class Initialized
DEBUG - 2019-08-31 12:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-31 12:10:45 --> Input Class Initialized
INFO - 2019-08-31 12:10:45 --> Language Class Initialized
INFO - 2019-08-31 12:10:45 --> Loader Class Initialized
INFO - 2019-08-31 12:10:45 --> Helper loaded: url_helper
INFO - 2019-08-31 12:10:45 --> Database Driver Class Initialized
DEBUG - 2019-08-31 12:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-31 12:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-31 12:11:00 --> Controller Class Initialized
INFO - 2019-08-31 12:11:00 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-31 12:11:00 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step3.php
INFO - 2019-08-31 12:11:00 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-31 12:11:00 --> Final output sent to browser
DEBUG - 2019-08-31 12:11:00 --> Total execution time: 15.1947
