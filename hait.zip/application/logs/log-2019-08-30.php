<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-08-30 10:30:18 --> Config Class Initialized
INFO - 2019-08-30 10:30:18 --> Hooks Class Initialized
DEBUG - 2019-08-30 10:30:18 --> UTF-8 Support Enabled
INFO - 2019-08-30 10:30:18 --> Utf8 Class Initialized
INFO - 2019-08-30 10:30:18 --> URI Class Initialized
INFO - 2019-08-30 10:30:18 --> Router Class Initialized
INFO - 2019-08-30 10:30:18 --> Output Class Initialized
INFO - 2019-08-30 10:30:18 --> Security Class Initialized
DEBUG - 2019-08-30 10:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 10:30:18 --> Input Class Initialized
INFO - 2019-08-30 10:30:18 --> Language Class Initialized
INFO - 2019-08-30 10:30:18 --> Loader Class Initialized
INFO - 2019-08-30 10:30:18 --> Helper loaded: url_helper
INFO - 2019-08-30 10:30:18 --> Database Driver Class Initialized
ERROR - 2019-08-30 10:30:53 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 203
INFO - 2019-08-30 10:34:12 --> Config Class Initialized
INFO - 2019-08-30 10:34:12 --> Hooks Class Initialized
DEBUG - 2019-08-30 10:34:12 --> UTF-8 Support Enabled
INFO - 2019-08-30 10:34:12 --> Utf8 Class Initialized
INFO - 2019-08-30 10:34:12 --> URI Class Initialized
INFO - 2019-08-30 10:34:12 --> Router Class Initialized
INFO - 2019-08-30 10:34:12 --> Output Class Initialized
INFO - 2019-08-30 10:34:12 --> Security Class Initialized
DEBUG - 2019-08-30 10:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 10:34:12 --> Input Class Initialized
INFO - 2019-08-30 10:34:12 --> Language Class Initialized
INFO - 2019-08-30 10:34:12 --> Loader Class Initialized
INFO - 2019-08-30 10:34:12 --> Helper loaded: url_helper
INFO - 2019-08-30 10:34:12 --> Database Driver Class Initialized
ERROR - 2019-08-30 10:34:42 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 203
INFO - 2019-08-30 15:05:00 --> Config Class Initialized
INFO - 2019-08-30 15:05:01 --> Hooks Class Initialized
DEBUG - 2019-08-30 15:05:01 --> UTF-8 Support Enabled
INFO - 2019-08-30 15:05:01 --> Utf8 Class Initialized
INFO - 2019-08-30 15:05:01 --> URI Class Initialized
INFO - 2019-08-30 15:05:01 --> Router Class Initialized
INFO - 2019-08-30 15:05:01 --> Output Class Initialized
INFO - 2019-08-30 15:05:01 --> Security Class Initialized
DEBUG - 2019-08-30 15:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 15:05:01 --> Input Class Initialized
INFO - 2019-08-30 15:05:01 --> Language Class Initialized
INFO - 2019-08-30 15:05:01 --> Loader Class Initialized
INFO - 2019-08-30 15:05:01 --> Helper loaded: url_helper
INFO - 2019-08-30 15:05:01 --> Database Driver Class Initialized
ERROR - 2019-08-30 15:05:35 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Programs\Xampp\htdocs\hait\system\core\Common.php 597
INFO - 2019-08-30 15:09:39 --> Config Class Initialized
INFO - 2019-08-30 15:09:39 --> Hooks Class Initialized
DEBUG - 2019-08-30 15:09:39 --> UTF-8 Support Enabled
INFO - 2019-08-30 15:09:39 --> Utf8 Class Initialized
INFO - 2019-08-30 15:09:39 --> URI Class Initialized
INFO - 2019-08-30 15:09:39 --> Router Class Initialized
INFO - 2019-08-30 15:09:39 --> Output Class Initialized
INFO - 2019-08-30 15:09:39 --> Security Class Initialized
DEBUG - 2019-08-30 15:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 15:09:39 --> Input Class Initialized
INFO - 2019-08-30 15:09:39 --> Language Class Initialized
INFO - 2019-08-30 15:09:39 --> Loader Class Initialized
INFO - 2019-08-30 15:09:39 --> Helper loaded: url_helper
INFO - 2019-08-30 15:09:39 --> Database Driver Class Initialized
DEBUG - 2019-08-30 15:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 15:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 15:09:40 --> Controller Class Initialized
INFO - 2019-08-30 15:09:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 15:09:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-08-30 15:09:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 15:09:40 --> Final output sent to browser
DEBUG - 2019-08-30 15:09:40 --> Total execution time: 1.3678
INFO - 2019-08-30 15:10:04 --> Config Class Initialized
INFO - 2019-08-30 15:10:04 --> Hooks Class Initialized
DEBUG - 2019-08-30 15:10:04 --> UTF-8 Support Enabled
INFO - 2019-08-30 15:10:04 --> Utf8 Class Initialized
INFO - 2019-08-30 15:10:04 --> URI Class Initialized
INFO - 2019-08-30 15:10:04 --> Router Class Initialized
INFO - 2019-08-30 15:10:04 --> Output Class Initialized
INFO - 2019-08-30 15:10:04 --> Security Class Initialized
DEBUG - 2019-08-30 15:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 15:10:04 --> Input Class Initialized
INFO - 2019-08-30 15:10:04 --> Language Class Initialized
INFO - 2019-08-30 15:10:04 --> Loader Class Initialized
INFO - 2019-08-30 15:10:04 --> Helper loaded: url_helper
INFO - 2019-08-30 15:10:04 --> Database Driver Class Initialized
DEBUG - 2019-08-30 15:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 15:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 15:10:05 --> Controller Class Initialized
DEBUG - 2019-08-30 15:10:05 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-30 15:10:05 --> Helper loaded: inflector_helper
INFO - 2019-08-30 15:10:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-30 15:10:05 --> Model "Form_model" initialized
INFO - 2019-08-30 15:10:10 --> Final output sent to browser
DEBUG - 2019-08-30 15:10:10 --> Total execution time: 6.3675
INFO - 2019-08-30 15:10:10 --> Config Class Initialized
INFO - 2019-08-30 15:10:10 --> Hooks Class Initialized
DEBUG - 2019-08-30 15:10:10 --> UTF-8 Support Enabled
INFO - 2019-08-30 15:10:10 --> Utf8 Class Initialized
INFO - 2019-08-30 15:10:10 --> URI Class Initialized
INFO - 2019-08-30 15:10:10 --> Router Class Initialized
INFO - 2019-08-30 15:10:10 --> Output Class Initialized
INFO - 2019-08-30 15:10:10 --> Security Class Initialized
DEBUG - 2019-08-30 15:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 15:10:10 --> Input Class Initialized
INFO - 2019-08-30 15:10:10 --> Language Class Initialized
INFO - 2019-08-30 15:10:10 --> Loader Class Initialized
INFO - 2019-08-30 15:10:10 --> Helper loaded: url_helper
INFO - 2019-08-30 15:10:10 --> Database Driver Class Initialized
DEBUG - 2019-08-30 15:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 15:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 15:10:14 --> Controller Class Initialized
INFO - 2019-08-30 15:10:14 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 15:10:14 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-30 15:10:14 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 15:10:14 --> Final output sent to browser
DEBUG - 2019-08-30 15:10:14 --> Total execution time: 3.3338
INFO - 2019-08-30 15:10:20 --> Config Class Initialized
INFO - 2019-08-30 15:10:20 --> Hooks Class Initialized
DEBUG - 2019-08-30 15:10:20 --> UTF-8 Support Enabled
INFO - 2019-08-30 15:10:20 --> Utf8 Class Initialized
INFO - 2019-08-30 15:10:20 --> URI Class Initialized
INFO - 2019-08-30 15:10:20 --> Router Class Initialized
INFO - 2019-08-30 15:10:20 --> Output Class Initialized
INFO - 2019-08-30 15:10:20 --> Security Class Initialized
DEBUG - 2019-08-30 15:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 15:10:20 --> Input Class Initialized
INFO - 2019-08-30 15:10:20 --> Language Class Initialized
INFO - 2019-08-30 15:10:20 --> Loader Class Initialized
INFO - 2019-08-30 15:10:20 --> Helper loaded: url_helper
INFO - 2019-08-30 15:10:20 --> Database Driver Class Initialized
DEBUG - 2019-08-30 15:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 15:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 15:10:22 --> Controller Class Initialized
INFO - 2019-08-30 15:10:22 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 15:10:22 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-30 15:10:22 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 15:10:22 --> Final output sent to browser
DEBUG - 2019-08-30 15:10:22 --> Total execution time: 1.7208
INFO - 2019-08-30 15:10:22 --> Config Class Initialized
INFO - 2019-08-30 15:10:22 --> Hooks Class Initialized
DEBUG - 2019-08-30 15:10:22 --> UTF-8 Support Enabled
INFO - 2019-08-30 15:10:22 --> Utf8 Class Initialized
INFO - 2019-08-30 15:10:22 --> URI Class Initialized
INFO - 2019-08-30 15:10:22 --> Router Class Initialized
INFO - 2019-08-30 15:10:22 --> Output Class Initialized
INFO - 2019-08-30 15:10:22 --> Security Class Initialized
DEBUG - 2019-08-30 15:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 15:10:22 --> Input Class Initialized
INFO - 2019-08-30 15:10:22 --> Language Class Initialized
INFO - 2019-08-30 15:10:22 --> Loader Class Initialized
INFO - 2019-08-30 15:10:22 --> Helper loaded: url_helper
INFO - 2019-08-30 15:10:22 --> Database Driver Class Initialized
ERROR - 2019-08-30 15:10:56 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 203
INFO - 2019-08-30 15:12:39 --> Config Class Initialized
INFO - 2019-08-30 15:12:39 --> Hooks Class Initialized
DEBUG - 2019-08-30 15:12:39 --> UTF-8 Support Enabled
INFO - 2019-08-30 15:12:39 --> Utf8 Class Initialized
INFO - 2019-08-30 15:12:39 --> URI Class Initialized
INFO - 2019-08-30 15:12:39 --> Router Class Initialized
INFO - 2019-08-30 15:12:39 --> Output Class Initialized
INFO - 2019-08-30 15:12:39 --> Security Class Initialized
DEBUG - 2019-08-30 15:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 15:12:39 --> Input Class Initialized
INFO - 2019-08-30 15:12:39 --> Language Class Initialized
INFO - 2019-08-30 15:12:39 --> Loader Class Initialized
INFO - 2019-08-30 15:12:39 --> Helper loaded: url_helper
INFO - 2019-08-30 15:12:39 --> Database Driver Class Initialized
DEBUG - 2019-08-30 15:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 15:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 15:12:48 --> Controller Class Initialized
INFO - 2019-08-30 15:12:48 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 15:12:48 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-30 15:12:48 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 15:12:48 --> Final output sent to browser
DEBUG - 2019-08-30 15:12:48 --> Total execution time: 8.9273
INFO - 2019-08-30 15:12:49 --> Config Class Initialized
INFO - 2019-08-30 15:12:49 --> Hooks Class Initialized
DEBUG - 2019-08-30 15:12:49 --> UTF-8 Support Enabled
INFO - 2019-08-30 15:12:49 --> Utf8 Class Initialized
INFO - 2019-08-30 15:12:49 --> URI Class Initialized
INFO - 2019-08-30 15:12:49 --> Router Class Initialized
INFO - 2019-08-30 15:12:49 --> Output Class Initialized
INFO - 2019-08-30 15:12:49 --> Security Class Initialized
DEBUG - 2019-08-30 15:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 15:12:49 --> Input Class Initialized
INFO - 2019-08-30 15:12:49 --> Language Class Initialized
INFO - 2019-08-30 15:12:49 --> Loader Class Initialized
INFO - 2019-08-30 15:12:49 --> Helper loaded: url_helper
INFO - 2019-08-30 15:12:49 --> Database Driver Class Initialized
DEBUG - 2019-08-30 15:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 15:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 15:12:50 --> Controller Class Initialized
DEBUG - 2019-08-30 15:12:50 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-30 15:12:50 --> Helper loaded: inflector_helper
INFO - 2019-08-30 15:12:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-30 15:12:50 --> Model "Template_model" initialized
INFO - 2019-08-30 15:12:50 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-30 15:12:51 --> Final output sent to browser
DEBUG - 2019-08-30 15:12:51 --> Total execution time: 2.1681
INFO - 2019-08-30 15:14:28 --> Config Class Initialized
INFO - 2019-08-30 15:14:28 --> Hooks Class Initialized
DEBUG - 2019-08-30 15:14:28 --> UTF-8 Support Enabled
INFO - 2019-08-30 15:14:28 --> Utf8 Class Initialized
INFO - 2019-08-30 15:14:28 --> URI Class Initialized
INFO - 2019-08-30 15:14:28 --> Router Class Initialized
INFO - 2019-08-30 15:14:28 --> Output Class Initialized
INFO - 2019-08-30 15:14:28 --> Security Class Initialized
DEBUG - 2019-08-30 15:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 15:14:28 --> Input Class Initialized
INFO - 2019-08-30 15:14:28 --> Language Class Initialized
INFO - 2019-08-30 15:14:28 --> Loader Class Initialized
INFO - 2019-08-30 15:14:28 --> Helper loaded: url_helper
INFO - 2019-08-30 15:14:28 --> Database Driver Class Initialized
DEBUG - 2019-08-30 15:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 15:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 15:14:31 --> Controller Class Initialized
INFO - 2019-08-30 15:14:31 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 15:14:31 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/alert.php
INFO - 2019-08-30 15:14:31 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 15:14:31 --> Final output sent to browser
DEBUG - 2019-08-30 15:14:31 --> Total execution time: 3.0330
INFO - 2019-08-30 15:44:28 --> Config Class Initialized
INFO - 2019-08-30 15:44:28 --> Hooks Class Initialized
DEBUG - 2019-08-30 15:44:28 --> UTF-8 Support Enabled
INFO - 2019-08-30 15:44:28 --> Utf8 Class Initialized
INFO - 2019-08-30 15:44:28 --> URI Class Initialized
INFO - 2019-08-30 15:44:28 --> Router Class Initialized
INFO - 2019-08-30 15:44:28 --> Output Class Initialized
INFO - 2019-08-30 15:44:28 --> Security Class Initialized
DEBUG - 2019-08-30 15:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 15:44:28 --> Input Class Initialized
INFO - 2019-08-30 15:44:28 --> Language Class Initialized
INFO - 2019-08-30 15:44:28 --> Loader Class Initialized
INFO - 2019-08-30 15:44:28 --> Helper loaded: url_helper
INFO - 2019-08-30 15:44:28 --> Database Driver Class Initialized
DEBUG - 2019-08-30 15:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 15:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 15:44:34 --> Controller Class Initialized
INFO - 2019-08-30 15:44:34 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 15:44:34 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-08-30 15:44:34 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 15:44:34 --> Final output sent to browser
DEBUG - 2019-08-30 15:44:34 --> Total execution time: 6.5765
INFO - 2019-08-30 15:48:03 --> Config Class Initialized
INFO - 2019-08-30 15:48:03 --> Hooks Class Initialized
DEBUG - 2019-08-30 15:48:03 --> UTF-8 Support Enabled
INFO - 2019-08-30 15:48:03 --> Utf8 Class Initialized
INFO - 2019-08-30 15:48:03 --> URI Class Initialized
INFO - 2019-08-30 15:48:03 --> Router Class Initialized
INFO - 2019-08-30 15:48:03 --> Output Class Initialized
INFO - 2019-08-30 15:48:03 --> Security Class Initialized
DEBUG - 2019-08-30 15:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 15:48:03 --> Input Class Initialized
INFO - 2019-08-30 15:48:03 --> Language Class Initialized
INFO - 2019-08-30 15:48:03 --> Loader Class Initialized
INFO - 2019-08-30 15:48:03 --> Helper loaded: url_helper
INFO - 2019-08-30 15:48:03 --> Database Driver Class Initialized
DEBUG - 2019-08-30 15:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 15:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 15:48:10 --> Controller Class Initialized
DEBUG - 2019-08-30 15:48:10 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-30 15:48:10 --> Helper loaded: inflector_helper
INFO - 2019-08-30 15:48:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-30 15:48:10 --> Model "Form_model" initialized
INFO - 2019-08-30 15:48:15 --> Final output sent to browser
DEBUG - 2019-08-30 15:48:15 --> Total execution time: 12.0197
INFO - 2019-08-30 15:48:15 --> Config Class Initialized
INFO - 2019-08-30 15:48:15 --> Hooks Class Initialized
DEBUG - 2019-08-30 15:48:15 --> UTF-8 Support Enabled
INFO - 2019-08-30 15:48:15 --> Utf8 Class Initialized
INFO - 2019-08-30 15:48:15 --> URI Class Initialized
INFO - 2019-08-30 15:48:15 --> Router Class Initialized
INFO - 2019-08-30 15:48:15 --> Output Class Initialized
INFO - 2019-08-30 15:48:15 --> Security Class Initialized
DEBUG - 2019-08-30 15:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 15:48:15 --> Input Class Initialized
INFO - 2019-08-30 15:48:15 --> Language Class Initialized
INFO - 2019-08-30 15:48:15 --> Loader Class Initialized
INFO - 2019-08-30 15:48:15 --> Helper loaded: url_helper
INFO - 2019-08-30 15:48:15 --> Database Driver Class Initialized
DEBUG - 2019-08-30 15:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 15:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 15:48:31 --> Controller Class Initialized
INFO - 2019-08-30 15:48:31 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 15:48:31 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-30 15:48:31 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 15:48:31 --> Final output sent to browser
DEBUG - 2019-08-30 15:48:31 --> Total execution time: 16.3912
INFO - 2019-08-30 15:54:28 --> Config Class Initialized
INFO - 2019-08-30 15:54:28 --> Hooks Class Initialized
DEBUG - 2019-08-30 15:54:28 --> UTF-8 Support Enabled
INFO - 2019-08-30 15:54:28 --> Utf8 Class Initialized
INFO - 2019-08-30 15:54:28 --> URI Class Initialized
INFO - 2019-08-30 15:54:28 --> Router Class Initialized
INFO - 2019-08-30 15:54:28 --> Output Class Initialized
INFO - 2019-08-30 15:54:28 --> Security Class Initialized
DEBUG - 2019-08-30 15:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 15:54:28 --> Input Class Initialized
INFO - 2019-08-30 15:54:28 --> Language Class Initialized
INFO - 2019-08-30 15:54:28 --> Loader Class Initialized
INFO - 2019-08-30 15:54:28 --> Helper loaded: url_helper
INFO - 2019-08-30 15:54:28 --> Database Driver Class Initialized
DEBUG - 2019-08-30 15:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 15:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 15:54:29 --> Controller Class Initialized
DEBUG - 2019-08-30 15:54:29 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-30 15:54:29 --> Helper loaded: inflector_helper
INFO - 2019-08-30 15:54:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-30 15:54:29 --> Model "Form_model" initialized
INFO - 2019-08-30 15:54:34 --> Final output sent to browser
DEBUG - 2019-08-30 15:54:34 --> Total execution time: 5.9108
INFO - 2019-08-30 15:54:34 --> Config Class Initialized
INFO - 2019-08-30 15:54:34 --> Hooks Class Initialized
DEBUG - 2019-08-30 15:54:34 --> UTF-8 Support Enabled
INFO - 2019-08-30 15:54:34 --> Utf8 Class Initialized
INFO - 2019-08-30 15:54:34 --> URI Class Initialized
INFO - 2019-08-30 15:54:34 --> Router Class Initialized
INFO - 2019-08-30 15:54:34 --> Output Class Initialized
INFO - 2019-08-30 15:54:34 --> Security Class Initialized
DEBUG - 2019-08-30 15:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 15:54:34 --> Input Class Initialized
INFO - 2019-08-30 15:54:34 --> Language Class Initialized
INFO - 2019-08-30 15:54:34 --> Loader Class Initialized
INFO - 2019-08-30 15:54:34 --> Helper loaded: url_helper
INFO - 2019-08-30 15:54:34 --> Database Driver Class Initialized
DEBUG - 2019-08-30 15:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 15:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 15:54:35 --> Controller Class Initialized
INFO - 2019-08-30 15:54:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 15:54:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-30 15:54:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 15:54:35 --> Final output sent to browser
DEBUG - 2019-08-30 15:54:35 --> Total execution time: 1.1433
INFO - 2019-08-30 16:57:18 --> Config Class Initialized
INFO - 2019-08-30 16:57:18 --> Hooks Class Initialized
DEBUG - 2019-08-30 16:57:18 --> UTF-8 Support Enabled
INFO - 2019-08-30 16:57:18 --> Utf8 Class Initialized
INFO - 2019-08-30 16:57:18 --> URI Class Initialized
DEBUG - 2019-08-30 16:57:19 --> No URI present. Default controller set.
INFO - 2019-08-30 16:57:19 --> Router Class Initialized
INFO - 2019-08-30 16:57:19 --> Output Class Initialized
INFO - 2019-08-30 16:57:19 --> Security Class Initialized
DEBUG - 2019-08-30 16:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 16:57:19 --> Input Class Initialized
INFO - 2019-08-30 16:57:19 --> Language Class Initialized
INFO - 2019-08-30 16:57:19 --> Loader Class Initialized
INFO - 2019-08-30 16:57:19 --> Helper loaded: url_helper
INFO - 2019-08-30 16:57:19 --> Database Driver Class Initialized
INFO - 2019-08-30 16:57:23 --> Config Class Initialized
INFO - 2019-08-30 16:57:23 --> Hooks Class Initialized
DEBUG - 2019-08-30 16:57:23 --> UTF-8 Support Enabled
INFO - 2019-08-30 16:57:23 --> Utf8 Class Initialized
INFO - 2019-08-30 16:57:23 --> URI Class Initialized
INFO - 2019-08-30 16:57:23 --> Router Class Initialized
INFO - 2019-08-30 16:57:23 --> Output Class Initialized
INFO - 2019-08-30 16:57:23 --> Security Class Initialized
DEBUG - 2019-08-30 16:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 16:57:23 --> Input Class Initialized
INFO - 2019-08-30 16:57:23 --> Language Class Initialized
INFO - 2019-08-30 16:57:23 --> Loader Class Initialized
INFO - 2019-08-30 16:57:23 --> Helper loaded: url_helper
INFO - 2019-08-30 16:57:23 --> Database Driver Class Initialized
DEBUG - 2019-08-30 16:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 16:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 16:57:35 --> Controller Class Initialized
INFO - 2019-08-30 16:57:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 16:57:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-08-30 16:57:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 16:57:35 --> Final output sent to browser
DEBUG - 2019-08-30 16:57:35 --> Total execution time: 12.0323
DEBUG - 2019-08-30 16:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 16:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 16:57:40 --> Controller Class Initialized
DEBUG - 2019-08-30 16:57:40 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/ion_auth.php
INFO - 2019-08-30 16:57:40 --> Email Class Initialized
INFO - 2019-08-30 16:57:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2019-08-30 16:57:40 --> Helper loaded: cookie_helper
INFO - 2019-08-30 16:57:40 --> Helper loaded: language_helper
DEBUG - 2019-08-30 16:57:40 --> Session class already loaded. Second attempt ignored.
INFO - 2019-08-30 16:57:40 --> Model "Ion_auth_model" initialized
INFO - 2019-08-30 16:57:40 --> Helper loaded: form_helper
INFO - 2019-08-30 16:57:40 --> Form Validation Class Initialized
INFO - 2019-08-30 16:57:40 --> Language file loaded: language/english/auth_lang.php
INFO - 2019-08-30 16:57:53 --> Config Class Initialized
INFO - 2019-08-30 16:57:53 --> Hooks Class Initialized
DEBUG - 2019-08-30 16:57:53 --> UTF-8 Support Enabled
INFO - 2019-08-30 16:57:53 --> Utf8 Class Initialized
INFO - 2019-08-30 16:57:53 --> URI Class Initialized
INFO - 2019-08-30 16:57:53 --> Router Class Initialized
INFO - 2019-08-30 16:57:53 --> Output Class Initialized
INFO - 2019-08-30 16:57:53 --> Security Class Initialized
DEBUG - 2019-08-30 16:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 16:57:53 --> Input Class Initialized
INFO - 2019-08-30 16:57:53 --> Language Class Initialized
INFO - 2019-08-30 16:57:53 --> Loader Class Initialized
INFO - 2019-08-30 16:57:53 --> Helper loaded: url_helper
INFO - 2019-08-30 16:57:53 --> Database Driver Class Initialized
DEBUG - 2019-08-30 16:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 16:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 16:58:13 --> Controller Class Initialized
DEBUG - 2019-08-30 16:58:13 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-30 16:58:13 --> Helper loaded: inflector_helper
INFO - 2019-08-30 16:58:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-30 16:58:13 --> Model "Form_model" initialized
INFO - 2019-08-30 16:58:21 --> Final output sent to browser
DEBUG - 2019-08-30 16:58:21 --> Total execution time: 27.6371
INFO - 2019-08-30 16:58:21 --> Config Class Initialized
INFO - 2019-08-30 16:58:21 --> Hooks Class Initialized
DEBUG - 2019-08-30 16:58:21 --> UTF-8 Support Enabled
INFO - 2019-08-30 16:58:21 --> Utf8 Class Initialized
INFO - 2019-08-30 16:58:21 --> URI Class Initialized
INFO - 2019-08-30 16:58:21 --> Router Class Initialized
INFO - 2019-08-30 16:58:21 --> Output Class Initialized
INFO - 2019-08-30 16:58:21 --> Security Class Initialized
DEBUG - 2019-08-30 16:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 16:58:21 --> Input Class Initialized
INFO - 2019-08-30 16:58:21 --> Language Class Initialized
INFO - 2019-08-30 16:58:21 --> Loader Class Initialized
INFO - 2019-08-30 16:58:21 --> Helper loaded: url_helper
INFO - 2019-08-30 16:58:21 --> Database Driver Class Initialized
DEBUG - 2019-08-30 16:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 16:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 16:58:39 --> Controller Class Initialized
INFO - 2019-08-30 16:58:39 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 16:58:39 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-30 16:58:39 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 16:58:39 --> Final output sent to browser
DEBUG - 2019-08-30 16:58:39 --> Total execution time: 18.1035
INFO - 2019-08-30 17:03:50 --> Config Class Initialized
INFO - 2019-08-30 17:03:50 --> Hooks Class Initialized
DEBUG - 2019-08-30 17:03:50 --> UTF-8 Support Enabled
INFO - 2019-08-30 17:03:50 --> Utf8 Class Initialized
INFO - 2019-08-30 17:03:50 --> URI Class Initialized
INFO - 2019-08-30 17:03:50 --> Router Class Initialized
INFO - 2019-08-30 17:03:50 --> Output Class Initialized
INFO - 2019-08-30 17:03:50 --> Security Class Initialized
DEBUG - 2019-08-30 17:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 17:03:50 --> Input Class Initialized
INFO - 2019-08-30 17:03:50 --> Language Class Initialized
INFO - 2019-08-30 17:03:50 --> Loader Class Initialized
INFO - 2019-08-30 17:03:50 --> Helper loaded: url_helper
INFO - 2019-08-30 17:03:50 --> Database Driver Class Initialized
DEBUG - 2019-08-30 17:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 17:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 17:04:01 --> Controller Class Initialized
INFO - 2019-08-30 17:04:01 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 17:04:01 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-30 17:04:01 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 17:04:01 --> Final output sent to browser
DEBUG - 2019-08-30 17:04:01 --> Total execution time: 11.0927
INFO - 2019-08-30 17:04:02 --> Config Class Initialized
INFO - 2019-08-30 17:04:02 --> Hooks Class Initialized
DEBUG - 2019-08-30 17:04:02 --> UTF-8 Support Enabled
INFO - 2019-08-30 17:04:02 --> Utf8 Class Initialized
INFO - 2019-08-30 17:04:02 --> URI Class Initialized
INFO - 2019-08-30 17:04:02 --> Router Class Initialized
INFO - 2019-08-30 17:04:02 --> Output Class Initialized
INFO - 2019-08-30 17:04:02 --> Security Class Initialized
DEBUG - 2019-08-30 17:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 17:04:02 --> Input Class Initialized
INFO - 2019-08-30 17:04:02 --> Language Class Initialized
INFO - 2019-08-30 17:04:02 --> Loader Class Initialized
INFO - 2019-08-30 17:04:02 --> Helper loaded: url_helper
INFO - 2019-08-30 17:04:02 --> Database Driver Class Initialized
DEBUG - 2019-08-30 17:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 17:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 17:04:25 --> Controller Class Initialized
DEBUG - 2019-08-30 17:04:25 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-30 17:04:25 --> Helper loaded: inflector_helper
INFO - 2019-08-30 17:04:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-30 17:04:25 --> Model "Template_model" initialized
INFO - 2019-08-30 17:04:25 --> Model "Khang_sinh_model" initialized
ERROR - 2019-08-30 17:04:43 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 307
INFO - 2019-08-30 17:07:42 --> Config Class Initialized
INFO - 2019-08-30 17:07:42 --> Hooks Class Initialized
DEBUG - 2019-08-30 17:07:42 --> UTF-8 Support Enabled
INFO - 2019-08-30 17:07:42 --> Utf8 Class Initialized
INFO - 2019-08-30 17:07:42 --> URI Class Initialized
INFO - 2019-08-30 17:07:42 --> Router Class Initialized
INFO - 2019-08-30 17:07:42 --> Output Class Initialized
INFO - 2019-08-30 17:07:42 --> Security Class Initialized
DEBUG - 2019-08-30 17:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 17:07:42 --> Input Class Initialized
INFO - 2019-08-30 17:07:42 --> Language Class Initialized
INFO - 2019-08-30 17:07:42 --> Loader Class Initialized
INFO - 2019-08-30 17:07:42 --> Helper loaded: url_helper
INFO - 2019-08-30 17:07:42 --> Database Driver Class Initialized
DEBUG - 2019-08-30 17:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 17:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 17:07:56 --> Controller Class Initialized
INFO - 2019-08-30 17:07:56 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 17:07:56 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-30 17:07:56 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 17:07:56 --> Final output sent to browser
DEBUG - 2019-08-30 17:07:56 --> Total execution time: 14.5399
INFO - 2019-08-30 17:07:58 --> Config Class Initialized
INFO - 2019-08-30 17:07:58 --> Hooks Class Initialized
DEBUG - 2019-08-30 17:07:58 --> UTF-8 Support Enabled
INFO - 2019-08-30 17:07:58 --> Utf8 Class Initialized
INFO - 2019-08-30 17:07:58 --> URI Class Initialized
INFO - 2019-08-30 17:07:58 --> Router Class Initialized
INFO - 2019-08-30 17:07:58 --> Output Class Initialized
INFO - 2019-08-30 17:07:58 --> Security Class Initialized
DEBUG - 2019-08-30 17:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 17:07:58 --> Input Class Initialized
INFO - 2019-08-30 17:07:58 --> Language Class Initialized
INFO - 2019-08-30 17:07:58 --> Loader Class Initialized
INFO - 2019-08-30 17:07:58 --> Helper loaded: url_helper
INFO - 2019-08-30 17:07:58 --> Database Driver Class Initialized
DEBUG - 2019-08-30 17:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 17:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 17:08:13 --> Controller Class Initialized
DEBUG - 2019-08-30 17:08:13 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-30 17:08:13 --> Helper loaded: inflector_helper
INFO - 2019-08-30 17:08:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-30 17:08:13 --> Model "Template_model" initialized
INFO - 2019-08-30 17:08:13 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-30 17:08:23 --> Final output sent to browser
DEBUG - 2019-08-30 17:08:23 --> Total execution time: 25.8112
INFO - 2019-08-30 17:23:33 --> Config Class Initialized
INFO - 2019-08-30 17:23:33 --> Hooks Class Initialized
DEBUG - 2019-08-30 17:23:33 --> UTF-8 Support Enabled
INFO - 2019-08-30 17:23:33 --> Utf8 Class Initialized
INFO - 2019-08-30 17:23:33 --> URI Class Initialized
INFO - 2019-08-30 17:23:33 --> Router Class Initialized
INFO - 2019-08-30 17:23:33 --> Output Class Initialized
INFO - 2019-08-30 17:23:33 --> Security Class Initialized
DEBUG - 2019-08-30 17:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 17:23:33 --> Input Class Initialized
INFO - 2019-08-30 17:23:33 --> Language Class Initialized
INFO - 2019-08-30 17:23:33 --> Loader Class Initialized
INFO - 2019-08-30 17:23:33 --> Helper loaded: url_helper
INFO - 2019-08-30 17:23:33 --> Database Driver Class Initialized
DEBUG - 2019-08-30 17:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 17:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 17:23:54 --> Controller Class Initialized
INFO - 2019-08-30 17:23:54 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 17:23:54 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step3.php
INFO - 2019-08-30 17:23:54 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 17:23:54 --> Final output sent to browser
DEBUG - 2019-08-30 17:23:54 --> Total execution time: 21.0727
INFO - 2019-08-30 18:06:13 --> Config Class Initialized
INFO - 2019-08-30 18:06:13 --> Hooks Class Initialized
DEBUG - 2019-08-30 18:06:13 --> UTF-8 Support Enabled
INFO - 2019-08-30 18:06:13 --> Utf8 Class Initialized
INFO - 2019-08-30 18:06:13 --> URI Class Initialized
INFO - 2019-08-30 18:06:13 --> Router Class Initialized
INFO - 2019-08-30 18:06:13 --> Output Class Initialized
INFO - 2019-08-30 18:06:13 --> Security Class Initialized
DEBUG - 2019-08-30 18:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 18:06:13 --> Input Class Initialized
INFO - 2019-08-30 18:06:13 --> Language Class Initialized
INFO - 2019-08-30 18:06:13 --> Loader Class Initialized
INFO - 2019-08-30 18:06:13 --> Helper loaded: url_helper
INFO - 2019-08-30 18:06:13 --> Database Driver Class Initialized
DEBUG - 2019-08-30 18:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 18:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 18:06:42 --> Controller Class Initialized
INFO - 2019-08-30 18:06:42 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 18:06:42 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-08-30 18:06:42 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 18:06:42 --> Final output sent to browser
DEBUG - 2019-08-30 18:06:42 --> Total execution time: 29.1156
INFO - 2019-08-30 18:07:28 --> Config Class Initialized
INFO - 2019-08-30 18:07:28 --> Hooks Class Initialized
DEBUG - 2019-08-30 18:07:28 --> UTF-8 Support Enabled
INFO - 2019-08-30 18:07:28 --> Utf8 Class Initialized
INFO - 2019-08-30 18:07:28 --> URI Class Initialized
INFO - 2019-08-30 18:07:28 --> Router Class Initialized
INFO - 2019-08-30 18:07:28 --> Output Class Initialized
INFO - 2019-08-30 18:07:28 --> Security Class Initialized
DEBUG - 2019-08-30 18:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 18:07:28 --> Input Class Initialized
INFO - 2019-08-30 18:07:28 --> Language Class Initialized
INFO - 2019-08-30 18:07:28 --> Loader Class Initialized
INFO - 2019-08-30 18:07:28 --> Helper loaded: url_helper
INFO - 2019-08-30 18:07:28 --> Database Driver Class Initialized
DEBUG - 2019-08-30 18:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 18:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 18:07:43 --> Controller Class Initialized
INFO - 2019-08-30 18:07:43 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 18:07:43 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-08-30 18:07:43 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 18:07:43 --> Final output sent to browser
DEBUG - 2019-08-30 18:07:43 --> Total execution time: 15.1749
INFO - 2019-08-30 18:10:21 --> Config Class Initialized
INFO - 2019-08-30 18:10:21 --> Hooks Class Initialized
DEBUG - 2019-08-30 18:10:21 --> UTF-8 Support Enabled
INFO - 2019-08-30 18:10:21 --> Utf8 Class Initialized
INFO - 2019-08-30 18:10:21 --> URI Class Initialized
INFO - 2019-08-30 18:10:21 --> Router Class Initialized
INFO - 2019-08-30 18:10:21 --> Output Class Initialized
INFO - 2019-08-30 18:10:21 --> Security Class Initialized
DEBUG - 2019-08-30 18:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 18:10:21 --> Input Class Initialized
INFO - 2019-08-30 18:10:21 --> Language Class Initialized
INFO - 2019-08-30 18:10:21 --> Loader Class Initialized
INFO - 2019-08-30 18:10:21 --> Helper loaded: url_helper
INFO - 2019-08-30 18:10:21 --> Database Driver Class Initialized
DEBUG - 2019-08-30 18:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 18:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 18:10:36 --> Controller Class Initialized
INFO - 2019-08-30 18:10:36 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 18:10:36 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-08-30 18:10:36 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 18:10:36 --> Final output sent to browser
DEBUG - 2019-08-30 18:10:36 --> Total execution time: 15.0545
INFO - 2019-08-30 18:12:32 --> Config Class Initialized
INFO - 2019-08-30 18:12:32 --> Hooks Class Initialized
DEBUG - 2019-08-30 18:12:32 --> UTF-8 Support Enabled
INFO - 2019-08-30 18:12:32 --> Utf8 Class Initialized
INFO - 2019-08-30 18:12:32 --> URI Class Initialized
INFO - 2019-08-30 18:12:32 --> Router Class Initialized
INFO - 2019-08-30 18:12:32 --> Output Class Initialized
INFO - 2019-08-30 18:12:32 --> Security Class Initialized
DEBUG - 2019-08-30 18:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 18:12:32 --> Input Class Initialized
INFO - 2019-08-30 18:12:32 --> Language Class Initialized
INFO - 2019-08-30 18:12:32 --> Loader Class Initialized
INFO - 2019-08-30 18:12:32 --> Helper loaded: url_helper
INFO - 2019-08-30 18:12:32 --> Database Driver Class Initialized
DEBUG - 2019-08-30 18:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 18:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 18:12:47 --> Controller Class Initialized
DEBUG - 2019-08-30 18:12:47 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-30 18:12:47 --> Helper loaded: inflector_helper
INFO - 2019-08-30 18:12:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-30 18:12:47 --> Model "Form_model" initialized
ERROR - 2019-08-30 18:13:12 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 307
INFO - 2019-08-30 18:13:29 --> Config Class Initialized
INFO - 2019-08-30 18:13:29 --> Hooks Class Initialized
DEBUG - 2019-08-30 18:13:29 --> UTF-8 Support Enabled
INFO - 2019-08-30 18:13:29 --> Utf8 Class Initialized
INFO - 2019-08-30 18:13:29 --> URI Class Initialized
INFO - 2019-08-30 18:13:29 --> Router Class Initialized
INFO - 2019-08-30 18:13:29 --> Output Class Initialized
INFO - 2019-08-30 18:13:29 --> Security Class Initialized
DEBUG - 2019-08-30 18:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 18:13:29 --> Input Class Initialized
INFO - 2019-08-30 18:13:29 --> Language Class Initialized
INFO - 2019-08-30 18:13:29 --> Loader Class Initialized
INFO - 2019-08-30 18:13:29 --> Helper loaded: url_helper
INFO - 2019-08-30 18:13:29 --> Database Driver Class Initialized
DEBUG - 2019-08-30 18:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 18:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 18:13:45 --> Controller Class Initialized
DEBUG - 2019-08-30 18:13:45 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-30 18:13:45 --> Helper loaded: inflector_helper
INFO - 2019-08-30 18:13:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-30 18:13:45 --> Model "Form_model" initialized
INFO - 2019-08-30 18:13:48 --> Final output sent to browser
DEBUG - 2019-08-30 18:13:48 --> Total execution time: 18.3489
INFO - 2019-08-30 18:13:48 --> Config Class Initialized
INFO - 2019-08-30 18:13:48 --> Hooks Class Initialized
DEBUG - 2019-08-30 18:13:48 --> UTF-8 Support Enabled
INFO - 2019-08-30 18:13:48 --> Utf8 Class Initialized
INFO - 2019-08-30 18:13:48 --> URI Class Initialized
INFO - 2019-08-30 18:13:48 --> Router Class Initialized
INFO - 2019-08-30 18:13:48 --> Output Class Initialized
INFO - 2019-08-30 18:13:48 --> Security Class Initialized
DEBUG - 2019-08-30 18:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 18:13:48 --> Input Class Initialized
INFO - 2019-08-30 18:13:48 --> Language Class Initialized
INFO - 2019-08-30 18:13:48 --> Loader Class Initialized
INFO - 2019-08-30 18:13:48 --> Helper loaded: url_helper
INFO - 2019-08-30 18:13:48 --> Database Driver Class Initialized
DEBUG - 2019-08-30 18:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 18:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 18:13:57 --> Controller Class Initialized
INFO - 2019-08-30 18:13:57 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 18:13:57 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-30 18:13:57 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 18:13:57 --> Final output sent to browser
DEBUG - 2019-08-30 18:13:57 --> Total execution time: 9.0903
INFO - 2019-08-30 18:55:20 --> Config Class Initialized
INFO - 2019-08-30 18:55:20 --> Hooks Class Initialized
DEBUG - 2019-08-30 18:55:20 --> UTF-8 Support Enabled
INFO - 2019-08-30 18:55:20 --> Utf8 Class Initialized
INFO - 2019-08-30 18:55:20 --> URI Class Initialized
INFO - 2019-08-30 18:55:20 --> Router Class Initialized
INFO - 2019-08-30 18:55:20 --> Output Class Initialized
INFO - 2019-08-30 18:55:20 --> Security Class Initialized
DEBUG - 2019-08-30 18:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 18:55:20 --> Input Class Initialized
INFO - 2019-08-30 18:55:20 --> Language Class Initialized
INFO - 2019-08-30 18:55:20 --> Loader Class Initialized
INFO - 2019-08-30 18:55:20 --> Helper loaded: url_helper
INFO - 2019-08-30 18:55:20 --> Database Driver Class Initialized
DEBUG - 2019-08-30 18:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 18:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 18:55:39 --> Controller Class Initialized
DEBUG - 2019-08-30 18:55:39 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-30 18:55:39 --> Helper loaded: inflector_helper
INFO - 2019-08-30 18:55:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-30 18:55:39 --> Model "Form_model" initialized
INFO - 2019-08-30 18:55:40 --> Final output sent to browser
DEBUG - 2019-08-30 18:55:40 --> Total execution time: 19.5845
INFO - 2019-08-30 18:55:40 --> Config Class Initialized
INFO - 2019-08-30 18:55:40 --> Hooks Class Initialized
DEBUG - 2019-08-30 18:55:40 --> UTF-8 Support Enabled
INFO - 2019-08-30 18:55:40 --> Utf8 Class Initialized
INFO - 2019-08-30 18:55:40 --> URI Class Initialized
INFO - 2019-08-30 18:55:40 --> Router Class Initialized
INFO - 2019-08-30 18:55:40 --> Output Class Initialized
INFO - 2019-08-30 18:55:40 --> Security Class Initialized
DEBUG - 2019-08-30 18:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 18:55:40 --> Input Class Initialized
INFO - 2019-08-30 18:55:40 --> Language Class Initialized
INFO - 2019-08-30 18:55:40 --> Loader Class Initialized
INFO - 2019-08-30 18:55:40 --> Helper loaded: url_helper
INFO - 2019-08-30 18:55:40 --> Database Driver Class Initialized
DEBUG - 2019-08-30 18:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 18:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 18:56:01 --> Controller Class Initialized
INFO - 2019-08-30 18:56:01 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 18:56:01 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-30 18:56:01 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 18:56:01 --> Final output sent to browser
DEBUG - 2019-08-30 18:56:01 --> Total execution time: 21.1879
INFO - 2019-08-30 18:56:11 --> Config Class Initialized
INFO - 2019-08-30 18:56:11 --> Hooks Class Initialized
DEBUG - 2019-08-30 18:56:11 --> UTF-8 Support Enabled
INFO - 2019-08-30 18:56:11 --> Utf8 Class Initialized
INFO - 2019-08-30 18:56:11 --> URI Class Initialized
INFO - 2019-08-30 18:56:11 --> Router Class Initialized
INFO - 2019-08-30 18:56:11 --> Output Class Initialized
INFO - 2019-08-30 18:56:11 --> Security Class Initialized
DEBUG - 2019-08-30 18:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 18:56:11 --> Input Class Initialized
INFO - 2019-08-30 18:56:11 --> Language Class Initialized
INFO - 2019-08-30 18:56:11 --> Loader Class Initialized
INFO - 2019-08-30 18:56:11 --> Helper loaded: url_helper
INFO - 2019-08-30 18:56:11 --> Database Driver Class Initialized
DEBUG - 2019-08-30 18:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 18:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 18:56:24 --> Controller Class Initialized
INFO - 2019-08-30 18:56:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 18:56:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-30 18:56:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 18:56:24 --> Final output sent to browser
DEBUG - 2019-08-30 18:56:24 --> Total execution time: 13.0108
INFO - 2019-08-30 18:59:38 --> Config Class Initialized
INFO - 2019-08-30 18:59:38 --> Hooks Class Initialized
DEBUG - 2019-08-30 18:59:38 --> UTF-8 Support Enabled
INFO - 2019-08-30 18:59:38 --> Utf8 Class Initialized
INFO - 2019-08-30 18:59:38 --> URI Class Initialized
INFO - 2019-08-30 18:59:38 --> Router Class Initialized
INFO - 2019-08-30 18:59:38 --> Output Class Initialized
INFO - 2019-08-30 18:59:38 --> Security Class Initialized
DEBUG - 2019-08-30 18:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 18:59:38 --> Input Class Initialized
INFO - 2019-08-30 18:59:38 --> Language Class Initialized
INFO - 2019-08-30 18:59:38 --> Loader Class Initialized
INFO - 2019-08-30 18:59:38 --> Helper loaded: url_helper
INFO - 2019-08-30 18:59:38 --> Database Driver Class Initialized
DEBUG - 2019-08-30 18:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 18:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 18:59:58 --> Controller Class Initialized
DEBUG - 2019-08-30 18:59:58 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-30 18:59:58 --> Helper loaded: inflector_helper
INFO - 2019-08-30 18:59:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-30 18:59:58 --> Model "Form_model" initialized
INFO - 2019-08-30 19:00:02 --> Final output sent to browser
DEBUG - 2019-08-30 19:00:02 --> Total execution time: 24.4835
INFO - 2019-08-30 19:00:02 --> Config Class Initialized
INFO - 2019-08-30 19:00:02 --> Hooks Class Initialized
DEBUG - 2019-08-30 19:00:02 --> UTF-8 Support Enabled
INFO - 2019-08-30 19:00:02 --> Utf8 Class Initialized
INFO - 2019-08-30 19:00:02 --> URI Class Initialized
INFO - 2019-08-30 19:00:02 --> Router Class Initialized
INFO - 2019-08-30 19:00:02 --> Output Class Initialized
INFO - 2019-08-30 19:00:02 --> Security Class Initialized
DEBUG - 2019-08-30 19:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 19:00:02 --> Input Class Initialized
INFO - 2019-08-30 19:00:02 --> Language Class Initialized
INFO - 2019-08-30 19:00:02 --> Loader Class Initialized
INFO - 2019-08-30 19:00:02 --> Helper loaded: url_helper
INFO - 2019-08-30 19:00:02 --> Database Driver Class Initialized
DEBUG - 2019-08-30 19:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 19:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 19:00:21 --> Controller Class Initialized
INFO - 2019-08-30 19:00:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 19:00:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-30 19:00:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 19:00:21 --> Final output sent to browser
DEBUG - 2019-08-30 19:00:21 --> Total execution time: 18.3375
INFO - 2019-08-30 19:49:27 --> Config Class Initialized
INFO - 2019-08-30 19:49:27 --> Hooks Class Initialized
DEBUG - 2019-08-30 19:49:27 --> UTF-8 Support Enabled
INFO - 2019-08-30 19:49:27 --> Utf8 Class Initialized
INFO - 2019-08-30 19:49:27 --> URI Class Initialized
INFO - 2019-08-30 19:49:27 --> Router Class Initialized
INFO - 2019-08-30 19:49:27 --> Output Class Initialized
INFO - 2019-08-30 19:49:27 --> Security Class Initialized
DEBUG - 2019-08-30 19:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 19:49:27 --> Input Class Initialized
INFO - 2019-08-30 19:49:27 --> Language Class Initialized
INFO - 2019-08-30 19:49:27 --> Loader Class Initialized
INFO - 2019-08-30 19:49:27 --> Helper loaded: url_helper
INFO - 2019-08-30 19:49:27 --> Database Driver Class Initialized
DEBUG - 2019-08-30 19:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 19:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 19:49:48 --> Controller Class Initialized
DEBUG - 2019-08-30 19:49:48 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-30 19:49:48 --> Helper loaded: inflector_helper
INFO - 2019-08-30 19:49:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-30 19:49:48 --> Model "Form_model" initialized
ERROR - 2019-08-30 19:50:02 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 307
INFO - 2019-08-30 19:50:18 --> Config Class Initialized
INFO - 2019-08-30 19:50:18 --> Hooks Class Initialized
DEBUG - 2019-08-30 19:50:18 --> UTF-8 Support Enabled
INFO - 2019-08-30 19:50:18 --> Utf8 Class Initialized
INFO - 2019-08-30 19:50:18 --> URI Class Initialized
INFO - 2019-08-30 19:50:18 --> Router Class Initialized
INFO - 2019-08-30 19:50:18 --> Output Class Initialized
INFO - 2019-08-30 19:50:18 --> Security Class Initialized
DEBUG - 2019-08-30 19:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 19:50:18 --> Input Class Initialized
INFO - 2019-08-30 19:50:18 --> Language Class Initialized
INFO - 2019-08-30 19:50:18 --> Loader Class Initialized
INFO - 2019-08-30 19:50:18 --> Helper loaded: url_helper
INFO - 2019-08-30 19:50:18 --> Database Driver Class Initialized
DEBUG - 2019-08-30 19:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 19:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 19:50:21 --> Controller Class Initialized
INFO - 2019-08-30 19:50:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 19:50:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-08-30 19:50:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 19:50:21 --> Final output sent to browser
DEBUG - 2019-08-30 19:50:21 --> Total execution time: 3.6022
INFO - 2019-08-30 19:51:58 --> Config Class Initialized
INFO - 2019-08-30 19:51:58 --> Hooks Class Initialized
DEBUG - 2019-08-30 19:51:58 --> UTF-8 Support Enabled
INFO - 2019-08-30 19:51:58 --> Utf8 Class Initialized
INFO - 2019-08-30 19:51:58 --> URI Class Initialized
INFO - 2019-08-30 19:51:58 --> Router Class Initialized
INFO - 2019-08-30 19:51:58 --> Output Class Initialized
INFO - 2019-08-30 19:51:58 --> Security Class Initialized
DEBUG - 2019-08-30 19:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 19:51:58 --> Input Class Initialized
INFO - 2019-08-30 19:51:58 --> Language Class Initialized
INFO - 2019-08-30 19:51:58 --> Loader Class Initialized
INFO - 2019-08-30 19:51:58 --> Helper loaded: url_helper
INFO - 2019-08-30 19:51:58 --> Database Driver Class Initialized
DEBUG - 2019-08-30 19:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 19:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 19:52:13 --> Controller Class Initialized
INFO - 2019-08-30 19:52:13 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 19:52:13 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-08-30 19:52:13 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 19:52:13 --> Final output sent to browser
DEBUG - 2019-08-30 19:52:13 --> Total execution time: 15.2646
INFO - 2019-08-30 19:52:18 --> Config Class Initialized
INFO - 2019-08-30 19:52:18 --> Hooks Class Initialized
DEBUG - 2019-08-30 19:52:18 --> UTF-8 Support Enabled
INFO - 2019-08-30 19:52:18 --> Utf8 Class Initialized
INFO - 2019-08-30 19:52:18 --> URI Class Initialized
INFO - 2019-08-30 19:52:18 --> Router Class Initialized
INFO - 2019-08-30 19:52:18 --> Output Class Initialized
INFO - 2019-08-30 19:52:18 --> Security Class Initialized
DEBUG - 2019-08-30 19:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 19:52:18 --> Input Class Initialized
INFO - 2019-08-30 19:52:18 --> Language Class Initialized
INFO - 2019-08-30 19:52:18 --> Loader Class Initialized
INFO - 2019-08-30 19:52:18 --> Helper loaded: url_helper
INFO - 2019-08-30 19:52:18 --> Database Driver Class Initialized
DEBUG - 2019-08-30 19:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 19:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 19:52:25 --> Controller Class Initialized
DEBUG - 2019-08-30 19:52:25 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-30 19:52:25 --> Helper loaded: inflector_helper
INFO - 2019-08-30 19:52:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-30 19:52:25 --> Model "Form_model" initialized
INFO - 2019-08-30 19:52:26 --> Final output sent to browser
DEBUG - 2019-08-30 19:52:26 --> Total execution time: 8.6906
INFO - 2019-08-30 19:52:26 --> Config Class Initialized
INFO - 2019-08-30 19:52:26 --> Hooks Class Initialized
DEBUG - 2019-08-30 19:52:26 --> UTF-8 Support Enabled
INFO - 2019-08-30 19:52:26 --> Utf8 Class Initialized
INFO - 2019-08-30 19:52:26 --> URI Class Initialized
INFO - 2019-08-30 19:52:26 --> Router Class Initialized
INFO - 2019-08-30 19:52:26 --> Output Class Initialized
INFO - 2019-08-30 19:52:26 --> Security Class Initialized
DEBUG - 2019-08-30 19:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 19:52:26 --> Input Class Initialized
INFO - 2019-08-30 19:52:26 --> Language Class Initialized
INFO - 2019-08-30 19:52:26 --> Loader Class Initialized
INFO - 2019-08-30 19:52:26 --> Helper loaded: url_helper
INFO - 2019-08-30 19:52:26 --> Database Driver Class Initialized
DEBUG - 2019-08-30 19:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 19:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 19:52:55 --> Controller Class Initialized
INFO - 2019-08-30 19:52:55 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 19:52:55 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-30 19:52:55 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 19:52:55 --> Final output sent to browser
DEBUG - 2019-08-30 19:52:55 --> Total execution time: 29.0191
INFO - 2019-08-30 20:07:01 --> Config Class Initialized
INFO - 2019-08-30 20:07:01 --> Hooks Class Initialized
DEBUG - 2019-08-30 20:07:01 --> UTF-8 Support Enabled
INFO - 2019-08-30 20:07:01 --> Utf8 Class Initialized
INFO - 2019-08-30 20:07:01 --> URI Class Initialized
INFO - 2019-08-30 20:07:01 --> Router Class Initialized
INFO - 2019-08-30 20:07:01 --> Output Class Initialized
INFO - 2019-08-30 20:07:01 --> Security Class Initialized
DEBUG - 2019-08-30 20:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 20:07:01 --> Input Class Initialized
INFO - 2019-08-30 20:07:01 --> Language Class Initialized
INFO - 2019-08-30 20:07:01 --> Loader Class Initialized
INFO - 2019-08-30 20:07:01 --> Helper loaded: url_helper
INFO - 2019-08-30 20:07:01 --> Database Driver Class Initialized
DEBUG - 2019-08-30 20:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 20:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 20:07:21 --> Controller Class Initialized
INFO - 2019-08-30 20:07:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 20:07:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-30 20:07:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 20:07:21 --> Final output sent to browser
DEBUG - 2019-08-30 20:07:21 --> Total execution time: 19.9850
INFO - 2019-08-30 20:07:22 --> Config Class Initialized
INFO - 2019-08-30 20:07:22 --> Hooks Class Initialized
DEBUG - 2019-08-30 20:07:22 --> UTF-8 Support Enabled
INFO - 2019-08-30 20:07:22 --> Utf8 Class Initialized
INFO - 2019-08-30 20:07:22 --> URI Class Initialized
INFO - 2019-08-30 20:07:22 --> Router Class Initialized
INFO - 2019-08-30 20:07:22 --> Output Class Initialized
INFO - 2019-08-30 20:07:22 --> Security Class Initialized
DEBUG - 2019-08-30 20:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 20:07:22 --> Input Class Initialized
INFO - 2019-08-30 20:07:22 --> Language Class Initialized
INFO - 2019-08-30 20:07:22 --> Loader Class Initialized
INFO - 2019-08-30 20:07:22 --> Helper loaded: url_helper
INFO - 2019-08-30 20:07:22 --> Database Driver Class Initialized
INFO - 2019-08-30 20:07:26 --> Config Class Initialized
INFO - 2019-08-30 20:07:26 --> Hooks Class Initialized
DEBUG - 2019-08-30 20:07:26 --> UTF-8 Support Enabled
INFO - 2019-08-30 20:07:26 --> Utf8 Class Initialized
INFO - 2019-08-30 20:07:26 --> URI Class Initialized
INFO - 2019-08-30 20:07:26 --> Router Class Initialized
INFO - 2019-08-30 20:07:26 --> Output Class Initialized
INFO - 2019-08-30 20:07:26 --> Security Class Initialized
DEBUG - 2019-08-30 20:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 20:07:26 --> Input Class Initialized
INFO - 2019-08-30 20:07:26 --> Language Class Initialized
INFO - 2019-08-30 20:07:26 --> Loader Class Initialized
INFO - 2019-08-30 20:07:26 --> Helper loaded: url_helper
INFO - 2019-08-30 20:07:26 --> Database Driver Class Initialized
DEBUG - 2019-08-30 20:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 20:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 20:07:34 --> Controller Class Initialized
DEBUG - 2019-08-30 20:07:34 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-30 20:07:34 --> Helper loaded: inflector_helper
INFO - 2019-08-30 20:07:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-30 20:07:34 --> Model "Template_model" initialized
INFO - 2019-08-30 20:07:34 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-30 20:07:37 --> Final output sent to browser
DEBUG - 2019-08-30 20:07:37 --> Total execution time: 15.2713
DEBUG - 2019-08-30 20:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 20:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 20:07:44 --> Controller Class Initialized
INFO - 2019-08-30 20:07:44 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 20:07:44 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-30 20:07:44 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 20:07:44 --> Final output sent to browser
DEBUG - 2019-08-30 20:07:44 --> Total execution time: 18.1271
INFO - 2019-08-30 20:09:26 --> Config Class Initialized
INFO - 2019-08-30 20:09:26 --> Hooks Class Initialized
DEBUG - 2019-08-30 20:09:26 --> UTF-8 Support Enabled
INFO - 2019-08-30 20:09:26 --> Utf8 Class Initialized
INFO - 2019-08-30 20:09:26 --> URI Class Initialized
INFO - 2019-08-30 20:09:26 --> Router Class Initialized
INFO - 2019-08-30 20:09:26 --> Output Class Initialized
INFO - 2019-08-30 20:09:26 --> Security Class Initialized
DEBUG - 2019-08-30 20:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 20:09:26 --> Input Class Initialized
INFO - 2019-08-30 20:09:26 --> Language Class Initialized
INFO - 2019-08-30 20:09:26 --> Loader Class Initialized
INFO - 2019-08-30 20:09:26 --> Helper loaded: url_helper
INFO - 2019-08-30 20:09:26 --> Database Driver Class Initialized
DEBUG - 2019-08-30 20:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 20:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 20:09:46 --> Controller Class Initialized
INFO - 2019-08-30 20:09:46 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 20:09:46 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-30 20:09:46 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 20:09:46 --> Final output sent to browser
DEBUG - 2019-08-30 20:09:46 --> Total execution time: 20.1315
INFO - 2019-08-30 20:10:59 --> Config Class Initialized
INFO - 2019-08-30 20:10:59 --> Hooks Class Initialized
DEBUG - 2019-08-30 20:10:59 --> UTF-8 Support Enabled
INFO - 2019-08-30 20:10:59 --> Utf8 Class Initialized
INFO - 2019-08-30 20:10:59 --> URI Class Initialized
INFO - 2019-08-30 20:10:59 --> Router Class Initialized
INFO - 2019-08-30 20:10:59 --> Output Class Initialized
INFO - 2019-08-30 20:10:59 --> Security Class Initialized
DEBUG - 2019-08-30 20:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 20:10:59 --> Input Class Initialized
INFO - 2019-08-30 20:10:59 --> Language Class Initialized
INFO - 2019-08-30 20:10:59 --> Loader Class Initialized
INFO - 2019-08-30 20:10:59 --> Helper loaded: url_helper
INFO - 2019-08-30 20:10:59 --> Database Driver Class Initialized
DEBUG - 2019-08-30 20:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 20:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 20:11:12 --> Controller Class Initialized
INFO - 2019-08-30 20:11:12 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 20:11:12 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-30 20:11:12 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 20:11:12 --> Final output sent to browser
DEBUG - 2019-08-30 20:11:12 --> Total execution time: 13.0706
INFO - 2019-08-30 20:11:13 --> Config Class Initialized
INFO - 2019-08-30 20:11:13 --> Hooks Class Initialized
DEBUG - 2019-08-30 20:11:13 --> UTF-8 Support Enabled
INFO - 2019-08-30 20:11:13 --> Utf8 Class Initialized
INFO - 2019-08-30 20:11:13 --> URI Class Initialized
INFO - 2019-08-30 20:11:13 --> Router Class Initialized
INFO - 2019-08-30 20:11:13 --> Output Class Initialized
INFO - 2019-08-30 20:11:13 --> Security Class Initialized
DEBUG - 2019-08-30 20:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 20:11:13 --> Input Class Initialized
INFO - 2019-08-30 20:11:13 --> Language Class Initialized
INFO - 2019-08-30 20:11:13 --> Loader Class Initialized
INFO - 2019-08-30 20:11:13 --> Helper loaded: url_helper
INFO - 2019-08-30 20:11:13 --> Database Driver Class Initialized
INFO - 2019-08-30 20:11:20 --> Config Class Initialized
INFO - 2019-08-30 20:11:20 --> Hooks Class Initialized
DEBUG - 2019-08-30 20:11:20 --> UTF-8 Support Enabled
INFO - 2019-08-30 20:11:20 --> Utf8 Class Initialized
INFO - 2019-08-30 20:11:20 --> URI Class Initialized
INFO - 2019-08-30 20:11:20 --> Router Class Initialized
INFO - 2019-08-30 20:11:20 --> Output Class Initialized
INFO - 2019-08-30 20:11:20 --> Security Class Initialized
DEBUG - 2019-08-30 20:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 20:11:20 --> Input Class Initialized
INFO - 2019-08-30 20:11:20 --> Language Class Initialized
INFO - 2019-08-30 20:11:20 --> Loader Class Initialized
INFO - 2019-08-30 20:11:20 --> Helper loaded: url_helper
INFO - 2019-08-30 20:11:20 --> Database Driver Class Initialized
DEBUG - 2019-08-30 20:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 20:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 20:11:28 --> Controller Class Initialized
DEBUG - 2019-08-30 20:11:28 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-30 20:11:28 --> Helper loaded: inflector_helper
INFO - 2019-08-30 20:11:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-30 20:11:28 --> Model "Template_model" initialized
INFO - 2019-08-30 20:11:28 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-30 20:11:30 --> Final output sent to browser
DEBUG - 2019-08-30 20:11:30 --> Total execution time: 16.7737
DEBUG - 2019-08-30 20:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 20:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 20:11:35 --> Controller Class Initialized
INFO - 2019-08-30 20:11:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 20:11:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-30 20:11:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 20:11:35 --> Final output sent to browser
DEBUG - 2019-08-30 20:11:35 --> Total execution time: 15.1530
INFO - 2019-08-30 21:08:33 --> Config Class Initialized
INFO - 2019-08-30 21:08:33 --> Hooks Class Initialized
DEBUG - 2019-08-30 21:08:33 --> UTF-8 Support Enabled
INFO - 2019-08-30 21:08:33 --> Utf8 Class Initialized
INFO - 2019-08-30 21:08:33 --> URI Class Initialized
INFO - 2019-08-30 21:08:33 --> Router Class Initialized
INFO - 2019-08-30 21:08:33 --> Output Class Initialized
INFO - 2019-08-30 21:08:33 --> Security Class Initialized
DEBUG - 2019-08-30 21:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 21:08:33 --> Input Class Initialized
INFO - 2019-08-30 21:08:33 --> Language Class Initialized
INFO - 2019-08-30 21:08:33 --> Loader Class Initialized
INFO - 2019-08-30 21:08:33 --> Helper loaded: url_helper
INFO - 2019-08-30 21:08:33 --> Database Driver Class Initialized
DEBUG - 2019-08-30 21:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 21:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 21:08:51 --> Controller Class Initialized
INFO - 2019-08-30 21:08:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 21:08:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-30 21:08:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 21:08:51 --> Final output sent to browser
DEBUG - 2019-08-30 21:08:51 --> Total execution time: 18.0568
INFO - 2019-08-30 21:12:54 --> Config Class Initialized
INFO - 2019-08-30 21:12:54 --> Hooks Class Initialized
DEBUG - 2019-08-30 21:12:54 --> UTF-8 Support Enabled
INFO - 2019-08-30 21:12:54 --> Utf8 Class Initialized
INFO - 2019-08-30 21:12:54 --> URI Class Initialized
INFO - 2019-08-30 21:12:54 --> Router Class Initialized
INFO - 2019-08-30 21:12:54 --> Output Class Initialized
INFO - 2019-08-30 21:12:54 --> Security Class Initialized
DEBUG - 2019-08-30 21:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 21:12:54 --> Input Class Initialized
INFO - 2019-08-30 21:12:54 --> Language Class Initialized
INFO - 2019-08-30 21:12:54 --> Loader Class Initialized
INFO - 2019-08-30 21:12:54 --> Helper loaded: url_helper
INFO - 2019-08-30 21:12:54 --> Database Driver Class Initialized
DEBUG - 2019-08-30 21:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 21:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 21:13:15 --> Controller Class Initialized
INFO - 2019-08-30 21:13:15 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 21:13:15 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-30 21:13:15 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 21:13:15 --> Final output sent to browser
DEBUG - 2019-08-30 21:13:15 --> Total execution time: 21.7093
INFO - 2019-08-30 21:13:16 --> Config Class Initialized
INFO - 2019-08-30 21:13:16 --> Hooks Class Initialized
DEBUG - 2019-08-30 21:13:16 --> UTF-8 Support Enabled
INFO - 2019-08-30 21:13:16 --> Utf8 Class Initialized
INFO - 2019-08-30 21:13:16 --> URI Class Initialized
INFO - 2019-08-30 21:13:16 --> Router Class Initialized
INFO - 2019-08-30 21:13:16 --> Output Class Initialized
INFO - 2019-08-30 21:13:16 --> Security Class Initialized
DEBUG - 2019-08-30 21:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 21:13:16 --> Input Class Initialized
INFO - 2019-08-30 21:13:16 --> Language Class Initialized
INFO - 2019-08-30 21:13:16 --> Loader Class Initialized
INFO - 2019-08-30 21:13:16 --> Helper loaded: url_helper
INFO - 2019-08-30 21:13:16 --> Database Driver Class Initialized
DEBUG - 2019-08-30 21:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 21:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 21:13:37 --> Controller Class Initialized
INFO - 2019-08-30 21:13:37 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 21:13:37 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-08-30 21:13:37 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 21:13:37 --> Final output sent to browser
DEBUG - 2019-08-30 21:13:37 --> Total execution time: 21.2843
INFO - 2019-08-30 21:16:59 --> Config Class Initialized
INFO - 2019-08-30 21:16:59 --> Hooks Class Initialized
DEBUG - 2019-08-30 21:16:59 --> UTF-8 Support Enabled
INFO - 2019-08-30 21:16:59 --> Utf8 Class Initialized
INFO - 2019-08-30 21:16:59 --> URI Class Initialized
INFO - 2019-08-30 21:16:59 --> Router Class Initialized
INFO - 2019-08-30 21:16:59 --> Output Class Initialized
INFO - 2019-08-30 21:16:59 --> Security Class Initialized
DEBUG - 2019-08-30 21:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 21:16:59 --> Input Class Initialized
INFO - 2019-08-30 21:16:59 --> Language Class Initialized
INFO - 2019-08-30 21:16:59 --> Loader Class Initialized
INFO - 2019-08-30 21:16:59 --> Helper loaded: url_helper
INFO - 2019-08-30 21:16:59 --> Database Driver Class Initialized
DEBUG - 2019-08-30 21:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 21:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 21:17:19 --> Controller Class Initialized
INFO - 2019-08-30 21:17:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 21:17:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-08-30 21:17:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 21:17:19 --> Final output sent to browser
DEBUG - 2019-08-30 21:17:19 --> Total execution time: 20.4231
INFO - 2019-08-30 21:17:27 --> Config Class Initialized
INFO - 2019-08-30 21:17:27 --> Hooks Class Initialized
DEBUG - 2019-08-30 21:17:27 --> UTF-8 Support Enabled
INFO - 2019-08-30 21:17:27 --> Utf8 Class Initialized
INFO - 2019-08-30 21:17:27 --> URI Class Initialized
INFO - 2019-08-30 21:17:27 --> Router Class Initialized
INFO - 2019-08-30 21:17:27 --> Output Class Initialized
INFO - 2019-08-30 21:17:27 --> Security Class Initialized
DEBUG - 2019-08-30 21:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 21:17:27 --> Input Class Initialized
INFO - 2019-08-30 21:17:27 --> Language Class Initialized
INFO - 2019-08-30 21:17:27 --> Loader Class Initialized
INFO - 2019-08-30 21:17:27 --> Helper loaded: url_helper
INFO - 2019-08-30 21:17:27 --> Database Driver Class Initialized
INFO - 2019-08-30 21:17:33 --> Config Class Initialized
INFO - 2019-08-30 21:17:33 --> Hooks Class Initialized
DEBUG - 2019-08-30 21:17:33 --> UTF-8 Support Enabled
INFO - 2019-08-30 21:17:33 --> Utf8 Class Initialized
INFO - 2019-08-30 21:17:33 --> URI Class Initialized
INFO - 2019-08-30 21:17:33 --> Router Class Initialized
INFO - 2019-08-30 21:17:33 --> Output Class Initialized
INFO - 2019-08-30 21:17:33 --> Security Class Initialized
DEBUG - 2019-08-30 21:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 21:17:33 --> Input Class Initialized
INFO - 2019-08-30 21:17:33 --> Language Class Initialized
INFO - 2019-08-30 21:17:33 --> Loader Class Initialized
INFO - 2019-08-30 21:17:33 --> Helper loaded: url_helper
INFO - 2019-08-30 21:17:33 --> Database Driver Class Initialized
DEBUG - 2019-08-30 21:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 21:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 21:17:48 --> Controller Class Initialized
DEBUG - 2019-08-30 21:17:48 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-30 21:17:48 --> Helper loaded: inflector_helper
INFO - 2019-08-30 21:17:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-30 21:17:48 --> Model "Form_model" initialized
DEBUG - 2019-08-30 21:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 21:17:52 --> Final output sent to browser
DEBUG - 2019-08-30 21:17:52 --> Total execution time: 25.8085
INFO - 2019-08-30 21:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 21:17:52 --> Controller Class Initialized
INFO - 2019-08-30 21:17:52 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 21:17:52 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-08-30 21:17:52 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 21:17:52 --> Final output sent to browser
DEBUG - 2019-08-30 21:17:52 --> Total execution time: 19.4691
INFO - 2019-08-30 21:17:52 --> Config Class Initialized
INFO - 2019-08-30 21:17:52 --> Hooks Class Initialized
DEBUG - 2019-08-30 21:17:52 --> UTF-8 Support Enabled
INFO - 2019-08-30 21:17:52 --> Utf8 Class Initialized
INFO - 2019-08-30 21:17:52 --> URI Class Initialized
INFO - 2019-08-30 21:17:52 --> Router Class Initialized
INFO - 2019-08-30 21:17:52 --> Output Class Initialized
INFO - 2019-08-30 21:17:52 --> Security Class Initialized
DEBUG - 2019-08-30 21:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 21:17:52 --> Input Class Initialized
INFO - 2019-08-30 21:17:52 --> Language Class Initialized
INFO - 2019-08-30 21:17:52 --> Loader Class Initialized
INFO - 2019-08-30 21:17:52 --> Helper loaded: url_helper
INFO - 2019-08-30 21:17:52 --> Database Driver Class Initialized
INFO - 2019-08-30 21:17:58 --> Config Class Initialized
INFO - 2019-08-30 21:17:58 --> Hooks Class Initialized
DEBUG - 2019-08-30 21:17:58 --> UTF-8 Support Enabled
INFO - 2019-08-30 21:17:58 --> Utf8 Class Initialized
INFO - 2019-08-30 21:17:58 --> URI Class Initialized
INFO - 2019-08-30 21:17:58 --> Router Class Initialized
INFO - 2019-08-30 21:17:58 --> Output Class Initialized
INFO - 2019-08-30 21:17:58 --> Security Class Initialized
DEBUG - 2019-08-30 21:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 21:17:58 --> Input Class Initialized
INFO - 2019-08-30 21:17:58 --> Language Class Initialized
INFO - 2019-08-30 21:17:58 --> Loader Class Initialized
INFO - 2019-08-30 21:17:58 --> Helper loaded: url_helper
INFO - 2019-08-30 21:17:58 --> Database Driver Class Initialized
DEBUG - 2019-08-30 21:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 21:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 21:18:07 --> Controller Class Initialized
INFO - 2019-08-30 21:18:07 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 21:18:07 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-30 21:18:07 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 21:18:07 --> Final output sent to browser
DEBUG - 2019-08-30 21:18:07 --> Total execution time: 15.1398
DEBUG - 2019-08-30 21:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 21:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 21:18:21 --> Controller Class Initialized
INFO - 2019-08-30 21:18:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 21:18:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-08-30 21:18:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 21:18:21 --> Final output sent to browser
DEBUG - 2019-08-30 21:18:21 --> Total execution time: 23.0649
INFO - 2019-08-30 21:19:06 --> Config Class Initialized
INFO - 2019-08-30 21:19:06 --> Hooks Class Initialized
DEBUG - 2019-08-30 21:19:06 --> UTF-8 Support Enabled
INFO - 2019-08-30 21:19:06 --> Utf8 Class Initialized
INFO - 2019-08-30 21:19:06 --> URI Class Initialized
INFO - 2019-08-30 21:19:06 --> Router Class Initialized
INFO - 2019-08-30 21:19:06 --> Output Class Initialized
INFO - 2019-08-30 21:19:06 --> Security Class Initialized
DEBUG - 2019-08-30 21:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 21:19:06 --> Input Class Initialized
INFO - 2019-08-30 21:19:06 --> Language Class Initialized
INFO - 2019-08-30 21:19:06 --> Loader Class Initialized
INFO - 2019-08-30 21:19:06 --> Helper loaded: url_helper
INFO - 2019-08-30 21:19:06 --> Database Driver Class Initialized
DEBUG - 2019-08-30 21:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 21:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 21:19:32 --> Controller Class Initialized
INFO - 2019-08-30 21:19:32 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-30 21:19:32 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-08-30 21:19:32 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-30 21:19:32 --> Final output sent to browser
DEBUG - 2019-08-30 21:19:32 --> Total execution time: 26.0404
INFO - 2019-08-30 21:19:33 --> Config Class Initialized
INFO - 2019-08-30 21:19:33 --> Hooks Class Initialized
DEBUG - 2019-08-30 21:19:33 --> UTF-8 Support Enabled
INFO - 2019-08-30 21:19:33 --> Utf8 Class Initialized
INFO - 2019-08-30 21:19:33 --> URI Class Initialized
INFO - 2019-08-30 21:19:33 --> Router Class Initialized
INFO - 2019-08-30 21:19:33 --> Output Class Initialized
INFO - 2019-08-30 21:19:33 --> Security Class Initialized
DEBUG - 2019-08-30 21:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-30 21:19:33 --> Input Class Initialized
INFO - 2019-08-30 21:19:33 --> Language Class Initialized
INFO - 2019-08-30 21:19:33 --> Loader Class Initialized
INFO - 2019-08-30 21:19:33 --> Helper loaded: url_helper
INFO - 2019-08-30 21:19:33 --> Database Driver Class Initialized
DEBUG - 2019-08-30 21:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-30 21:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-30 21:19:42 --> Controller Class Initialized
DEBUG - 2019-08-30 21:19:42 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-30 21:19:42 --> Helper loaded: inflector_helper
INFO - 2019-08-30 21:19:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-30 21:19:42 --> Model "Template_model" initialized
INFO - 2019-08-30 21:19:42 --> Model "Khang_sinh_model" initialized
INFO - 2019-08-30 21:19:44 --> Final output sent to browser
DEBUG - 2019-08-30 21:19:44 --> Total execution time: 11.2458
