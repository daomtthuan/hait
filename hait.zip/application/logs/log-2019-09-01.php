<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-01 09:49:43 --> Config Class Initialized
INFO - 2019-09-01 09:49:43 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:49:43 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:49:43 --> Utf8 Class Initialized
INFO - 2019-09-01 09:49:43 --> URI Class Initialized
INFO - 2019-09-01 09:49:43 --> Router Class Initialized
INFO - 2019-09-01 09:49:43 --> Output Class Initialized
INFO - 2019-09-01 09:49:43 --> Security Class Initialized
DEBUG - 2019-09-01 09:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:49:43 --> Input Class Initialized
INFO - 2019-09-01 09:49:43 --> Language Class Initialized
INFO - 2019-09-01 09:49:43 --> Loader Class Initialized
INFO - 2019-09-01 09:49:43 --> Helper loaded: url_helper
INFO - 2019-09-01 09:49:43 --> Database Driver Class Initialized
INFO - 2019-09-01 09:49:46 --> Config Class Initialized
INFO - 2019-09-01 09:49:46 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:49:46 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:49:46 --> Utf8 Class Initialized
INFO - 2019-09-01 09:49:46 --> URI Class Initialized
INFO - 2019-09-01 09:49:46 --> Router Class Initialized
INFO - 2019-09-01 09:49:46 --> Output Class Initialized
INFO - 2019-09-01 09:49:46 --> Security Class Initialized
DEBUG - 2019-09-01 09:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:49:46 --> Input Class Initialized
INFO - 2019-09-01 09:49:46 --> Language Class Initialized
INFO - 2019-09-01 09:49:46 --> Loader Class Initialized
INFO - 2019-09-01 09:49:46 --> Helper loaded: url_helper
INFO - 2019-09-01 09:49:46 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:49:47 --> Controller Class Initialized
INFO - 2019-09-01 09:49:47 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 09:49:47 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-09-01 09:49:47 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 09:49:47 --> Final output sent to browser
DEBUG - 2019-09-01 09:49:47 --> Total execution time: 4.6410
DEBUG - 2019-09-01 09:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:49:50 --> Controller Class Initialized
INFO - 2019-09-01 09:49:50 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 09:49:50 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-09-01 09:49:50 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 09:49:50 --> Final output sent to browser
DEBUG - 2019-09-01 09:49:50 --> Total execution time: 4.3927
INFO - 2019-09-01 09:50:35 --> Config Class Initialized
INFO - 2019-09-01 09:50:35 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:50:35 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:50:35 --> Utf8 Class Initialized
INFO - 2019-09-01 09:50:35 --> URI Class Initialized
INFO - 2019-09-01 09:50:35 --> Router Class Initialized
INFO - 2019-09-01 09:50:35 --> Output Class Initialized
INFO - 2019-09-01 09:50:35 --> Security Class Initialized
DEBUG - 2019-09-01 09:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:50:35 --> Input Class Initialized
INFO - 2019-09-01 09:50:35 --> Language Class Initialized
INFO - 2019-09-01 09:50:35 --> Loader Class Initialized
INFO - 2019-09-01 09:50:35 --> Helper loaded: url_helper
INFO - 2019-09-01 09:50:35 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:50:37 --> Controller Class Initialized
INFO - 2019-09-01 09:50:37 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 09:50:37 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-09-01 09:50:37 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 09:50:37 --> Final output sent to browser
DEBUG - 2019-09-01 09:50:37 --> Total execution time: 1.1827
INFO - 2019-09-01 09:50:45 --> Config Class Initialized
INFO - 2019-09-01 09:50:45 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:50:45 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:50:45 --> Utf8 Class Initialized
INFO - 2019-09-01 09:50:45 --> URI Class Initialized
INFO - 2019-09-01 09:50:45 --> Router Class Initialized
INFO - 2019-09-01 09:50:45 --> Output Class Initialized
INFO - 2019-09-01 09:50:45 --> Security Class Initialized
DEBUG - 2019-09-01 09:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:50:45 --> Input Class Initialized
INFO - 2019-09-01 09:50:45 --> Language Class Initialized
INFO - 2019-09-01 09:50:45 --> Loader Class Initialized
INFO - 2019-09-01 09:50:45 --> Helper loaded: url_helper
INFO - 2019-09-01 09:50:45 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:50:47 --> Controller Class Initialized
DEBUG - 2019-09-01 09:50:47 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 09:50:47 --> Helper loaded: inflector_helper
INFO - 2019-09-01 09:50:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 09:50:47 --> Model "Form_model" initialized
INFO - 2019-09-01 09:50:47 --> Final output sent to browser
DEBUG - 2019-09-01 09:50:47 --> Total execution time: 1.9069
INFO - 2019-09-01 09:50:47 --> Config Class Initialized
INFO - 2019-09-01 09:50:47 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:50:47 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:50:47 --> Utf8 Class Initialized
INFO - 2019-09-01 09:50:47 --> URI Class Initialized
INFO - 2019-09-01 09:50:47 --> Router Class Initialized
INFO - 2019-09-01 09:50:47 --> Output Class Initialized
INFO - 2019-09-01 09:50:47 --> Security Class Initialized
DEBUG - 2019-09-01 09:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:50:47 --> Input Class Initialized
INFO - 2019-09-01 09:50:47 --> Language Class Initialized
INFO - 2019-09-01 09:50:47 --> Loader Class Initialized
INFO - 2019-09-01 09:50:47 --> Helper loaded: url_helper
INFO - 2019-09-01 09:50:47 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:50:49 --> Controller Class Initialized
INFO - 2019-09-01 09:50:49 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 09:50:49 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-09-01 09:50:49 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 09:50:49 --> Final output sent to browser
DEBUG - 2019-09-01 09:50:49 --> Total execution time: 1.1318
INFO - 2019-09-01 09:51:12 --> Config Class Initialized
INFO - 2019-09-01 09:51:12 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:51:12 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:51:12 --> Utf8 Class Initialized
INFO - 2019-09-01 09:51:12 --> URI Class Initialized
INFO - 2019-09-01 09:51:12 --> Router Class Initialized
INFO - 2019-09-01 09:51:12 --> Output Class Initialized
INFO - 2019-09-01 09:51:12 --> Security Class Initialized
DEBUG - 2019-09-01 09:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:51:12 --> Input Class Initialized
INFO - 2019-09-01 09:51:12 --> Language Class Initialized
INFO - 2019-09-01 09:51:12 --> Loader Class Initialized
INFO - 2019-09-01 09:51:12 --> Helper loaded: url_helper
INFO - 2019-09-01 09:51:12 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:51:21 --> Controller Class Initialized
INFO - 2019-09-01 09:51:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 09:51:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 09:51:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 09:51:21 --> Final output sent to browser
DEBUG - 2019-09-01 09:51:21 --> Total execution time: 9.6598
INFO - 2019-09-01 09:51:22 --> Config Class Initialized
INFO - 2019-09-01 09:51:22 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:51:22 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:51:22 --> Utf8 Class Initialized
INFO - 2019-09-01 09:51:22 --> URI Class Initialized
INFO - 2019-09-01 09:51:22 --> Router Class Initialized
INFO - 2019-09-01 09:51:22 --> Output Class Initialized
INFO - 2019-09-01 09:51:22 --> Security Class Initialized
DEBUG - 2019-09-01 09:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:51:22 --> Input Class Initialized
INFO - 2019-09-01 09:51:22 --> Language Class Initialized
INFO - 2019-09-01 09:51:22 --> Loader Class Initialized
INFO - 2019-09-01 09:51:22 --> Helper loaded: url_helper
INFO - 2019-09-01 09:51:22 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:51:45 --> Controller Class Initialized
DEBUG - 2019-09-01 09:51:45 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 09:51:45 --> Helper loaded: inflector_helper
INFO - 2019-09-01 09:51:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 09:51:45 --> Model "Template_model" initialized
INFO - 2019-09-01 09:51:45 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 09:51:45 --> Final output sent to browser
DEBUG - 2019-09-01 09:51:45 --> Total execution time: 23.6697
INFO - 2019-09-01 09:53:15 --> Config Class Initialized
INFO - 2019-09-01 09:53:15 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:53:15 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:53:15 --> Utf8 Class Initialized
INFO - 2019-09-01 09:53:15 --> URI Class Initialized
INFO - 2019-09-01 09:53:15 --> Router Class Initialized
INFO - 2019-09-01 09:53:15 --> Output Class Initialized
INFO - 2019-09-01 09:53:15 --> Security Class Initialized
DEBUG - 2019-09-01 09:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:53:15 --> Input Class Initialized
INFO - 2019-09-01 09:53:15 --> Language Class Initialized
INFO - 2019-09-01 09:53:15 --> Loader Class Initialized
INFO - 2019-09-01 09:53:15 --> Helper loaded: url_helper
INFO - 2019-09-01 09:53:15 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:53:16 --> Controller Class Initialized
INFO - 2019-09-01 09:53:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 09:53:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step3.php
INFO - 2019-09-01 09:53:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 09:53:16 --> Final output sent to browser
DEBUG - 2019-09-01 09:53:16 --> Total execution time: 1.1409
INFO - 2019-09-01 09:53:18 --> Config Class Initialized
INFO - 2019-09-01 09:53:18 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:53:18 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:53:18 --> Utf8 Class Initialized
INFO - 2019-09-01 09:53:18 --> URI Class Initialized
INFO - 2019-09-01 09:53:18 --> Router Class Initialized
INFO - 2019-09-01 09:53:18 --> Output Class Initialized
INFO - 2019-09-01 09:53:18 --> Security Class Initialized
DEBUG - 2019-09-01 09:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:53:18 --> Input Class Initialized
INFO - 2019-09-01 09:53:18 --> Language Class Initialized
INFO - 2019-09-01 09:53:18 --> Loader Class Initialized
INFO - 2019-09-01 09:53:18 --> Helper loaded: url_helper
INFO - 2019-09-01 09:53:18 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:53:19 --> Controller Class Initialized
INFO - 2019-09-01 09:53:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 09:53:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 09:53:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 09:53:19 --> Final output sent to browser
DEBUG - 2019-09-01 09:53:19 --> Total execution time: 1.1709
INFO - 2019-09-01 09:53:19 --> Config Class Initialized
INFO - 2019-09-01 09:53:19 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:53:19 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:53:19 --> Utf8 Class Initialized
INFO - 2019-09-01 09:53:19 --> URI Class Initialized
INFO - 2019-09-01 09:53:19 --> Router Class Initialized
INFO - 2019-09-01 09:53:19 --> Output Class Initialized
INFO - 2019-09-01 09:53:19 --> Security Class Initialized
DEBUG - 2019-09-01 09:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:53:19 --> Input Class Initialized
INFO - 2019-09-01 09:53:19 --> Language Class Initialized
INFO - 2019-09-01 09:53:19 --> Loader Class Initialized
INFO - 2019-09-01 09:53:19 --> Helper loaded: url_helper
INFO - 2019-09-01 09:53:19 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:53:20 --> Controller Class Initialized
DEBUG - 2019-09-01 09:53:20 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 09:53:20 --> Helper loaded: inflector_helper
INFO - 2019-09-01 09:53:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 09:53:20 --> Model "Template_model" initialized
INFO - 2019-09-01 09:53:20 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 09:53:22 --> Final output sent to browser
DEBUG - 2019-09-01 09:53:22 --> Total execution time: 2.8594
INFO - 2019-09-01 09:53:55 --> Config Class Initialized
INFO - 2019-09-01 09:53:55 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:53:55 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:53:55 --> Utf8 Class Initialized
INFO - 2019-09-01 09:53:55 --> URI Class Initialized
INFO - 2019-09-01 09:53:55 --> Router Class Initialized
INFO - 2019-09-01 09:53:55 --> Output Class Initialized
INFO - 2019-09-01 09:53:55 --> Security Class Initialized
DEBUG - 2019-09-01 09:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:53:55 --> Input Class Initialized
INFO - 2019-09-01 09:53:55 --> Language Class Initialized
INFO - 2019-09-01 09:53:55 --> Loader Class Initialized
INFO - 2019-09-01 09:53:55 --> Helper loaded: url_helper
INFO - 2019-09-01 09:53:55 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:54:01 --> Controller Class Initialized
INFO - 2019-09-01 09:54:01 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 09:54:01 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step3.php
INFO - 2019-09-01 09:54:01 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 09:54:01 --> Final output sent to browser
DEBUG - 2019-09-01 09:54:01 --> Total execution time: 6.1379
INFO - 2019-09-01 09:56:57 --> Config Class Initialized
INFO - 2019-09-01 09:56:57 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:56:57 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:56:57 --> Utf8 Class Initialized
INFO - 2019-09-01 09:56:57 --> URI Class Initialized
INFO - 2019-09-01 09:56:57 --> Router Class Initialized
INFO - 2019-09-01 09:56:57 --> Output Class Initialized
INFO - 2019-09-01 09:56:57 --> Security Class Initialized
DEBUG - 2019-09-01 09:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:56:57 --> Input Class Initialized
INFO - 2019-09-01 09:56:57 --> Language Class Initialized
INFO - 2019-09-01 09:56:57 --> Loader Class Initialized
INFO - 2019-09-01 09:56:57 --> Helper loaded: url_helper
INFO - 2019-09-01 09:56:57 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:56:58 --> Controller Class Initialized
INFO - 2019-09-01 09:56:58 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 09:56:58 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step3.php
INFO - 2019-09-01 09:56:58 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 09:56:58 --> Final output sent to browser
DEBUG - 2019-09-01 09:56:58 --> Total execution time: 1.1676
INFO - 2019-09-01 09:57:06 --> Config Class Initialized
INFO - 2019-09-01 09:57:06 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:57:06 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:57:06 --> Utf8 Class Initialized
INFO - 2019-09-01 09:57:06 --> URI Class Initialized
INFO - 2019-09-01 09:57:06 --> Router Class Initialized
INFO - 2019-09-01 09:57:06 --> Output Class Initialized
INFO - 2019-09-01 09:57:06 --> Security Class Initialized
DEBUG - 2019-09-01 09:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:57:06 --> Input Class Initialized
INFO - 2019-09-01 09:57:06 --> Language Class Initialized
INFO - 2019-09-01 09:57:06 --> Loader Class Initialized
INFO - 2019-09-01 09:57:06 --> Helper loaded: url_helper
INFO - 2019-09-01 09:57:06 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:57:07 --> Controller Class Initialized
INFO - 2019-09-01 09:57:07 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 09:57:07 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 09:57:07 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 09:57:07 --> Final output sent to browser
DEBUG - 2019-09-01 09:57:07 --> Total execution time: 1.1309
INFO - 2019-09-01 09:57:07 --> Config Class Initialized
INFO - 2019-09-01 09:57:07 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:57:07 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:57:07 --> Utf8 Class Initialized
INFO - 2019-09-01 09:57:07 --> URI Class Initialized
INFO - 2019-09-01 09:57:07 --> Router Class Initialized
INFO - 2019-09-01 09:57:07 --> Output Class Initialized
INFO - 2019-09-01 09:57:07 --> Security Class Initialized
DEBUG - 2019-09-01 09:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:57:07 --> Input Class Initialized
INFO - 2019-09-01 09:57:07 --> Language Class Initialized
INFO - 2019-09-01 09:57:07 --> Loader Class Initialized
INFO - 2019-09-01 09:57:07 --> Helper loaded: url_helper
INFO - 2019-09-01 09:57:07 --> Database Driver Class Initialized
INFO - 2019-09-01 09:57:10 --> Config Class Initialized
INFO - 2019-09-01 09:57:10 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:57:10 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:57:10 --> Utf8 Class Initialized
INFO - 2019-09-01 09:57:10 --> URI Class Initialized
INFO - 2019-09-01 09:57:10 --> Router Class Initialized
INFO - 2019-09-01 09:57:10 --> Output Class Initialized
INFO - 2019-09-01 09:57:10 --> Security Class Initialized
DEBUG - 2019-09-01 09:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:57:10 --> Input Class Initialized
INFO - 2019-09-01 09:57:10 --> Language Class Initialized
INFO - 2019-09-01 09:57:10 --> Loader Class Initialized
INFO - 2019-09-01 09:57:10 --> Helper loaded: url_helper
INFO - 2019-09-01 09:57:10 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:57:11 --> Controller Class Initialized
INFO - 2019-09-01 09:57:11 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 09:57:11 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-09-01 09:57:11 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 09:57:11 --> Final output sent to browser
DEBUG - 2019-09-01 09:57:11 --> Total execution time: 1.1301
DEBUG - 2019-09-01 09:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:57:17 --> Controller Class Initialized
DEBUG - 2019-09-01 09:57:17 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 09:57:17 --> Helper loaded: inflector_helper
INFO - 2019-09-01 09:57:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 09:57:17 --> Model "Template_model" initialized
INFO - 2019-09-01 09:57:17 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 09:57:17 --> Final output sent to browser
DEBUG - 2019-09-01 09:57:17 --> Total execution time: 9.4368
INFO - 2019-09-01 09:57:26 --> Config Class Initialized
INFO - 2019-09-01 09:57:26 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:57:26 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:57:26 --> Utf8 Class Initialized
INFO - 2019-09-01 09:57:26 --> URI Class Initialized
INFO - 2019-09-01 09:57:26 --> Router Class Initialized
INFO - 2019-09-01 09:57:26 --> Output Class Initialized
INFO - 2019-09-01 09:57:26 --> Security Class Initialized
DEBUG - 2019-09-01 09:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:57:26 --> Input Class Initialized
INFO - 2019-09-01 09:57:26 --> Language Class Initialized
INFO - 2019-09-01 09:57:26 --> Loader Class Initialized
INFO - 2019-09-01 09:57:26 --> Helper loaded: url_helper
INFO - 2019-09-01 09:57:26 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:57:35 --> Controller Class Initialized
INFO - 2019-09-01 09:57:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 09:57:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 09:57:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 09:57:35 --> Final output sent to browser
DEBUG - 2019-09-01 09:57:35 --> Total execution time: 9.1839
INFO - 2019-09-01 09:57:35 --> Config Class Initialized
INFO - 2019-09-01 09:57:35 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:57:35 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:57:35 --> Utf8 Class Initialized
INFO - 2019-09-01 09:57:35 --> URI Class Initialized
INFO - 2019-09-01 09:57:35 --> Router Class Initialized
INFO - 2019-09-01 09:57:35 --> Output Class Initialized
INFO - 2019-09-01 09:57:35 --> Security Class Initialized
DEBUG - 2019-09-01 09:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:57:35 --> Input Class Initialized
INFO - 2019-09-01 09:57:35 --> Language Class Initialized
INFO - 2019-09-01 09:57:35 --> Loader Class Initialized
INFO - 2019-09-01 09:57:35 --> Helper loaded: url_helper
INFO - 2019-09-01 09:57:35 --> Database Driver Class Initialized
INFO - 2019-09-01 09:57:39 --> Config Class Initialized
INFO - 2019-09-01 09:57:39 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:57:39 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:57:39 --> Utf8 Class Initialized
INFO - 2019-09-01 09:57:39 --> URI Class Initialized
INFO - 2019-09-01 09:57:39 --> Router Class Initialized
INFO - 2019-09-01 09:57:39 --> Output Class Initialized
INFO - 2019-09-01 09:57:39 --> Security Class Initialized
DEBUG - 2019-09-01 09:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:57:39 --> Input Class Initialized
INFO - 2019-09-01 09:57:39 --> Language Class Initialized
INFO - 2019-09-01 09:57:39 --> Loader Class Initialized
INFO - 2019-09-01 09:57:39 --> Helper loaded: url_helper
INFO - 2019-09-01 09:57:39 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:57:45 --> Controller Class Initialized
INFO - 2019-09-01 09:57:45 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 09:57:45 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step3.php
INFO - 2019-09-01 09:57:45 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 09:57:45 --> Final output sent to browser
DEBUG - 2019-09-01 09:57:45 --> Total execution time: 6.1537
DEBUG - 2019-09-01 09:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:57:50 --> Controller Class Initialized
DEBUG - 2019-09-01 09:57:50 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 09:57:50 --> Helper loaded: inflector_helper
INFO - 2019-09-01 09:57:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 09:57:50 --> Model "Template_model" initialized
INFO - 2019-09-01 09:57:50 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 09:57:51 --> Final output sent to browser
DEBUG - 2019-09-01 09:57:51 --> Total execution time: 15.9629
INFO - 2019-09-01 09:58:21 --> Config Class Initialized
INFO - 2019-09-01 09:58:21 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:58:21 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:58:21 --> Utf8 Class Initialized
INFO - 2019-09-01 09:58:21 --> URI Class Initialized
INFO - 2019-09-01 09:58:21 --> Router Class Initialized
INFO - 2019-09-01 09:58:21 --> Output Class Initialized
INFO - 2019-09-01 09:58:21 --> Security Class Initialized
DEBUG - 2019-09-01 09:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:58:21 --> Input Class Initialized
INFO - 2019-09-01 09:58:21 --> Language Class Initialized
INFO - 2019-09-01 09:58:21 --> Loader Class Initialized
INFO - 2019-09-01 09:58:21 --> Helper loaded: url_helper
INFO - 2019-09-01 09:58:21 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:58:22 --> Controller Class Initialized
INFO - 2019-09-01 09:58:22 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 09:58:22 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step3.php
INFO - 2019-09-01 09:58:22 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 09:58:22 --> Final output sent to browser
DEBUG - 2019-09-01 09:58:22 --> Total execution time: 1.1781
INFO - 2019-09-01 09:58:32 --> Config Class Initialized
INFO - 2019-09-01 09:58:32 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:58:32 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:58:32 --> Utf8 Class Initialized
INFO - 2019-09-01 09:58:32 --> URI Class Initialized
INFO - 2019-09-01 09:58:32 --> Router Class Initialized
INFO - 2019-09-01 09:58:32 --> Output Class Initialized
INFO - 2019-09-01 09:58:32 --> Security Class Initialized
DEBUG - 2019-09-01 09:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:58:32 --> Input Class Initialized
INFO - 2019-09-01 09:58:32 --> Language Class Initialized
INFO - 2019-09-01 09:58:32 --> Loader Class Initialized
INFO - 2019-09-01 09:58:32 --> Helper loaded: url_helper
INFO - 2019-09-01 09:58:32 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:58:33 --> Controller Class Initialized
INFO - 2019-09-01 09:58:33 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 09:58:33 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 09:58:33 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 09:58:33 --> Final output sent to browser
DEBUG - 2019-09-01 09:58:33 --> Total execution time: 1.1669
INFO - 2019-09-01 09:58:34 --> Config Class Initialized
INFO - 2019-09-01 09:58:34 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:58:34 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:58:34 --> Utf8 Class Initialized
INFO - 2019-09-01 09:58:34 --> URI Class Initialized
INFO - 2019-09-01 09:58:34 --> Router Class Initialized
INFO - 2019-09-01 09:58:34 --> Output Class Initialized
INFO - 2019-09-01 09:58:34 --> Security Class Initialized
DEBUG - 2019-09-01 09:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:58:34 --> Input Class Initialized
INFO - 2019-09-01 09:58:34 --> Language Class Initialized
INFO - 2019-09-01 09:58:34 --> Loader Class Initialized
INFO - 2019-09-01 09:58:34 --> Helper loaded: url_helper
INFO - 2019-09-01 09:58:34 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:58:35 --> Controller Class Initialized
DEBUG - 2019-09-01 09:58:35 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 09:58:35 --> Helper loaded: inflector_helper
INFO - 2019-09-01 09:58:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 09:58:35 --> Model "Template_model" initialized
INFO - 2019-09-01 09:58:35 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 09:58:36 --> Final output sent to browser
DEBUG - 2019-09-01 09:58:36 --> Total execution time: 1.8603
INFO - 2019-09-01 09:58:39 --> Config Class Initialized
INFO - 2019-09-01 09:58:39 --> Hooks Class Initialized
DEBUG - 2019-09-01 09:58:39 --> UTF-8 Support Enabled
INFO - 2019-09-01 09:58:39 --> Utf8 Class Initialized
INFO - 2019-09-01 09:58:39 --> URI Class Initialized
INFO - 2019-09-01 09:58:39 --> Router Class Initialized
INFO - 2019-09-01 09:58:39 --> Output Class Initialized
INFO - 2019-09-01 09:58:39 --> Security Class Initialized
DEBUG - 2019-09-01 09:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 09:58:39 --> Input Class Initialized
INFO - 2019-09-01 09:58:39 --> Language Class Initialized
INFO - 2019-09-01 09:58:39 --> Loader Class Initialized
INFO - 2019-09-01 09:58:39 --> Helper loaded: url_helper
INFO - 2019-09-01 09:58:39 --> Database Driver Class Initialized
DEBUG - 2019-09-01 09:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 09:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 09:58:40 --> Controller Class Initialized
INFO - 2019-09-01 09:58:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 09:58:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step3.php
INFO - 2019-09-01 09:58:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 09:58:40 --> Final output sent to browser
DEBUG - 2019-09-01 09:58:40 --> Total execution time: 1.1941
INFO - 2019-09-01 10:01:31 --> Config Class Initialized
INFO - 2019-09-01 10:01:31 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:01:31 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:01:31 --> Utf8 Class Initialized
INFO - 2019-09-01 10:01:31 --> URI Class Initialized
INFO - 2019-09-01 10:01:31 --> Router Class Initialized
INFO - 2019-09-01 10:01:31 --> Output Class Initialized
INFO - 2019-09-01 10:01:31 --> Security Class Initialized
DEBUG - 2019-09-01 10:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:01:31 --> Input Class Initialized
INFO - 2019-09-01 10:01:31 --> Language Class Initialized
INFO - 2019-09-01 10:01:31 --> Loader Class Initialized
INFO - 2019-09-01 10:01:31 --> Helper loaded: url_helper
INFO - 2019-09-01 10:01:31 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:01:46 --> Controller Class Initialized
INFO - 2019-09-01 10:01:46 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:01:46 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-09-01 10:01:46 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:01:46 --> Final output sent to browser
DEBUG - 2019-09-01 10:01:46 --> Total execution time: 15.2926
INFO - 2019-09-01 10:03:14 --> Config Class Initialized
INFO - 2019-09-01 10:03:14 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:03:14 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:03:14 --> Utf8 Class Initialized
INFO - 2019-09-01 10:03:14 --> URI Class Initialized
INFO - 2019-09-01 10:03:14 --> Router Class Initialized
INFO - 2019-09-01 10:03:14 --> Output Class Initialized
INFO - 2019-09-01 10:03:14 --> Security Class Initialized
DEBUG - 2019-09-01 10:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:03:14 --> Input Class Initialized
INFO - 2019-09-01 10:03:14 --> Language Class Initialized
INFO - 2019-09-01 10:03:14 --> Loader Class Initialized
INFO - 2019-09-01 10:03:14 --> Helper loaded: url_helper
INFO - 2019-09-01 10:03:14 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:03:16 --> Controller Class Initialized
DEBUG - 2019-09-01 10:03:16 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 10:03:16 --> Helper loaded: inflector_helper
INFO - 2019-09-01 10:03:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 10:03:16 --> Model "Form_model" initialized
INFO - 2019-09-01 10:03:16 --> Final output sent to browser
DEBUG - 2019-09-01 10:03:16 --> Total execution time: 2.1587
INFO - 2019-09-01 10:03:16 --> Config Class Initialized
INFO - 2019-09-01 10:03:16 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:03:16 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:03:16 --> Utf8 Class Initialized
INFO - 2019-09-01 10:03:16 --> URI Class Initialized
INFO - 2019-09-01 10:03:16 --> Router Class Initialized
INFO - 2019-09-01 10:03:16 --> Output Class Initialized
INFO - 2019-09-01 10:03:16 --> Security Class Initialized
DEBUG - 2019-09-01 10:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:03:17 --> Input Class Initialized
INFO - 2019-09-01 10:03:17 --> Language Class Initialized
INFO - 2019-09-01 10:03:17 --> Loader Class Initialized
INFO - 2019-09-01 10:03:17 --> Helper loaded: url_helper
INFO - 2019-09-01 10:03:17 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:03:18 --> Controller Class Initialized
INFO - 2019-09-01 10:03:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:03:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-09-01 10:03:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:03:18 --> Final output sent to browser
DEBUG - 2019-09-01 10:03:18 --> Total execution time: 1.1349
INFO - 2019-09-01 10:04:55 --> Config Class Initialized
INFO - 2019-09-01 10:04:55 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:04:55 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:04:55 --> Utf8 Class Initialized
INFO - 2019-09-01 10:04:55 --> URI Class Initialized
INFO - 2019-09-01 10:04:55 --> Router Class Initialized
INFO - 2019-09-01 10:04:55 --> Output Class Initialized
INFO - 2019-09-01 10:04:55 --> Security Class Initialized
DEBUG - 2019-09-01 10:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:04:55 --> Input Class Initialized
INFO - 2019-09-01 10:04:55 --> Language Class Initialized
INFO - 2019-09-01 10:04:55 --> Loader Class Initialized
INFO - 2019-09-01 10:04:55 --> Helper loaded: url_helper
INFO - 2019-09-01 10:04:55 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:04:56 --> Controller Class Initialized
INFO - 2019-09-01 10:04:56 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:04:56 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 10:04:56 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:04:56 --> Final output sent to browser
DEBUG - 2019-09-01 10:04:56 --> Total execution time: 1.1714
INFO - 2019-09-01 10:04:57 --> Config Class Initialized
INFO - 2019-09-01 10:04:57 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:04:57 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:04:57 --> Utf8 Class Initialized
INFO - 2019-09-01 10:04:57 --> URI Class Initialized
INFO - 2019-09-01 10:04:57 --> Router Class Initialized
INFO - 2019-09-01 10:04:57 --> Output Class Initialized
INFO - 2019-09-01 10:04:57 --> Security Class Initialized
DEBUG - 2019-09-01 10:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:04:57 --> Input Class Initialized
INFO - 2019-09-01 10:04:57 --> Language Class Initialized
INFO - 2019-09-01 10:04:57 --> Loader Class Initialized
INFO - 2019-09-01 10:04:57 --> Helper loaded: url_helper
INFO - 2019-09-01 10:04:57 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:04:58 --> Controller Class Initialized
DEBUG - 2019-09-01 10:04:58 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 10:04:58 --> Helper loaded: inflector_helper
INFO - 2019-09-01 10:04:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 10:04:58 --> Model "Template_model" initialized
INFO - 2019-09-01 10:04:58 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 10:05:00 --> Final output sent to browser
DEBUG - 2019-09-01 10:05:00 --> Total execution time: 2.8847
INFO - 2019-09-01 10:05:09 --> Config Class Initialized
INFO - 2019-09-01 10:05:09 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:05:09 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:05:09 --> Utf8 Class Initialized
INFO - 2019-09-01 10:05:09 --> URI Class Initialized
INFO - 2019-09-01 10:05:09 --> Router Class Initialized
INFO - 2019-09-01 10:05:09 --> Output Class Initialized
INFO - 2019-09-01 10:05:09 --> Security Class Initialized
DEBUG - 2019-09-01 10:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:05:09 --> Input Class Initialized
INFO - 2019-09-01 10:05:09 --> Language Class Initialized
INFO - 2019-09-01 10:05:09 --> Loader Class Initialized
INFO - 2019-09-01 10:05:09 --> Helper loaded: url_helper
INFO - 2019-09-01 10:05:09 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:05:15 --> Controller Class Initialized
INFO - 2019-09-01 10:05:15 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:05:15 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step3.php
INFO - 2019-09-01 10:05:15 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:05:15 --> Final output sent to browser
DEBUG - 2019-09-01 10:05:15 --> Total execution time: 6.1545
INFO - 2019-09-01 10:05:22 --> Config Class Initialized
INFO - 2019-09-01 10:05:22 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:05:22 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:05:22 --> Utf8 Class Initialized
INFO - 2019-09-01 10:05:22 --> URI Class Initialized
INFO - 2019-09-01 10:05:22 --> Router Class Initialized
INFO - 2019-09-01 10:05:22 --> Output Class Initialized
INFO - 2019-09-01 10:05:22 --> Security Class Initialized
DEBUG - 2019-09-01 10:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:05:22 --> Input Class Initialized
INFO - 2019-09-01 10:05:22 --> Language Class Initialized
INFO - 2019-09-01 10:05:22 --> Loader Class Initialized
INFO - 2019-09-01 10:05:22 --> Helper loaded: url_helper
INFO - 2019-09-01 10:05:22 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:05:23 --> Controller Class Initialized
INFO - 2019-09-01 10:05:23 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:05:23 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step4.php
INFO - 2019-09-01 10:05:23 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:05:23 --> Final output sent to browser
DEBUG - 2019-09-01 10:05:23 --> Total execution time: 1.1352
INFO - 2019-09-01 10:13:45 --> Config Class Initialized
INFO - 2019-09-01 10:13:45 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:13:45 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:13:45 --> Utf8 Class Initialized
INFO - 2019-09-01 10:13:45 --> URI Class Initialized
INFO - 2019-09-01 10:13:45 --> Router Class Initialized
INFO - 2019-09-01 10:13:45 --> Output Class Initialized
INFO - 2019-09-01 10:13:45 --> Security Class Initialized
DEBUG - 2019-09-01 10:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:13:45 --> Input Class Initialized
INFO - 2019-09-01 10:13:45 --> Language Class Initialized
INFO - 2019-09-01 10:13:45 --> Loader Class Initialized
INFO - 2019-09-01 10:13:45 --> Helper loaded: url_helper
INFO - 2019-09-01 10:13:45 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:13:47 --> Controller Class Initialized
INFO - 2019-09-01 10:13:47 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:13:47 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step5.php
INFO - 2019-09-01 10:13:47 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:13:47 --> Final output sent to browser
DEBUG - 2019-09-01 10:13:47 --> Total execution time: 1.5709
INFO - 2019-09-01 10:13:48 --> Config Class Initialized
INFO - 2019-09-01 10:13:48 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:13:48 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:13:48 --> Utf8 Class Initialized
INFO - 2019-09-01 10:13:48 --> URI Class Initialized
INFO - 2019-09-01 10:13:48 --> Router Class Initialized
INFO - 2019-09-01 10:13:48 --> Output Class Initialized
INFO - 2019-09-01 10:13:48 --> Security Class Initialized
DEBUG - 2019-09-01 10:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:13:48 --> Input Class Initialized
INFO - 2019-09-01 10:13:48 --> Language Class Initialized
INFO - 2019-09-01 10:13:48 --> Loader Class Initialized
INFO - 2019-09-01 10:13:48 --> Helper loaded: url_helper
INFO - 2019-09-01 10:13:48 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:13:50 --> Controller Class Initialized
INFO - 2019-09-01 10:13:50 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:13:50 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step4.php
INFO - 2019-09-01 10:13:50 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:13:50 --> Final output sent to browser
DEBUG - 2019-09-01 10:13:50 --> Total execution time: 1.2653
INFO - 2019-09-01 10:13:52 --> Config Class Initialized
INFO - 2019-09-01 10:13:52 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:13:52 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:13:52 --> Utf8 Class Initialized
INFO - 2019-09-01 10:13:52 --> URI Class Initialized
INFO - 2019-09-01 10:13:52 --> Router Class Initialized
INFO - 2019-09-01 10:13:52 --> Output Class Initialized
INFO - 2019-09-01 10:13:52 --> Security Class Initialized
DEBUG - 2019-09-01 10:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:13:52 --> Input Class Initialized
INFO - 2019-09-01 10:13:52 --> Language Class Initialized
INFO - 2019-09-01 10:13:52 --> Loader Class Initialized
INFO - 2019-09-01 10:13:52 --> Helper loaded: url_helper
INFO - 2019-09-01 10:13:52 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:13:54 --> Controller Class Initialized
INFO - 2019-09-01 10:13:54 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:13:54 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step5.php
INFO - 2019-09-01 10:13:54 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:13:54 --> Final output sent to browser
DEBUG - 2019-09-01 10:13:54 --> Total execution time: 1.3062
INFO - 2019-09-01 10:14:12 --> Config Class Initialized
INFO - 2019-09-01 10:14:12 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:14:12 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:14:12 --> Utf8 Class Initialized
INFO - 2019-09-01 10:14:12 --> URI Class Initialized
INFO - 2019-09-01 10:14:12 --> Router Class Initialized
INFO - 2019-09-01 10:14:12 --> Output Class Initialized
INFO - 2019-09-01 10:14:12 --> Security Class Initialized
DEBUG - 2019-09-01 10:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:14:12 --> Input Class Initialized
INFO - 2019-09-01 10:14:12 --> Language Class Initialized
INFO - 2019-09-01 10:14:12 --> Loader Class Initialized
INFO - 2019-09-01 10:14:12 --> Helper loaded: url_helper
INFO - 2019-09-01 10:14:12 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:14:22 --> Controller Class Initialized
INFO - 2019-09-01 10:14:22 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:14:22 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step6.php
INFO - 2019-09-01 10:14:22 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:14:22 --> Final output sent to browser
DEBUG - 2019-09-01 10:14:22 --> Total execution time: 9.2757
INFO - 2019-09-01 10:14:30 --> Config Class Initialized
INFO - 2019-09-01 10:14:30 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:14:30 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:14:30 --> Utf8 Class Initialized
INFO - 2019-09-01 10:14:30 --> URI Class Initialized
INFO - 2019-09-01 10:14:30 --> Router Class Initialized
INFO - 2019-09-01 10:14:30 --> Output Class Initialized
INFO - 2019-09-01 10:14:30 --> Security Class Initialized
DEBUG - 2019-09-01 10:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:14:30 --> Input Class Initialized
INFO - 2019-09-01 10:14:30 --> Language Class Initialized
INFO - 2019-09-01 10:14:30 --> Loader Class Initialized
INFO - 2019-09-01 10:14:30 --> Helper loaded: url_helper
INFO - 2019-09-01 10:14:30 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:14:31 --> Controller Class Initialized
INFO - 2019-09-01 10:14:31 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:14:31 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step5.php
INFO - 2019-09-01 10:14:31 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:14:31 --> Final output sent to browser
DEBUG - 2019-09-01 10:14:31 --> Total execution time: 1.2460
INFO - 2019-09-01 10:14:37 --> Config Class Initialized
INFO - 2019-09-01 10:14:37 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:14:37 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:14:37 --> Utf8 Class Initialized
INFO - 2019-09-01 10:14:37 --> URI Class Initialized
INFO - 2019-09-01 10:14:37 --> Router Class Initialized
INFO - 2019-09-01 10:14:37 --> Output Class Initialized
INFO - 2019-09-01 10:14:37 --> Security Class Initialized
DEBUG - 2019-09-01 10:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:14:37 --> Input Class Initialized
INFO - 2019-09-01 10:14:37 --> Language Class Initialized
INFO - 2019-09-01 10:14:37 --> Loader Class Initialized
INFO - 2019-09-01 10:14:37 --> Helper loaded: url_helper
INFO - 2019-09-01 10:14:37 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:14:39 --> Controller Class Initialized
INFO - 2019-09-01 10:14:39 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:14:39 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step6.php
INFO - 2019-09-01 10:14:39 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:14:39 --> Final output sent to browser
DEBUG - 2019-09-01 10:14:39 --> Total execution time: 1.3254
INFO - 2019-09-01 10:14:41 --> Config Class Initialized
INFO - 2019-09-01 10:14:41 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:14:41 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:14:41 --> Utf8 Class Initialized
INFO - 2019-09-01 10:14:41 --> URI Class Initialized
INFO - 2019-09-01 10:14:41 --> Router Class Initialized
INFO - 2019-09-01 10:14:41 --> Output Class Initialized
INFO - 2019-09-01 10:14:41 --> Security Class Initialized
DEBUG - 2019-09-01 10:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:14:41 --> Input Class Initialized
INFO - 2019-09-01 10:14:41 --> Language Class Initialized
INFO - 2019-09-01 10:14:42 --> Loader Class Initialized
INFO - 2019-09-01 10:14:42 --> Helper loaded: url_helper
INFO - 2019-09-01 10:14:42 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:14:51 --> Controller Class Initialized
INFO - 2019-09-01 10:14:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:14:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step5.php
INFO - 2019-09-01 10:14:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:14:51 --> Final output sent to browser
DEBUG - 2019-09-01 10:14:51 --> Total execution time: 9.2522
INFO - 2019-09-01 10:15:00 --> Config Class Initialized
INFO - 2019-09-01 10:15:00 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:15:00 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:15:00 --> Utf8 Class Initialized
INFO - 2019-09-01 10:15:00 --> URI Class Initialized
INFO - 2019-09-01 10:15:00 --> Router Class Initialized
INFO - 2019-09-01 10:15:00 --> Output Class Initialized
INFO - 2019-09-01 10:15:00 --> Security Class Initialized
DEBUG - 2019-09-01 10:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:15:00 --> Input Class Initialized
INFO - 2019-09-01 10:15:00 --> Language Class Initialized
INFO - 2019-09-01 10:15:00 --> Loader Class Initialized
INFO - 2019-09-01 10:15:00 --> Helper loaded: url_helper
INFO - 2019-09-01 10:15:00 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:15:06 --> Controller Class Initialized
INFO - 2019-09-01 10:15:06 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:15:06 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step6.php
INFO - 2019-09-01 10:15:06 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:15:06 --> Final output sent to browser
DEBUG - 2019-09-01 10:15:06 --> Total execution time: 6.3263
INFO - 2019-09-01 10:32:17 --> Config Class Initialized
INFO - 2019-09-01 10:32:17 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:32:17 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:32:17 --> Utf8 Class Initialized
INFO - 2019-09-01 10:32:17 --> URI Class Initialized
INFO - 2019-09-01 10:32:17 --> Router Class Initialized
INFO - 2019-09-01 10:32:17 --> Output Class Initialized
INFO - 2019-09-01 10:32:17 --> Security Class Initialized
DEBUG - 2019-09-01 10:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:32:17 --> Input Class Initialized
INFO - 2019-09-01 10:32:17 --> Language Class Initialized
INFO - 2019-09-01 10:32:17 --> Loader Class Initialized
INFO - 2019-09-01 10:32:17 --> Helper loaded: url_helper
INFO - 2019-09-01 10:32:17 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:32:23 --> Controller Class Initialized
INFO - 2019-09-01 10:32:23 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:32:23 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step5.php
INFO - 2019-09-01 10:32:23 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:32:23 --> Final output sent to browser
DEBUG - 2019-09-01 10:32:23 --> Total execution time: 6.1604
INFO - 2019-09-01 10:32:28 --> Config Class Initialized
INFO - 2019-09-01 10:32:28 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:32:28 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:32:28 --> Utf8 Class Initialized
INFO - 2019-09-01 10:32:28 --> URI Class Initialized
INFO - 2019-09-01 10:32:28 --> Router Class Initialized
INFO - 2019-09-01 10:32:28 --> Output Class Initialized
INFO - 2019-09-01 10:32:28 --> Security Class Initialized
DEBUG - 2019-09-01 10:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:32:28 --> Input Class Initialized
INFO - 2019-09-01 10:32:28 --> Language Class Initialized
INFO - 2019-09-01 10:32:28 --> Loader Class Initialized
INFO - 2019-09-01 10:32:28 --> Helper loaded: url_helper
INFO - 2019-09-01 10:32:28 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:32:34 --> Controller Class Initialized
INFO - 2019-09-01 10:32:34 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:32:34 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step6.php
INFO - 2019-09-01 10:32:34 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:32:34 --> Final output sent to browser
DEBUG - 2019-09-01 10:32:34 --> Total execution time: 6.1881
INFO - 2019-09-01 10:33:20 --> Config Class Initialized
INFO - 2019-09-01 10:33:20 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:33:20 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:33:20 --> Utf8 Class Initialized
INFO - 2019-09-01 10:33:20 --> URI Class Initialized
INFO - 2019-09-01 10:33:20 --> Router Class Initialized
INFO - 2019-09-01 10:33:20 --> Output Class Initialized
INFO - 2019-09-01 10:33:20 --> Security Class Initialized
DEBUG - 2019-09-01 10:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:33:20 --> Input Class Initialized
INFO - 2019-09-01 10:33:20 --> Language Class Initialized
INFO - 2019-09-01 10:33:20 --> Loader Class Initialized
INFO - 2019-09-01 10:33:20 --> Helper loaded: url_helper
INFO - 2019-09-01 10:33:20 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:33:21 --> Controller Class Initialized
INFO - 2019-09-01 10:33:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:33:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step5.php
INFO - 2019-09-01 10:33:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:33:21 --> Final output sent to browser
DEBUG - 2019-09-01 10:33:21 --> Total execution time: 1.1434
INFO - 2019-09-01 10:33:24 --> Config Class Initialized
INFO - 2019-09-01 10:33:24 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:33:24 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:33:24 --> Utf8 Class Initialized
INFO - 2019-09-01 10:33:24 --> URI Class Initialized
INFO - 2019-09-01 10:33:24 --> Router Class Initialized
INFO - 2019-09-01 10:33:24 --> Output Class Initialized
INFO - 2019-09-01 10:33:24 --> Security Class Initialized
DEBUG - 2019-09-01 10:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:33:24 --> Input Class Initialized
INFO - 2019-09-01 10:33:24 --> Language Class Initialized
INFO - 2019-09-01 10:33:24 --> Loader Class Initialized
INFO - 2019-09-01 10:33:24 --> Helper loaded: url_helper
INFO - 2019-09-01 10:33:24 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:33:25 --> Controller Class Initialized
INFO - 2019-09-01 10:33:25 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:33:25 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step6.php
INFO - 2019-09-01 10:33:25 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:33:25 --> Final output sent to browser
DEBUG - 2019-09-01 10:33:25 --> Total execution time: 1.1506
INFO - 2019-09-01 10:34:05 --> Config Class Initialized
INFO - 2019-09-01 10:34:05 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:34:05 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:34:05 --> Utf8 Class Initialized
INFO - 2019-09-01 10:34:05 --> URI Class Initialized
INFO - 2019-09-01 10:34:05 --> Router Class Initialized
INFO - 2019-09-01 10:34:05 --> Output Class Initialized
INFO - 2019-09-01 10:34:05 --> Security Class Initialized
DEBUG - 2019-09-01 10:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:34:05 --> Input Class Initialized
INFO - 2019-09-01 10:34:05 --> Language Class Initialized
INFO - 2019-09-01 10:34:05 --> Loader Class Initialized
INFO - 2019-09-01 10:34:05 --> Helper loaded: url_helper
INFO - 2019-09-01 10:34:05 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:34:12 --> Controller Class Initialized
INFO - 2019-09-01 10:34:12 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:34:12 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step6.php
INFO - 2019-09-01 10:34:12 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:34:12 --> Final output sent to browser
DEBUG - 2019-09-01 10:34:12 --> Total execution time: 6.1803
INFO - 2019-09-01 10:35:09 --> Config Class Initialized
INFO - 2019-09-01 10:35:09 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:35:09 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:35:09 --> Utf8 Class Initialized
INFO - 2019-09-01 10:35:09 --> URI Class Initialized
INFO - 2019-09-01 10:35:09 --> Router Class Initialized
INFO - 2019-09-01 10:35:09 --> Output Class Initialized
INFO - 2019-09-01 10:35:09 --> Security Class Initialized
DEBUG - 2019-09-01 10:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:35:09 --> Input Class Initialized
INFO - 2019-09-01 10:35:09 --> Language Class Initialized
INFO - 2019-09-01 10:35:09 --> Loader Class Initialized
INFO - 2019-09-01 10:35:09 --> Helper loaded: url_helper
INFO - 2019-09-01 10:35:09 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:35:10 --> Controller Class Initialized
INFO - 2019-09-01 10:35:10 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:35:10 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step5.php
INFO - 2019-09-01 10:35:10 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:35:10 --> Final output sent to browser
DEBUG - 2019-09-01 10:35:10 --> Total execution time: 1.1762
INFO - 2019-09-01 10:35:13 --> Config Class Initialized
INFO - 2019-09-01 10:35:13 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:35:13 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:35:13 --> Utf8 Class Initialized
INFO - 2019-09-01 10:35:13 --> URI Class Initialized
INFO - 2019-09-01 10:35:13 --> Router Class Initialized
INFO - 2019-09-01 10:35:13 --> Output Class Initialized
INFO - 2019-09-01 10:35:13 --> Security Class Initialized
DEBUG - 2019-09-01 10:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:35:13 --> Input Class Initialized
INFO - 2019-09-01 10:35:13 --> Language Class Initialized
INFO - 2019-09-01 10:35:13 --> Loader Class Initialized
INFO - 2019-09-01 10:35:13 --> Helper loaded: url_helper
INFO - 2019-09-01 10:35:13 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:35:14 --> Controller Class Initialized
INFO - 2019-09-01 10:35:14 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:35:14 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step6.php
INFO - 2019-09-01 10:35:14 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:35:14 --> Final output sent to browser
DEBUG - 2019-09-01 10:35:14 --> Total execution time: 1.1235
INFO - 2019-09-01 10:35:36 --> Config Class Initialized
INFO - 2019-09-01 10:35:36 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:35:36 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:35:36 --> Utf8 Class Initialized
INFO - 2019-09-01 10:35:36 --> URI Class Initialized
INFO - 2019-09-01 10:35:36 --> Router Class Initialized
INFO - 2019-09-01 10:35:36 --> Output Class Initialized
INFO - 2019-09-01 10:35:36 --> Security Class Initialized
DEBUG - 2019-09-01 10:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:35:36 --> Input Class Initialized
INFO - 2019-09-01 10:35:36 --> Language Class Initialized
INFO - 2019-09-01 10:35:36 --> Loader Class Initialized
INFO - 2019-09-01 10:35:36 --> Helper loaded: url_helper
INFO - 2019-09-01 10:35:36 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:35:37 --> Controller Class Initialized
INFO - 2019-09-01 10:35:37 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:35:37 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_1.php
INFO - 2019-09-01 10:35:37 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:35:37 --> Final output sent to browser
DEBUG - 2019-09-01 10:35:37 --> Total execution time: 1.1326
INFO - 2019-09-01 10:35:38 --> Config Class Initialized
INFO - 2019-09-01 10:35:38 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:35:38 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:35:38 --> Utf8 Class Initialized
INFO - 2019-09-01 10:35:38 --> URI Class Initialized
INFO - 2019-09-01 10:35:38 --> Router Class Initialized
INFO - 2019-09-01 10:35:38 --> Output Class Initialized
INFO - 2019-09-01 10:35:38 --> Security Class Initialized
DEBUG - 2019-09-01 10:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:35:38 --> Input Class Initialized
INFO - 2019-09-01 10:35:38 --> Language Class Initialized
INFO - 2019-09-01 10:35:38 --> Loader Class Initialized
INFO - 2019-09-01 10:35:38 --> Helper loaded: url_helper
INFO - 2019-09-01 10:35:38 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:35:47 --> Controller Class Initialized
INFO - 2019-09-01 10:35:47 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:35:47 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_1.php
INFO - 2019-09-01 10:35:47 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:35:47 --> Final output sent to browser
DEBUG - 2019-09-01 10:35:47 --> Total execution time: 9.2431
INFO - 2019-09-01 10:57:31 --> Config Class Initialized
INFO - 2019-09-01 10:57:31 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:57:31 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:57:31 --> Utf8 Class Initialized
INFO - 2019-09-01 10:57:31 --> URI Class Initialized
INFO - 2019-09-01 10:57:31 --> Router Class Initialized
INFO - 2019-09-01 10:57:31 --> Output Class Initialized
INFO - 2019-09-01 10:57:31 --> Security Class Initialized
DEBUG - 2019-09-01 10:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:57:31 --> Input Class Initialized
INFO - 2019-09-01 10:57:31 --> Language Class Initialized
INFO - 2019-09-01 10:57:31 --> Loader Class Initialized
INFO - 2019-09-01 10:57:31 --> Helper loaded: url_helper
INFO - 2019-09-01 10:57:31 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:57:35 --> Controller Class Initialized
INFO - 2019-09-01 10:57:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:57:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_1.php
INFO - 2019-09-01 10:57:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:57:35 --> Final output sent to browser
DEBUG - 2019-09-01 10:57:35 --> Total execution time: 3.7435
INFO - 2019-09-01 10:57:37 --> Config Class Initialized
INFO - 2019-09-01 10:57:37 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:57:37 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:57:37 --> Utf8 Class Initialized
INFO - 2019-09-01 10:57:37 --> URI Class Initialized
INFO - 2019-09-01 10:57:37 --> Router Class Initialized
INFO - 2019-09-01 10:57:37 --> Output Class Initialized
INFO - 2019-09-01 10:57:37 --> Security Class Initialized
DEBUG - 2019-09-01 10:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:57:37 --> Input Class Initialized
INFO - 2019-09-01 10:57:37 --> Language Class Initialized
INFO - 2019-09-01 10:57:37 --> Loader Class Initialized
INFO - 2019-09-01 10:57:37 --> Helper loaded: url_helper
INFO - 2019-09-01 10:57:37 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:57:38 --> Controller Class Initialized
INFO - 2019-09-01 10:57:38 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:57:38 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_1.php
INFO - 2019-09-01 10:57:38 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:57:38 --> Final output sent to browser
DEBUG - 2019-09-01 10:57:38 --> Total execution time: 1.1251
INFO - 2019-09-01 10:58:17 --> Config Class Initialized
INFO - 2019-09-01 10:58:17 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:58:17 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:58:17 --> Utf8 Class Initialized
INFO - 2019-09-01 10:58:17 --> URI Class Initialized
INFO - 2019-09-01 10:58:17 --> Router Class Initialized
INFO - 2019-09-01 10:58:17 --> Output Class Initialized
INFO - 2019-09-01 10:58:17 --> Security Class Initialized
DEBUG - 2019-09-01 10:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:58:17 --> Input Class Initialized
INFO - 2019-09-01 10:58:17 --> Language Class Initialized
INFO - 2019-09-01 10:58:17 --> Loader Class Initialized
INFO - 2019-09-01 10:58:17 --> Helper loaded: url_helper
INFO - 2019-09-01 10:58:17 --> Database Driver Class Initialized
INFO - 2019-09-01 10:58:40 --> Config Class Initialized
INFO - 2019-09-01 10:58:40 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:58:40 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:58:40 --> Utf8 Class Initialized
INFO - 2019-09-01 10:58:40 --> URI Class Initialized
INFO - 2019-09-01 10:58:40 --> Router Class Initialized
INFO - 2019-09-01 10:58:40 --> Output Class Initialized
INFO - 2019-09-01 10:58:40 --> Security Class Initialized
DEBUG - 2019-09-01 10:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:58:40 --> Input Class Initialized
INFO - 2019-09-01 10:58:40 --> Language Class Initialized
INFO - 2019-09-01 10:58:40 --> Loader Class Initialized
INFO - 2019-09-01 10:58:40 --> Helper loaded: url_helper
INFO - 2019-09-01 10:58:40 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:58:41 --> Controller Class Initialized
INFO - 2019-09-01 10:58:41 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:58:41 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_1.php
INFO - 2019-09-01 10:58:41 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:58:41 --> Final output sent to browser
DEBUG - 2019-09-01 10:58:41 --> Total execution time: 1.2010
INFO - 2019-09-01 10:58:43 --> Config Class Initialized
INFO - 2019-09-01 10:58:43 --> Hooks Class Initialized
DEBUG - 2019-09-01 10:58:43 --> UTF-8 Support Enabled
INFO - 2019-09-01 10:58:43 --> Utf8 Class Initialized
INFO - 2019-09-01 10:58:43 --> URI Class Initialized
INFO - 2019-09-01 10:58:43 --> Router Class Initialized
INFO - 2019-09-01 10:58:43 --> Output Class Initialized
INFO - 2019-09-01 10:58:43 --> Security Class Initialized
DEBUG - 2019-09-01 10:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 10:58:43 --> Input Class Initialized
INFO - 2019-09-01 10:58:43 --> Language Class Initialized
INFO - 2019-09-01 10:58:43 --> Loader Class Initialized
INFO - 2019-09-01 10:58:43 --> Helper loaded: url_helper
INFO - 2019-09-01 10:58:43 --> Database Driver Class Initialized
DEBUG - 2019-09-01 10:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:58:46 --> Controller Class Initialized
INFO - 2019-09-01 10:58:46 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:58:46 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step6.php
INFO - 2019-09-01 10:58:46 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:58:46 --> Final output sent to browser
DEBUG - 2019-09-01 10:58:46 --> Total execution time: 29.2046
DEBUG - 2019-09-01 10:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 10:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 10:58:58 --> Controller Class Initialized
INFO - 2019-09-01 10:58:58 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 10:58:58 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_1.php
INFO - 2019-09-01 10:58:58 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 10:58:58 --> Final output sent to browser
DEBUG - 2019-09-01 10:58:58 --> Total execution time: 15.1906
INFO - 2019-09-01 11:01:26 --> Config Class Initialized
INFO - 2019-09-01 11:01:26 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:01:26 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:01:26 --> Utf8 Class Initialized
INFO - 2019-09-01 11:01:26 --> URI Class Initialized
INFO - 2019-09-01 11:01:26 --> Router Class Initialized
INFO - 2019-09-01 11:01:26 --> Output Class Initialized
INFO - 2019-09-01 11:01:26 --> Security Class Initialized
DEBUG - 2019-09-01 11:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:01:26 --> Input Class Initialized
INFO - 2019-09-01 11:01:26 --> Language Class Initialized
INFO - 2019-09-01 11:01:26 --> Loader Class Initialized
INFO - 2019-09-01 11:01:26 --> Helper loaded: url_helper
INFO - 2019-09-01 11:01:26 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:01:27 --> Controller Class Initialized
INFO - 2019-09-01 11:01:27 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:01:27 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_1.php
INFO - 2019-09-01 11:01:27 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:01:27 --> Final output sent to browser
DEBUG - 2019-09-01 11:01:27 --> Total execution time: 1.1683
INFO - 2019-09-01 11:01:28 --> Config Class Initialized
INFO - 2019-09-01 11:01:28 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:01:28 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:01:28 --> Utf8 Class Initialized
INFO - 2019-09-01 11:01:28 --> URI Class Initialized
INFO - 2019-09-01 11:01:28 --> Router Class Initialized
INFO - 2019-09-01 11:01:28 --> Output Class Initialized
INFO - 2019-09-01 11:01:28 --> Security Class Initialized
DEBUG - 2019-09-01 11:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:01:28 --> Input Class Initialized
INFO - 2019-09-01 11:01:28 --> Language Class Initialized
INFO - 2019-09-01 11:01:28 --> Loader Class Initialized
INFO - 2019-09-01 11:01:28 --> Helper loaded: url_helper
INFO - 2019-09-01 11:01:28 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:01:29 --> Controller Class Initialized
DEBUG - 2019-09-01 11:01:29 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:01:29 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:01:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:01:29 --> Model "Template_model" initialized
INFO - 2019-09-01 11:01:29 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 11:01:31 --> Final output sent to browser
DEBUG - 2019-09-01 11:01:31 --> Total execution time: 2.9861
INFO - 2019-09-01 11:03:38 --> Config Class Initialized
INFO - 2019-09-01 11:03:38 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:03:38 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:03:38 --> Utf8 Class Initialized
INFO - 2019-09-01 11:03:38 --> URI Class Initialized
INFO - 2019-09-01 11:03:38 --> Router Class Initialized
INFO - 2019-09-01 11:03:38 --> Output Class Initialized
INFO - 2019-09-01 11:03:38 --> Security Class Initialized
DEBUG - 2019-09-01 11:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:03:38 --> Input Class Initialized
INFO - 2019-09-01 11:03:38 --> Language Class Initialized
INFO - 2019-09-01 11:03:38 --> Loader Class Initialized
INFO - 2019-09-01 11:03:38 --> Helper loaded: url_helper
INFO - 2019-09-01 11:03:38 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:03:45 --> Controller Class Initialized
INFO - 2019-09-01 11:03:45 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:03:45 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_1.php
INFO - 2019-09-01 11:03:45 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:03:45 --> Final output sent to browser
DEBUG - 2019-09-01 11:03:45 --> Total execution time: 6.7985
INFO - 2019-09-01 11:03:47 --> Config Class Initialized
INFO - 2019-09-01 11:03:47 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:03:47 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:03:47 --> Utf8 Class Initialized
INFO - 2019-09-01 11:03:47 --> URI Class Initialized
INFO - 2019-09-01 11:03:47 --> Router Class Initialized
INFO - 2019-09-01 11:03:47 --> Output Class Initialized
INFO - 2019-09-01 11:03:47 --> Security Class Initialized
DEBUG - 2019-09-01 11:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:03:47 --> Input Class Initialized
INFO - 2019-09-01 11:03:47 --> Language Class Initialized
INFO - 2019-09-01 11:03:47 --> Loader Class Initialized
INFO - 2019-09-01 11:03:47 --> Helper loaded: url_helper
INFO - 2019-09-01 11:03:47 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:03:48 --> Controller Class Initialized
DEBUG - 2019-09-01 11:03:48 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:03:48 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:03:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:03:48 --> Model "Template_model" initialized
INFO - 2019-09-01 11:03:48 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 11:03:48 --> Final output sent to browser
DEBUG - 2019-09-01 11:03:48 --> Total execution time: 1.4513
INFO - 2019-09-01 11:05:19 --> Config Class Initialized
INFO - 2019-09-01 11:05:19 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:05:19 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:05:19 --> Utf8 Class Initialized
INFO - 2019-09-01 11:05:19 --> URI Class Initialized
INFO - 2019-09-01 11:05:19 --> Router Class Initialized
INFO - 2019-09-01 11:05:19 --> Output Class Initialized
INFO - 2019-09-01 11:05:19 --> Security Class Initialized
DEBUG - 2019-09-01 11:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:05:19 --> Input Class Initialized
INFO - 2019-09-01 11:05:19 --> Language Class Initialized
INFO - 2019-09-01 11:05:19 --> Loader Class Initialized
INFO - 2019-09-01 11:05:19 --> Helper loaded: url_helper
INFO - 2019-09-01 11:05:19 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:05:20 --> Controller Class Initialized
INFO - 2019-09-01 11:05:20 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:05:20 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step6.php
INFO - 2019-09-01 11:05:20 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:05:20 --> Final output sent to browser
DEBUG - 2019-09-01 11:05:20 --> Total execution time: 1.1725
INFO - 2019-09-01 11:05:22 --> Config Class Initialized
INFO - 2019-09-01 11:05:22 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:05:22 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:05:22 --> Utf8 Class Initialized
INFO - 2019-09-01 11:05:22 --> URI Class Initialized
INFO - 2019-09-01 11:05:22 --> Router Class Initialized
INFO - 2019-09-01 11:05:22 --> Output Class Initialized
INFO - 2019-09-01 11:05:22 --> Security Class Initialized
DEBUG - 2019-09-01 11:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:05:22 --> Input Class Initialized
INFO - 2019-09-01 11:05:22 --> Language Class Initialized
INFO - 2019-09-01 11:05:22 --> Loader Class Initialized
INFO - 2019-09-01 11:05:22 --> Helper loaded: url_helper
INFO - 2019-09-01 11:05:22 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:05:24 --> Controller Class Initialized
INFO - 2019-09-01 11:05:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:05:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_1.php
INFO - 2019-09-01 11:05:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:05:24 --> Final output sent to browser
DEBUG - 2019-09-01 11:05:24 --> Total execution time: 1.1347
INFO - 2019-09-01 11:05:24 --> Config Class Initialized
INFO - 2019-09-01 11:05:24 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:05:24 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:05:24 --> Utf8 Class Initialized
INFO - 2019-09-01 11:05:24 --> URI Class Initialized
INFO - 2019-09-01 11:05:24 --> Router Class Initialized
INFO - 2019-09-01 11:05:24 --> Output Class Initialized
INFO - 2019-09-01 11:05:24 --> Security Class Initialized
DEBUG - 2019-09-01 11:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:05:24 --> Input Class Initialized
INFO - 2019-09-01 11:05:24 --> Language Class Initialized
INFO - 2019-09-01 11:05:24 --> Loader Class Initialized
INFO - 2019-09-01 11:05:24 --> Helper loaded: url_helper
INFO - 2019-09-01 11:05:24 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:05:25 --> Controller Class Initialized
DEBUG - 2019-09-01 11:05:25 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:05:25 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:05:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:05:25 --> Model "Template_model" initialized
INFO - 2019-09-01 11:05:25 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 11:05:26 --> Final output sent to browser
DEBUG - 2019-09-01 11:05:26 --> Total execution time: 1.6801
INFO - 2019-09-01 11:05:58 --> Config Class Initialized
INFO - 2019-09-01 11:05:58 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:05:58 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:05:58 --> Utf8 Class Initialized
INFO - 2019-09-01 11:05:58 --> URI Class Initialized
INFO - 2019-09-01 11:05:58 --> Router Class Initialized
INFO - 2019-09-01 11:05:58 --> Output Class Initialized
INFO - 2019-09-01 11:05:58 --> Security Class Initialized
DEBUG - 2019-09-01 11:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:05:58 --> Input Class Initialized
INFO - 2019-09-01 11:05:58 --> Language Class Initialized
INFO - 2019-09-01 11:05:58 --> Loader Class Initialized
INFO - 2019-09-01 11:05:58 --> Helper loaded: url_helper
INFO - 2019-09-01 11:05:58 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:05:59 --> Controller Class Initialized
INFO - 2019-09-01 11:05:59 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:05:59 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step6.php
INFO - 2019-09-01 11:05:59 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:05:59 --> Final output sent to browser
DEBUG - 2019-09-01 11:05:59 --> Total execution time: 1.2120
INFO - 2019-09-01 11:06:02 --> Config Class Initialized
INFO - 2019-09-01 11:06:02 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:06:02 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:06:02 --> Utf8 Class Initialized
INFO - 2019-09-01 11:06:02 --> URI Class Initialized
INFO - 2019-09-01 11:06:02 --> Router Class Initialized
INFO - 2019-09-01 11:06:02 --> Output Class Initialized
INFO - 2019-09-01 11:06:02 --> Security Class Initialized
DEBUG - 2019-09-01 11:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:06:02 --> Input Class Initialized
INFO - 2019-09-01 11:06:02 --> Language Class Initialized
INFO - 2019-09-01 11:06:02 --> Loader Class Initialized
INFO - 2019-09-01 11:06:02 --> Helper loaded: url_helper
INFO - 2019-09-01 11:06:02 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:06:04 --> Controller Class Initialized
INFO - 2019-09-01 11:06:04 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:06:04 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_2.php
INFO - 2019-09-01 11:06:04 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:06:04 --> Final output sent to browser
DEBUG - 2019-09-01 11:06:04 --> Total execution time: 1.1366
INFO - 2019-09-01 11:06:04 --> Config Class Initialized
INFO - 2019-09-01 11:06:04 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:06:04 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:06:04 --> Utf8 Class Initialized
INFO - 2019-09-01 11:06:04 --> URI Class Initialized
INFO - 2019-09-01 11:06:04 --> Router Class Initialized
INFO - 2019-09-01 11:06:04 --> Output Class Initialized
INFO - 2019-09-01 11:06:04 --> Security Class Initialized
DEBUG - 2019-09-01 11:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:06:04 --> Input Class Initialized
INFO - 2019-09-01 11:06:04 --> Language Class Initialized
INFO - 2019-09-01 11:06:04 --> Loader Class Initialized
INFO - 2019-09-01 11:06:04 --> Helper loaded: url_helper
INFO - 2019-09-01 11:06:04 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:06:05 --> Controller Class Initialized
DEBUG - 2019-09-01 11:06:05 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:06:05 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:06:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:06:05 --> Model "Template_model" initialized
INFO - 2019-09-01 11:06:05 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 11:06:07 --> Final output sent to browser
DEBUG - 2019-09-01 11:06:07 --> Total execution time: 2.6799
INFO - 2019-09-01 11:06:08 --> Config Class Initialized
INFO - 2019-09-01 11:06:08 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:06:08 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:06:08 --> Utf8 Class Initialized
INFO - 2019-09-01 11:06:08 --> URI Class Initialized
INFO - 2019-09-01 11:06:08 --> Router Class Initialized
INFO - 2019-09-01 11:06:08 --> Output Class Initialized
INFO - 2019-09-01 11:06:08 --> Security Class Initialized
DEBUG - 2019-09-01 11:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:06:08 --> Input Class Initialized
INFO - 2019-09-01 11:06:08 --> Language Class Initialized
INFO - 2019-09-01 11:06:08 --> Loader Class Initialized
INFO - 2019-09-01 11:06:08 --> Helper loaded: url_helper
INFO - 2019-09-01 11:06:08 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:06:10 --> Controller Class Initialized
INFO - 2019-09-01 11:06:10 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:06:10 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step6.php
INFO - 2019-09-01 11:06:10 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:06:10 --> Final output sent to browser
DEBUG - 2019-09-01 11:06:10 --> Total execution time: 1.1675
INFO - 2019-09-01 11:06:17 --> Config Class Initialized
INFO - 2019-09-01 11:06:17 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:06:17 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:06:17 --> Utf8 Class Initialized
INFO - 2019-09-01 11:06:17 --> URI Class Initialized
INFO - 2019-09-01 11:06:17 --> Router Class Initialized
INFO - 2019-09-01 11:06:17 --> Output Class Initialized
INFO - 2019-09-01 11:06:17 --> Security Class Initialized
DEBUG - 2019-09-01 11:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:06:17 --> Input Class Initialized
INFO - 2019-09-01 11:06:17 --> Language Class Initialized
INFO - 2019-09-01 11:06:17 --> Loader Class Initialized
INFO - 2019-09-01 11:06:17 --> Helper loaded: url_helper
INFO - 2019-09-01 11:06:17 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:06:18 --> Controller Class Initialized
INFO - 2019-09-01 11:06:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:06:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_1.php
INFO - 2019-09-01 11:06:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:06:18 --> Final output sent to browser
DEBUG - 2019-09-01 11:06:18 --> Total execution time: 1.2108
INFO - 2019-09-01 11:06:18 --> Config Class Initialized
INFO - 2019-09-01 11:06:18 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:06:18 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:06:18 --> Utf8 Class Initialized
INFO - 2019-09-01 11:06:18 --> URI Class Initialized
INFO - 2019-09-01 11:06:18 --> Router Class Initialized
INFO - 2019-09-01 11:06:18 --> Output Class Initialized
INFO - 2019-09-01 11:06:18 --> Security Class Initialized
DEBUG - 2019-09-01 11:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:06:18 --> Input Class Initialized
INFO - 2019-09-01 11:06:18 --> Language Class Initialized
INFO - 2019-09-01 11:06:18 --> Loader Class Initialized
INFO - 2019-09-01 11:06:18 --> Helper loaded: url_helper
INFO - 2019-09-01 11:06:18 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:06:19 --> Controller Class Initialized
DEBUG - 2019-09-01 11:06:19 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:06:19 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:06:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:06:19 --> Model "Template_model" initialized
INFO - 2019-09-01 11:06:19 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 11:06:21 --> Final output sent to browser
DEBUG - 2019-09-01 11:06:21 --> Total execution time: 2.4638
INFO - 2019-09-01 11:06:33 --> Config Class Initialized
INFO - 2019-09-01 11:06:33 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:06:33 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:06:33 --> Utf8 Class Initialized
INFO - 2019-09-01 11:06:33 --> URI Class Initialized
INFO - 2019-09-01 11:06:33 --> Router Class Initialized
INFO - 2019-09-01 11:06:33 --> Output Class Initialized
INFO - 2019-09-01 11:06:33 --> Security Class Initialized
DEBUG - 2019-09-01 11:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:06:33 --> Input Class Initialized
INFO - 2019-09-01 11:06:33 --> Language Class Initialized
INFO - 2019-09-01 11:06:33 --> Loader Class Initialized
INFO - 2019-09-01 11:06:33 --> Helper loaded: url_helper
INFO - 2019-09-01 11:06:33 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:06:40 --> Controller Class Initialized
INFO - 2019-09-01 11:06:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:06:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step6.php
INFO - 2019-09-01 11:06:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:06:40 --> Final output sent to browser
DEBUG - 2019-09-01 11:06:40 --> Total execution time: 6.1719
INFO - 2019-09-01 11:06:42 --> Config Class Initialized
INFO - 2019-09-01 11:06:42 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:06:42 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:06:42 --> Utf8 Class Initialized
INFO - 2019-09-01 11:06:42 --> URI Class Initialized
INFO - 2019-09-01 11:06:42 --> Router Class Initialized
INFO - 2019-09-01 11:06:42 --> Output Class Initialized
INFO - 2019-09-01 11:06:42 --> Security Class Initialized
DEBUG - 2019-09-01 11:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:06:42 --> Input Class Initialized
INFO - 2019-09-01 11:06:42 --> Language Class Initialized
INFO - 2019-09-01 11:06:42 --> Loader Class Initialized
INFO - 2019-09-01 11:06:42 --> Helper loaded: url_helper
INFO - 2019-09-01 11:06:42 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:06:43 --> Controller Class Initialized
INFO - 2019-09-01 11:06:43 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:06:43 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_1.php
INFO - 2019-09-01 11:06:43 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:06:43 --> Final output sent to browser
DEBUG - 2019-09-01 11:06:43 --> Total execution time: 1.1755
INFO - 2019-09-01 11:06:44 --> Config Class Initialized
INFO - 2019-09-01 11:06:44 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:06:44 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:06:44 --> Utf8 Class Initialized
INFO - 2019-09-01 11:06:44 --> URI Class Initialized
INFO - 2019-09-01 11:06:44 --> Router Class Initialized
INFO - 2019-09-01 11:06:44 --> Output Class Initialized
INFO - 2019-09-01 11:06:44 --> Security Class Initialized
DEBUG - 2019-09-01 11:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:06:44 --> Input Class Initialized
INFO - 2019-09-01 11:06:44 --> Language Class Initialized
INFO - 2019-09-01 11:06:44 --> Loader Class Initialized
INFO - 2019-09-01 11:06:44 --> Helper loaded: url_helper
INFO - 2019-09-01 11:06:44 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:06:53 --> Controller Class Initialized
DEBUG - 2019-09-01 11:06:53 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:06:53 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:06:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:06:53 --> Model "Template_model" initialized
INFO - 2019-09-01 11:06:53 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 11:06:54 --> Final output sent to browser
DEBUG - 2019-09-01 11:06:54 --> Total execution time: 9.7157
INFO - 2019-09-01 11:06:58 --> Config Class Initialized
INFO - 2019-09-01 11:06:58 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:06:58 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:06:58 --> Utf8 Class Initialized
INFO - 2019-09-01 11:06:58 --> URI Class Initialized
INFO - 2019-09-01 11:06:58 --> Router Class Initialized
INFO - 2019-09-01 11:06:58 --> Output Class Initialized
INFO - 2019-09-01 11:06:58 --> Security Class Initialized
DEBUG - 2019-09-01 11:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:06:58 --> Input Class Initialized
INFO - 2019-09-01 11:06:58 --> Language Class Initialized
INFO - 2019-09-01 11:06:58 --> Loader Class Initialized
INFO - 2019-09-01 11:06:58 --> Helper loaded: url_helper
INFO - 2019-09-01 11:06:58 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:06:59 --> Controller Class Initialized
INFO - 2019-09-01 11:06:59 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:06:59 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step6.php
INFO - 2019-09-01 11:06:59 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:06:59 --> Final output sent to browser
DEBUG - 2019-09-01 11:06:59 --> Total execution time: 1.1377
INFO - 2019-09-01 11:07:02 --> Config Class Initialized
INFO - 2019-09-01 11:07:02 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:07:02 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:07:02 --> Utf8 Class Initialized
INFO - 2019-09-01 11:07:02 --> URI Class Initialized
INFO - 2019-09-01 11:07:02 --> Router Class Initialized
INFO - 2019-09-01 11:07:02 --> Output Class Initialized
INFO - 2019-09-01 11:07:02 --> Security Class Initialized
DEBUG - 2019-09-01 11:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:07:02 --> Input Class Initialized
INFO - 2019-09-01 11:07:02 --> Language Class Initialized
INFO - 2019-09-01 11:07:02 --> Loader Class Initialized
INFO - 2019-09-01 11:07:02 --> Helper loaded: url_helper
INFO - 2019-09-01 11:07:02 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:07:03 --> Controller Class Initialized
INFO - 2019-09-01 11:07:03 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:07:03 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_1.php
INFO - 2019-09-01 11:07:03 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:07:03 --> Final output sent to browser
DEBUG - 2019-09-01 11:07:03 --> Total execution time: 1.1253
INFO - 2019-09-01 11:07:04 --> Config Class Initialized
INFO - 2019-09-01 11:07:04 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:07:04 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:07:04 --> Utf8 Class Initialized
INFO - 2019-09-01 11:07:04 --> URI Class Initialized
INFO - 2019-09-01 11:07:04 --> Router Class Initialized
INFO - 2019-09-01 11:07:04 --> Output Class Initialized
INFO - 2019-09-01 11:07:04 --> Security Class Initialized
DEBUG - 2019-09-01 11:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:07:04 --> Input Class Initialized
INFO - 2019-09-01 11:07:04 --> Language Class Initialized
INFO - 2019-09-01 11:07:04 --> Loader Class Initialized
INFO - 2019-09-01 11:07:04 --> Helper loaded: url_helper
INFO - 2019-09-01 11:07:04 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:07:05 --> Controller Class Initialized
DEBUG - 2019-09-01 11:07:05 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:07:05 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:07:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:07:05 --> Model "Template_model" initialized
INFO - 2019-09-01 11:07:05 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 11:07:05 --> Final output sent to browser
DEBUG - 2019-09-01 11:07:05 --> Total execution time: 1.6208
INFO - 2019-09-01 11:09:16 --> Config Class Initialized
INFO - 2019-09-01 11:09:16 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:09:16 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:09:16 --> Utf8 Class Initialized
INFO - 2019-09-01 11:09:16 --> URI Class Initialized
INFO - 2019-09-01 11:09:16 --> Router Class Initialized
INFO - 2019-09-01 11:09:16 --> Output Class Initialized
INFO - 2019-09-01 11:09:16 --> Security Class Initialized
DEBUG - 2019-09-01 11:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:09:16 --> Input Class Initialized
INFO - 2019-09-01 11:09:16 --> Language Class Initialized
INFO - 2019-09-01 11:09:16 --> Loader Class Initialized
INFO - 2019-09-01 11:09:16 --> Helper loaded: url_helper
INFO - 2019-09-01 11:09:16 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:09:17 --> Controller Class Initialized
INFO - 2019-09-01 11:09:17 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:09:17 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step6.php
INFO - 2019-09-01 11:09:17 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:09:17 --> Final output sent to browser
DEBUG - 2019-09-01 11:09:17 --> Total execution time: 1.1565
INFO - 2019-09-01 11:09:19 --> Config Class Initialized
INFO - 2019-09-01 11:09:19 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:09:19 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:09:19 --> Utf8 Class Initialized
INFO - 2019-09-01 11:09:19 --> URI Class Initialized
INFO - 2019-09-01 11:09:20 --> Router Class Initialized
INFO - 2019-09-01 11:09:20 --> Output Class Initialized
INFO - 2019-09-01 11:09:20 --> Security Class Initialized
DEBUG - 2019-09-01 11:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:09:20 --> Input Class Initialized
INFO - 2019-09-01 11:09:20 --> Language Class Initialized
INFO - 2019-09-01 11:09:20 --> Loader Class Initialized
INFO - 2019-09-01 11:09:20 --> Helper loaded: url_helper
INFO - 2019-09-01 11:09:20 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:09:26 --> Controller Class Initialized
INFO - 2019-09-01 11:09:26 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:09:26 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_2.php
INFO - 2019-09-01 11:09:26 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:09:26 --> Final output sent to browser
DEBUG - 2019-09-01 11:09:26 --> Total execution time: 6.8411
INFO - 2019-09-01 11:09:27 --> Config Class Initialized
INFO - 2019-09-01 11:09:27 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:09:27 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:09:27 --> Utf8 Class Initialized
INFO - 2019-09-01 11:09:27 --> URI Class Initialized
INFO - 2019-09-01 11:09:27 --> Router Class Initialized
INFO - 2019-09-01 11:09:27 --> Output Class Initialized
INFO - 2019-09-01 11:09:27 --> Security Class Initialized
DEBUG - 2019-09-01 11:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:09:27 --> Input Class Initialized
INFO - 2019-09-01 11:09:27 --> Language Class Initialized
INFO - 2019-09-01 11:09:27 --> Loader Class Initialized
INFO - 2019-09-01 11:09:27 --> Helper loaded: url_helper
INFO - 2019-09-01 11:09:27 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:09:28 --> Controller Class Initialized
DEBUG - 2019-09-01 11:09:28 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:09:28 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:09:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:09:28 --> Model "Template_model" initialized
INFO - 2019-09-01 11:09:28 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 11:09:29 --> Final output sent to browser
DEBUG - 2019-09-01 11:09:29 --> Total execution time: 2.6445
INFO - 2019-09-01 11:17:40 --> Config Class Initialized
INFO - 2019-09-01 11:17:40 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:17:40 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:17:40 --> Utf8 Class Initialized
INFO - 2019-09-01 11:17:40 --> URI Class Initialized
INFO - 2019-09-01 11:17:40 --> Router Class Initialized
INFO - 2019-09-01 11:17:40 --> Output Class Initialized
INFO - 2019-09-01 11:17:40 --> Security Class Initialized
DEBUG - 2019-09-01 11:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:17:40 --> Input Class Initialized
INFO - 2019-09-01 11:17:40 --> Language Class Initialized
INFO - 2019-09-01 11:17:40 --> Loader Class Initialized
INFO - 2019-09-01 11:17:40 --> Helper loaded: url_helper
INFO - 2019-09-01 11:17:40 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:17:41 --> Controller Class Initialized
INFO - 2019-09-01 11:17:41 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:17:41 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_2.php
INFO - 2019-09-01 11:17:41 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:17:41 --> Final output sent to browser
DEBUG - 2019-09-01 11:17:41 --> Total execution time: 1.1768
INFO - 2019-09-01 11:17:43 --> Config Class Initialized
INFO - 2019-09-01 11:17:43 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:17:43 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:17:43 --> Utf8 Class Initialized
INFO - 2019-09-01 11:17:43 --> URI Class Initialized
INFO - 2019-09-01 11:17:43 --> Router Class Initialized
INFO - 2019-09-01 11:17:43 --> Output Class Initialized
INFO - 2019-09-01 11:17:43 --> Security Class Initialized
DEBUG - 2019-09-01 11:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:17:43 --> Input Class Initialized
INFO - 2019-09-01 11:17:43 --> Language Class Initialized
INFO - 2019-09-01 11:17:43 --> Loader Class Initialized
INFO - 2019-09-01 11:17:43 --> Helper loaded: url_helper
INFO - 2019-09-01 11:17:43 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:17:44 --> Controller Class Initialized
DEBUG - 2019-09-01 11:17:44 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:17:44 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:17:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:17:44 --> Model "Template_model" initialized
INFO - 2019-09-01 11:17:44 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 11:17:49 --> Final output sent to browser
DEBUG - 2019-09-01 11:17:49 --> Total execution time: 5.8791
INFO - 2019-09-01 11:17:52 --> Config Class Initialized
INFO - 2019-09-01 11:17:52 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:17:52 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:17:52 --> Utf8 Class Initialized
INFO - 2019-09-01 11:17:52 --> URI Class Initialized
INFO - 2019-09-01 11:17:52 --> Router Class Initialized
INFO - 2019-09-01 11:17:52 --> Output Class Initialized
INFO - 2019-09-01 11:17:52 --> Security Class Initialized
DEBUG - 2019-09-01 11:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:17:52 --> Input Class Initialized
INFO - 2019-09-01 11:17:52 --> Language Class Initialized
INFO - 2019-09-01 11:17:52 --> Loader Class Initialized
INFO - 2019-09-01 11:17:52 --> Helper loaded: url_helper
INFO - 2019-09-01 11:17:52 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:17:53 --> Controller Class Initialized
INFO - 2019-09-01 11:17:53 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:17:53 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step6.php
INFO - 2019-09-01 11:17:53 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:17:53 --> Final output sent to browser
DEBUG - 2019-09-01 11:17:53 --> Total execution time: 1.2123
INFO - 2019-09-01 11:17:55 --> Config Class Initialized
INFO - 2019-09-01 11:17:55 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:17:55 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:17:55 --> Utf8 Class Initialized
INFO - 2019-09-01 11:17:55 --> URI Class Initialized
INFO - 2019-09-01 11:17:55 --> Router Class Initialized
INFO - 2019-09-01 11:17:55 --> Output Class Initialized
INFO - 2019-09-01 11:17:55 --> Security Class Initialized
DEBUG - 2019-09-01 11:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:17:55 --> Input Class Initialized
INFO - 2019-09-01 11:17:55 --> Language Class Initialized
INFO - 2019-09-01 11:17:55 --> Loader Class Initialized
INFO - 2019-09-01 11:17:55 --> Helper loaded: url_helper
INFO - 2019-09-01 11:17:55 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:18:19 --> Controller Class Initialized
INFO - 2019-09-01 11:18:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:18:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_2.php
INFO - 2019-09-01 11:18:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:18:19 --> Final output sent to browser
DEBUG - 2019-09-01 11:18:19 --> Total execution time: 23.1897
INFO - 2019-09-01 11:18:20 --> Config Class Initialized
INFO - 2019-09-01 11:18:20 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:18:20 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:18:20 --> Utf8 Class Initialized
INFO - 2019-09-01 11:18:20 --> URI Class Initialized
INFO - 2019-09-01 11:18:20 --> Router Class Initialized
INFO - 2019-09-01 11:18:20 --> Output Class Initialized
INFO - 2019-09-01 11:18:20 --> Security Class Initialized
DEBUG - 2019-09-01 11:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:18:20 --> Input Class Initialized
INFO - 2019-09-01 11:18:20 --> Language Class Initialized
INFO - 2019-09-01 11:18:20 --> Loader Class Initialized
INFO - 2019-09-01 11:18:20 --> Helper loaded: url_helper
INFO - 2019-09-01 11:18:20 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:18:35 --> Controller Class Initialized
DEBUG - 2019-09-01 11:18:35 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:18:35 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:18:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:18:35 --> Model "Template_model" initialized
INFO - 2019-09-01 11:18:35 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 11:18:36 --> Final output sent to browser
DEBUG - 2019-09-01 11:18:36 --> Total execution time: 16.2076
INFO - 2019-09-01 11:19:03 --> Config Class Initialized
INFO - 2019-09-01 11:19:03 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:19:03 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:19:03 --> Utf8 Class Initialized
INFO - 2019-09-01 11:19:03 --> URI Class Initialized
INFO - 2019-09-01 11:19:03 --> Router Class Initialized
INFO - 2019-09-01 11:19:03 --> Output Class Initialized
INFO - 2019-09-01 11:19:03 --> Security Class Initialized
DEBUG - 2019-09-01 11:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:19:03 --> Input Class Initialized
INFO - 2019-09-01 11:19:03 --> Language Class Initialized
INFO - 2019-09-01 11:19:03 --> Loader Class Initialized
INFO - 2019-09-01 11:19:03 --> Helper loaded: url_helper
INFO - 2019-09-01 11:19:03 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:19:04 --> Controller Class Initialized
INFO - 2019-09-01 11:19:04 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:19:04 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step8.php
INFO - 2019-09-01 11:19:04 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:19:04 --> Final output sent to browser
DEBUG - 2019-09-01 11:19:04 --> Total execution time: 1.1728
INFO - 2019-09-01 11:19:08 --> Config Class Initialized
INFO - 2019-09-01 11:19:08 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:19:08 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:19:08 --> Utf8 Class Initialized
INFO - 2019-09-01 11:19:08 --> URI Class Initialized
INFO - 2019-09-01 11:19:08 --> Router Class Initialized
INFO - 2019-09-01 11:19:08 --> Output Class Initialized
INFO - 2019-09-01 11:19:08 --> Security Class Initialized
DEBUG - 2019-09-01 11:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:19:08 --> Input Class Initialized
INFO - 2019-09-01 11:19:08 --> Language Class Initialized
INFO - 2019-09-01 11:19:08 --> Loader Class Initialized
INFO - 2019-09-01 11:19:08 --> Helper loaded: url_helper
INFO - 2019-09-01 11:19:08 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:19:09 --> Controller Class Initialized
INFO - 2019-09-01 11:19:09 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:19:09 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-09-01 11:19:09 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:19:09 --> Final output sent to browser
DEBUG - 2019-09-01 11:19:09 --> Total execution time: 1.1400
INFO - 2019-09-01 11:19:15 --> Config Class Initialized
INFO - 2019-09-01 11:19:15 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:19:15 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:19:15 --> Utf8 Class Initialized
INFO - 2019-09-01 11:19:15 --> URI Class Initialized
INFO - 2019-09-01 11:19:15 --> Router Class Initialized
INFO - 2019-09-01 11:19:15 --> Output Class Initialized
INFO - 2019-09-01 11:19:15 --> Security Class Initialized
DEBUG - 2019-09-01 11:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:19:15 --> Input Class Initialized
INFO - 2019-09-01 11:19:15 --> Language Class Initialized
INFO - 2019-09-01 11:19:15 --> Loader Class Initialized
INFO - 2019-09-01 11:19:15 --> Helper loaded: url_helper
INFO - 2019-09-01 11:19:15 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:19:21 --> Controller Class Initialized
INFO - 2019-09-01 11:19:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:19:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 11:19:21 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:19:21 --> Final output sent to browser
DEBUG - 2019-09-01 11:19:21 --> Total execution time: 6.1384
INFO - 2019-09-01 11:19:22 --> Config Class Initialized
INFO - 2019-09-01 11:19:22 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:19:22 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:19:22 --> Utf8 Class Initialized
INFO - 2019-09-01 11:19:22 --> URI Class Initialized
INFO - 2019-09-01 11:19:22 --> Router Class Initialized
INFO - 2019-09-01 11:19:22 --> Output Class Initialized
INFO - 2019-09-01 11:19:22 --> Security Class Initialized
DEBUG - 2019-09-01 11:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:19:22 --> Input Class Initialized
INFO - 2019-09-01 11:19:22 --> Language Class Initialized
INFO - 2019-09-01 11:19:22 --> Loader Class Initialized
INFO - 2019-09-01 11:19:22 --> Helper loaded: url_helper
INFO - 2019-09-01 11:19:22 --> Database Driver Class Initialized
INFO - 2019-09-01 11:19:26 --> Config Class Initialized
INFO - 2019-09-01 11:19:26 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:19:26 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:19:26 --> Utf8 Class Initialized
INFO - 2019-09-01 11:19:26 --> URI Class Initialized
INFO - 2019-09-01 11:19:26 --> Router Class Initialized
INFO - 2019-09-01 11:19:26 --> Output Class Initialized
INFO - 2019-09-01 11:19:26 --> Security Class Initialized
DEBUG - 2019-09-01 11:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:19:26 --> Input Class Initialized
INFO - 2019-09-01 11:19:26 --> Language Class Initialized
INFO - 2019-09-01 11:19:26 --> Loader Class Initialized
INFO - 2019-09-01 11:19:26 --> Helper loaded: url_helper
INFO - 2019-09-01 11:19:26 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:19:28 --> Controller Class Initialized
ERROR - 2019-09-01 11:19:28 --> 404 Page Not Found: 
DEBUG - 2019-09-01 11:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:19:28 --> Controller Class Initialized
DEBUG - 2019-09-01 11:19:28 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:19:28 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:19:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:19:28 --> Model "Template_model" initialized
INFO - 2019-09-01 11:19:28 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 11:19:32 --> Config Class Initialized
INFO - 2019-09-01 11:19:32 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:19:32 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:19:32 --> Utf8 Class Initialized
INFO - 2019-09-01 11:19:32 --> URI Class Initialized
INFO - 2019-09-01 11:19:32 --> Router Class Initialized
INFO - 2019-09-01 11:19:32 --> Output Class Initialized
INFO - 2019-09-01 11:19:32 --> Security Class Initialized
DEBUG - 2019-09-01 11:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:19:32 --> Input Class Initialized
INFO - 2019-09-01 11:19:32 --> Language Class Initialized
INFO - 2019-09-01 11:19:32 --> Loader Class Initialized
INFO - 2019-09-01 11:19:32 --> Helper loaded: url_helper
INFO - 2019-09-01 11:19:32 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:19:46 --> Final output sent to browser
DEBUG - 2019-09-01 11:19:46 --> Total execution time: 24.4172
INFO - 2019-09-01 11:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:19:46 --> Controller Class Initialized
INFO - 2019-09-01 11:19:46 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:19:46 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_1.php
INFO - 2019-09-01 11:19:46 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:19:46 --> Final output sent to browser
DEBUG - 2019-09-01 11:19:46 --> Total execution time: 14.2407
INFO - 2019-09-01 11:19:47 --> Config Class Initialized
INFO - 2019-09-01 11:19:47 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:19:47 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:19:47 --> Utf8 Class Initialized
INFO - 2019-09-01 11:19:47 --> URI Class Initialized
INFO - 2019-09-01 11:19:47 --> Router Class Initialized
INFO - 2019-09-01 11:19:47 --> Output Class Initialized
INFO - 2019-09-01 11:19:47 --> Security Class Initialized
DEBUG - 2019-09-01 11:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:19:47 --> Input Class Initialized
INFO - 2019-09-01 11:19:47 --> Language Class Initialized
INFO - 2019-09-01 11:19:47 --> Loader Class Initialized
INFO - 2019-09-01 11:19:47 --> Helper loaded: url_helper
INFO - 2019-09-01 11:19:47 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:19:48 --> Controller Class Initialized
INFO - 2019-09-01 11:19:48 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:19:48 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_2.php
INFO - 2019-09-01 11:19:48 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:19:48 --> Final output sent to browser
DEBUG - 2019-09-01 11:19:48 --> Total execution time: 1.3727
INFO - 2019-09-01 11:19:48 --> Config Class Initialized
INFO - 2019-09-01 11:19:48 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:19:48 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:19:48 --> Utf8 Class Initialized
INFO - 2019-09-01 11:19:48 --> URI Class Initialized
INFO - 2019-09-01 11:19:48 --> Router Class Initialized
INFO - 2019-09-01 11:19:48 --> Output Class Initialized
INFO - 2019-09-01 11:19:48 --> Security Class Initialized
DEBUG - 2019-09-01 11:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:19:48 --> Input Class Initialized
INFO - 2019-09-01 11:19:48 --> Language Class Initialized
INFO - 2019-09-01 11:19:48 --> Loader Class Initialized
INFO - 2019-09-01 11:19:48 --> Helper loaded: url_helper
INFO - 2019-09-01 11:19:48 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:19:50 --> Controller Class Initialized
DEBUG - 2019-09-01 11:19:50 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:19:50 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:19:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:19:50 --> Model "Template_model" initialized
INFO - 2019-09-01 11:19:50 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 11:19:50 --> Final output sent to browser
DEBUG - 2019-09-01 11:19:50 --> Total execution time: 1.8300
INFO - 2019-09-01 11:42:10 --> Config Class Initialized
INFO - 2019-09-01 11:42:10 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:42:10 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:42:10 --> Utf8 Class Initialized
INFO - 2019-09-01 11:42:10 --> URI Class Initialized
INFO - 2019-09-01 11:42:10 --> Router Class Initialized
INFO - 2019-09-01 11:42:10 --> Output Class Initialized
INFO - 2019-09-01 11:42:10 --> Security Class Initialized
DEBUG - 2019-09-01 11:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:42:10 --> Input Class Initialized
INFO - 2019-09-01 11:42:10 --> Language Class Initialized
INFO - 2019-09-01 11:42:10 --> Loader Class Initialized
INFO - 2019-09-01 11:42:10 --> Helper loaded: url_helper
INFO - 2019-09-01 11:42:10 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:42:25 --> Controller Class Initialized
INFO - 2019-09-01 11:42:25 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:42:25 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step8.php
INFO - 2019-09-01 11:42:25 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:42:25 --> Final output sent to browser
DEBUG - 2019-09-01 11:42:25 --> Total execution time: 15.1492
INFO - 2019-09-01 11:42:36 --> Config Class Initialized
INFO - 2019-09-01 11:42:36 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:42:36 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:42:36 --> Utf8 Class Initialized
INFO - 2019-09-01 11:42:36 --> URI Class Initialized
INFO - 2019-09-01 11:42:36 --> Router Class Initialized
INFO - 2019-09-01 11:42:36 --> Output Class Initialized
INFO - 2019-09-01 11:42:36 --> Security Class Initialized
DEBUG - 2019-09-01 11:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:42:36 --> Input Class Initialized
INFO - 2019-09-01 11:42:36 --> Language Class Initialized
INFO - 2019-09-01 11:42:36 --> Loader Class Initialized
INFO - 2019-09-01 11:42:36 --> Helper loaded: url_helper
INFO - 2019-09-01 11:42:36 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:42:37 --> Controller Class Initialized
INFO - 2019-09-01 11:42:37 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:42:37 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_2.php
INFO - 2019-09-01 11:42:37 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:42:37 --> Final output sent to browser
DEBUG - 2019-09-01 11:42:37 --> Total execution time: 1.1725
INFO - 2019-09-01 11:42:38 --> Config Class Initialized
INFO - 2019-09-01 11:42:38 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:42:38 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:42:38 --> Utf8 Class Initialized
INFO - 2019-09-01 11:42:38 --> URI Class Initialized
INFO - 2019-09-01 11:42:38 --> Router Class Initialized
INFO - 2019-09-01 11:42:38 --> Output Class Initialized
INFO - 2019-09-01 11:42:38 --> Security Class Initialized
DEBUG - 2019-09-01 11:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:42:38 --> Input Class Initialized
INFO - 2019-09-01 11:42:38 --> Language Class Initialized
INFO - 2019-09-01 11:42:38 --> Loader Class Initialized
INFO - 2019-09-01 11:42:38 --> Helper loaded: url_helper
INFO - 2019-09-01 11:42:38 --> Database Driver Class Initialized
INFO - 2019-09-01 11:42:39 --> Config Class Initialized
INFO - 2019-09-01 11:42:39 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:42:39 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:42:39 --> Utf8 Class Initialized
INFO - 2019-09-01 11:42:39 --> URI Class Initialized
INFO - 2019-09-01 11:42:39 --> Router Class Initialized
INFO - 2019-09-01 11:42:39 --> Output Class Initialized
INFO - 2019-09-01 11:42:39 --> Security Class Initialized
DEBUG - 2019-09-01 11:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:42:39 --> Input Class Initialized
INFO - 2019-09-01 11:42:39 --> Language Class Initialized
INFO - 2019-09-01 11:42:39 --> Loader Class Initialized
INFO - 2019-09-01 11:42:39 --> Helper loaded: url_helper
INFO - 2019-09-01 11:42:39 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:42:45 --> Controller Class Initialized
INFO - 2019-09-01 11:42:45 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:42:45 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step8.php
INFO - 2019-09-01 11:42:45 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:42:45 --> Final output sent to browser
DEBUG - 2019-09-01 11:42:45 --> Total execution time: 6.1846
INFO - 2019-09-01 11:42:53 --> Config Class Initialized
INFO - 2019-09-01 11:42:53 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:42:53 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:42:53 --> Utf8 Class Initialized
INFO - 2019-09-01 11:42:53 --> URI Class Initialized
INFO - 2019-09-01 11:42:53 --> Router Class Initialized
INFO - 2019-09-01 11:42:53 --> Output Class Initialized
INFO - 2019-09-01 11:42:53 --> Security Class Initialized
DEBUG - 2019-09-01 11:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:42:53 --> Input Class Initialized
INFO - 2019-09-01 11:42:53 --> Language Class Initialized
INFO - 2019-09-01 11:42:53 --> Loader Class Initialized
INFO - 2019-09-01 11:42:53 --> Helper loaded: url_helper
INFO - 2019-09-01 11:42:53 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:42:53 --> Controller Class Initialized
DEBUG - 2019-09-01 11:42:53 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:42:53 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:42:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:42:53 --> Model "Template_model" initialized
INFO - 2019-09-01 11:42:53 --> Model "Khang_sinh_model" initialized
DEBUG - 2019-09-01 11:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:42:54 --> Final output sent to browser
DEBUG - 2019-09-01 11:42:54 --> Total execution time: 16.8287
INFO - 2019-09-01 11:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:42:54 --> Controller Class Initialized
INFO - 2019-09-01 11:42:54 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:42:54 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_2.php
INFO - 2019-09-01 11:42:54 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:42:54 --> Final output sent to browser
DEBUG - 2019-09-01 11:42:54 --> Total execution time: 1.8408
INFO - 2019-09-01 11:42:55 --> Config Class Initialized
INFO - 2019-09-01 11:42:55 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:42:55 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:42:55 --> Utf8 Class Initialized
INFO - 2019-09-01 11:42:55 --> URI Class Initialized
INFO - 2019-09-01 11:42:55 --> Router Class Initialized
INFO - 2019-09-01 11:42:55 --> Output Class Initialized
INFO - 2019-09-01 11:42:55 --> Security Class Initialized
DEBUG - 2019-09-01 11:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:42:55 --> Input Class Initialized
INFO - 2019-09-01 11:42:55 --> Language Class Initialized
INFO - 2019-09-01 11:42:55 --> Loader Class Initialized
INFO - 2019-09-01 11:42:55 --> Helper loaded: url_helper
INFO - 2019-09-01 11:42:55 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:42:56 --> Controller Class Initialized
DEBUG - 2019-09-01 11:42:56 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:42:56 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:42:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:42:56 --> Model "Template_model" initialized
INFO - 2019-09-01 11:42:56 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 11:42:56 --> Config Class Initialized
INFO - 2019-09-01 11:42:56 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:42:56 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:42:56 --> Utf8 Class Initialized
INFO - 2019-09-01 11:42:56 --> URI Class Initialized
INFO - 2019-09-01 11:42:56 --> Router Class Initialized
INFO - 2019-09-01 11:42:56 --> Output Class Initialized
INFO - 2019-09-01 11:42:56 --> Security Class Initialized
DEBUG - 2019-09-01 11:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:42:56 --> Input Class Initialized
INFO - 2019-09-01 11:42:56 --> Language Class Initialized
INFO - 2019-09-01 11:42:56 --> Loader Class Initialized
INFO - 2019-09-01 11:42:56 --> Helper loaded: url_helper
INFO - 2019-09-01 11:42:56 --> Database Driver Class Initialized
INFO - 2019-09-01 11:42:56 --> Final output sent to browser
DEBUG - 2019-09-01 11:42:56 --> Total execution time: 1.4396
DEBUG - 2019-09-01 11:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:43:02 --> Controller Class Initialized
INFO - 2019-09-01 11:43:02 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:43:02 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step8.php
INFO - 2019-09-01 11:43:02 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:43:02 --> Final output sent to browser
DEBUG - 2019-09-01 11:43:02 --> Total execution time: 6.1881
INFO - 2019-09-01 11:43:10 --> Config Class Initialized
INFO - 2019-09-01 11:43:10 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:43:10 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:43:10 --> Utf8 Class Initialized
INFO - 2019-09-01 11:43:10 --> URI Class Initialized
INFO - 2019-09-01 11:43:10 --> Router Class Initialized
INFO - 2019-09-01 11:43:10 --> Output Class Initialized
INFO - 2019-09-01 11:43:10 --> Security Class Initialized
DEBUG - 2019-09-01 11:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:43:10 --> Input Class Initialized
INFO - 2019-09-01 11:43:10 --> Language Class Initialized
INFO - 2019-09-01 11:43:10 --> Loader Class Initialized
INFO - 2019-09-01 11:43:10 --> Helper loaded: url_helper
INFO - 2019-09-01 11:43:10 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:43:12 --> Controller Class Initialized
DEBUG - 2019-09-01 11:43:12 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:43:12 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:43:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:43:12 --> Model "Value_model" initialized
INFO - 2019-09-01 11:43:12 --> Model "Form_model" initialized
INFO - 2019-09-01 11:43:12 --> Model "Meta_link_model" initialized
INFO - 2019-09-01 11:43:12 --> Model "List_ks_model" initialized
ERROR - 2019-09-01 11:43:12 --> Severity: Notice --> Undefined index: form_id D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php 19
ERROR - 2019-09-01 11:43:13 --> Severity: Notice --> Undefined index: form_id D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php 29
DEBUG - 2019-09-01 11:43:13 --> Form id:
ERROR - 2019-09-01 11:43:13 --> Severity: error --> Exception: Too few arguments to function List_ks_model::create_list(), 0 passed in D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php on line 88 and exactly 1 expected D:\Programs\Xampp\htdocs\hait\application\models\List_ks_model.php 26
INFO - 2019-09-01 11:45:58 --> Config Class Initialized
INFO - 2019-09-01 11:45:58 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:45:58 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:45:58 --> Utf8 Class Initialized
INFO - 2019-09-01 11:45:58 --> URI Class Initialized
INFO - 2019-09-01 11:45:58 --> Router Class Initialized
INFO - 2019-09-01 11:45:58 --> Output Class Initialized
INFO - 2019-09-01 11:45:58 --> Security Class Initialized
DEBUG - 2019-09-01 11:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:45:58 --> Input Class Initialized
INFO - 2019-09-01 11:45:58 --> Language Class Initialized
INFO - 2019-09-01 11:45:58 --> Loader Class Initialized
INFO - 2019-09-01 11:45:58 --> Helper loaded: url_helper
INFO - 2019-09-01 11:45:58 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:46:05 --> Controller Class Initialized
INFO - 2019-09-01 11:46:05 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:46:05 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step8.php
INFO - 2019-09-01 11:46:05 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:46:05 --> Final output sent to browser
DEBUG - 2019-09-01 11:46:05 --> Total execution time: 6.1676
INFO - 2019-09-01 11:46:39 --> Config Class Initialized
INFO - 2019-09-01 11:46:39 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:46:39 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:46:39 --> Utf8 Class Initialized
INFO - 2019-09-01 11:46:39 --> URI Class Initialized
INFO - 2019-09-01 11:46:39 --> Router Class Initialized
INFO - 2019-09-01 11:46:39 --> Output Class Initialized
INFO - 2019-09-01 11:46:39 --> Security Class Initialized
DEBUG - 2019-09-01 11:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:46:39 --> Input Class Initialized
INFO - 2019-09-01 11:46:39 --> Language Class Initialized
INFO - 2019-09-01 11:46:39 --> Loader Class Initialized
INFO - 2019-09-01 11:46:39 --> Helper loaded: url_helper
INFO - 2019-09-01 11:46:39 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:46:41 --> Controller Class Initialized
INFO - 2019-09-01 11:46:41 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:46:41 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step8.php
INFO - 2019-09-01 11:46:41 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:46:41 --> Final output sent to browser
DEBUG - 2019-09-01 11:46:41 --> Total execution time: 2.1503
INFO - 2019-09-01 11:46:46 --> Config Class Initialized
INFO - 2019-09-01 11:46:46 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:46:46 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:46:46 --> Utf8 Class Initialized
INFO - 2019-09-01 11:46:46 --> URI Class Initialized
INFO - 2019-09-01 11:46:46 --> Router Class Initialized
INFO - 2019-09-01 11:46:46 --> Output Class Initialized
INFO - 2019-09-01 11:46:46 --> Security Class Initialized
DEBUG - 2019-09-01 11:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:46:46 --> Input Class Initialized
INFO - 2019-09-01 11:46:46 --> Language Class Initialized
INFO - 2019-09-01 11:46:46 --> Loader Class Initialized
INFO - 2019-09-01 11:46:46 --> Helper loaded: url_helper
INFO - 2019-09-01 11:46:46 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:46:55 --> Controller Class Initialized
DEBUG - 2019-09-01 11:46:55 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:46:55 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:46:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:46:55 --> Model "Value_model" initialized
INFO - 2019-09-01 11:46:55 --> Model "Form_model" initialized
INFO - 2019-09-01 11:46:55 --> Model "Meta_link_model" initialized
INFO - 2019-09-01 11:46:55 --> Model "List_ks_model" initialized
ERROR - 2019-09-01 11:46:55 --> Severity: Notice --> Undefined index: form_id D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php 19
ERROR - 2019-09-01 11:47:03 --> Severity: Notice --> Undefined index: form_id D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php 29
DEBUG - 2019-09-01 11:47:03 --> Form id:
ERROR - 2019-09-01 11:47:03 --> Severity: error --> Exception: Too few arguments to function List_ks_model::create_list(), 0 passed in D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php on line 88 and exactly 1 expected D:\Programs\Xampp\htdocs\hait\application\models\List_ks_model.php 26
INFO - 2019-09-01 11:47:09 --> Config Class Initialized
INFO - 2019-09-01 11:47:09 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:47:09 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:47:09 --> Utf8 Class Initialized
INFO - 2019-09-01 11:47:09 --> URI Class Initialized
INFO - 2019-09-01 11:47:09 --> Router Class Initialized
INFO - 2019-09-01 11:47:09 --> Output Class Initialized
INFO - 2019-09-01 11:47:09 --> Security Class Initialized
DEBUG - 2019-09-01 11:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:47:09 --> Input Class Initialized
INFO - 2019-09-01 11:47:09 --> Language Class Initialized
INFO - 2019-09-01 11:47:09 --> Loader Class Initialized
INFO - 2019-09-01 11:47:09 --> Helper loaded: url_helper
INFO - 2019-09-01 11:47:09 --> Database Driver Class Initialized
INFO - 2019-09-01 11:47:11 --> Config Class Initialized
INFO - 2019-09-01 11:47:11 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:47:11 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:47:11 --> Utf8 Class Initialized
INFO - 2019-09-01 11:47:11 --> URI Class Initialized
INFO - 2019-09-01 11:47:11 --> Router Class Initialized
INFO - 2019-09-01 11:47:11 --> Output Class Initialized
INFO - 2019-09-01 11:47:11 --> Security Class Initialized
DEBUG - 2019-09-01 11:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:47:11 --> Input Class Initialized
INFO - 2019-09-01 11:47:11 --> Language Class Initialized
INFO - 2019-09-01 11:47:11 --> Loader Class Initialized
INFO - 2019-09-01 11:47:11 --> Helper loaded: url_helper
INFO - 2019-09-01 11:47:11 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:47:15 --> Controller Class Initialized
INFO - 2019-09-01 11:47:15 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:47:15 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-09-01 11:47:15 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:47:15 --> Final output sent to browser
DEBUG - 2019-09-01 11:47:15 --> Total execution time: 6.1696
DEBUG - 2019-09-01 11:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:47:17 --> Controller Class Initialized
INFO - 2019-09-01 11:47:17 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:47:17 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-09-01 11:47:17 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:47:17 --> Final output sent to browser
DEBUG - 2019-09-01 11:47:17 --> Total execution time: 6.1775
INFO - 2019-09-01 11:55:12 --> Config Class Initialized
INFO - 2019-09-01 11:55:12 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:55:12 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:55:12 --> Utf8 Class Initialized
INFO - 2019-09-01 11:55:12 --> URI Class Initialized
INFO - 2019-09-01 11:55:12 --> Router Class Initialized
INFO - 2019-09-01 11:55:12 --> Output Class Initialized
INFO - 2019-09-01 11:55:12 --> Security Class Initialized
DEBUG - 2019-09-01 11:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:55:12 --> Input Class Initialized
INFO - 2019-09-01 11:55:12 --> Language Class Initialized
INFO - 2019-09-01 11:55:12 --> Loader Class Initialized
INFO - 2019-09-01 11:55:12 --> Helper loaded: url_helper
INFO - 2019-09-01 11:55:12 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:55:13 --> Controller Class Initialized
INFO - 2019-09-01 11:55:13 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:55:13 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/home.php
INFO - 2019-09-01 11:55:13 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:55:13 --> Final output sent to browser
DEBUG - 2019-09-01 11:55:13 --> Total execution time: 1.1303
INFO - 2019-09-01 11:55:17 --> Config Class Initialized
INFO - 2019-09-01 11:55:17 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:55:17 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:55:17 --> Utf8 Class Initialized
INFO - 2019-09-01 11:55:17 --> URI Class Initialized
INFO - 2019-09-01 11:55:17 --> Router Class Initialized
INFO - 2019-09-01 11:55:17 --> Output Class Initialized
INFO - 2019-09-01 11:55:17 --> Security Class Initialized
DEBUG - 2019-09-01 11:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:55:17 --> Input Class Initialized
INFO - 2019-09-01 11:55:17 --> Language Class Initialized
INFO - 2019-09-01 11:55:17 --> Loader Class Initialized
INFO - 2019-09-01 11:55:17 --> Helper loaded: url_helper
INFO - 2019-09-01 11:55:17 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:55:18 --> Controller Class Initialized
DEBUG - 2019-09-01 11:55:18 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:55:18 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:55:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:55:18 --> Model "Form_model" initialized
INFO - 2019-09-01 11:55:22 --> Final output sent to browser
DEBUG - 2019-09-01 11:55:22 --> Total execution time: 4.8623
INFO - 2019-09-01 11:55:22 --> Config Class Initialized
INFO - 2019-09-01 11:55:22 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:55:22 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:55:22 --> Utf8 Class Initialized
INFO - 2019-09-01 11:55:22 --> URI Class Initialized
INFO - 2019-09-01 11:55:22 --> Router Class Initialized
INFO - 2019-09-01 11:55:22 --> Output Class Initialized
INFO - 2019-09-01 11:55:22 --> Security Class Initialized
DEBUG - 2019-09-01 11:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:55:22 --> Input Class Initialized
INFO - 2019-09-01 11:55:22 --> Language Class Initialized
INFO - 2019-09-01 11:55:22 --> Loader Class Initialized
INFO - 2019-09-01 11:55:22 --> Helper loaded: url_helper
INFO - 2019-09-01 11:55:22 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:55:23 --> Controller Class Initialized
INFO - 2019-09-01 11:55:23 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:55:23 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-09-01 11:55:23 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:55:23 --> Final output sent to browser
DEBUG - 2019-09-01 11:55:23 --> Total execution time: 1.1407
INFO - 2019-09-01 11:56:00 --> Config Class Initialized
INFO - 2019-09-01 11:56:00 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:56:00 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:56:00 --> Utf8 Class Initialized
INFO - 2019-09-01 11:56:00 --> URI Class Initialized
INFO - 2019-09-01 11:56:00 --> Router Class Initialized
INFO - 2019-09-01 11:56:00 --> Output Class Initialized
INFO - 2019-09-01 11:56:00 --> Security Class Initialized
DEBUG - 2019-09-01 11:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:56:00 --> Input Class Initialized
INFO - 2019-09-01 11:56:00 --> Language Class Initialized
INFO - 2019-09-01 11:56:00 --> Loader Class Initialized
INFO - 2019-09-01 11:56:00 --> Helper loaded: url_helper
INFO - 2019-09-01 11:56:00 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:56:09 --> Controller Class Initialized
DEBUG - 2019-09-01 11:56:09 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:56:09 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:56:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:56:09 --> Model "Form_model" initialized
INFO - 2019-09-01 11:56:13 --> Final output sent to browser
DEBUG - 2019-09-01 11:56:13 --> Total execution time: 12.6926
INFO - 2019-09-01 11:56:13 --> Config Class Initialized
INFO - 2019-09-01 11:56:13 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:56:13 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:56:13 --> Utf8 Class Initialized
INFO - 2019-09-01 11:56:13 --> URI Class Initialized
INFO - 2019-09-01 11:56:13 --> Router Class Initialized
INFO - 2019-09-01 11:56:13 --> Output Class Initialized
INFO - 2019-09-01 11:56:13 --> Security Class Initialized
DEBUG - 2019-09-01 11:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:56:13 --> Input Class Initialized
INFO - 2019-09-01 11:56:13 --> Language Class Initialized
INFO - 2019-09-01 11:56:13 --> Loader Class Initialized
INFO - 2019-09-01 11:56:13 --> Helper loaded: url_helper
INFO - 2019-09-01 11:56:13 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:56:14 --> Controller Class Initialized
INFO - 2019-09-01 11:56:14 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:56:14 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-09-01 11:56:14 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:56:14 --> Final output sent to browser
DEBUG - 2019-09-01 11:56:14 --> Total execution time: 1.1944
INFO - 2019-09-01 11:56:43 --> Config Class Initialized
INFO - 2019-09-01 11:56:43 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:56:43 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:56:43 --> Utf8 Class Initialized
INFO - 2019-09-01 11:56:43 --> URI Class Initialized
INFO - 2019-09-01 11:56:43 --> Router Class Initialized
INFO - 2019-09-01 11:56:43 --> Output Class Initialized
INFO - 2019-09-01 11:56:43 --> Security Class Initialized
DEBUG - 2019-09-01 11:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:56:43 --> Input Class Initialized
INFO - 2019-09-01 11:56:43 --> Language Class Initialized
INFO - 2019-09-01 11:56:43 --> Loader Class Initialized
INFO - 2019-09-01 11:56:43 --> Helper loaded: url_helper
INFO - 2019-09-01 11:56:43 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:56:44 --> Controller Class Initialized
DEBUG - 2019-09-01 11:56:44 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 11:56:44 --> Helper loaded: inflector_helper
INFO - 2019-09-01 11:56:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 11:56:44 --> Model "Form_model" initialized
INFO - 2019-09-01 11:56:51 --> Final output sent to browser
DEBUG - 2019-09-01 11:56:51 --> Total execution time: 7.3928
INFO - 2019-09-01 11:56:51 --> Config Class Initialized
INFO - 2019-09-01 11:56:51 --> Hooks Class Initialized
DEBUG - 2019-09-01 11:56:51 --> UTF-8 Support Enabled
INFO - 2019-09-01 11:56:51 --> Utf8 Class Initialized
INFO - 2019-09-01 11:56:51 --> URI Class Initialized
INFO - 2019-09-01 11:56:51 --> Router Class Initialized
INFO - 2019-09-01 11:56:51 --> Output Class Initialized
INFO - 2019-09-01 11:56:51 --> Security Class Initialized
DEBUG - 2019-09-01 11:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 11:56:51 --> Input Class Initialized
INFO - 2019-09-01 11:56:51 --> Language Class Initialized
INFO - 2019-09-01 11:56:51 --> Loader Class Initialized
INFO - 2019-09-01 11:56:51 --> Helper loaded: url_helper
INFO - 2019-09-01 11:56:51 --> Database Driver Class Initialized
DEBUG - 2019-09-01 11:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 11:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 11:56:52 --> Controller Class Initialized
INFO - 2019-09-01 11:56:52 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 11:56:52 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-09-01 11:56:52 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 11:56:52 --> Final output sent to browser
DEBUG - 2019-09-01 11:56:52 --> Total execution time: 1.1748
INFO - 2019-09-01 12:00:15 --> Config Class Initialized
INFO - 2019-09-01 12:00:15 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:00:15 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:00:15 --> Utf8 Class Initialized
INFO - 2019-09-01 12:00:15 --> URI Class Initialized
INFO - 2019-09-01 12:00:15 --> Router Class Initialized
INFO - 2019-09-01 12:00:15 --> Output Class Initialized
INFO - 2019-09-01 12:00:15 --> Security Class Initialized
DEBUG - 2019-09-01 12:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:00:15 --> Input Class Initialized
INFO - 2019-09-01 12:00:15 --> Language Class Initialized
INFO - 2019-09-01 12:00:15 --> Loader Class Initialized
INFO - 2019-09-01 12:00:15 --> Helper loaded: url_helper
INFO - 2019-09-01 12:00:15 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:00:16 --> Controller Class Initialized
INFO - 2019-09-01 12:00:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:00:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-09-01 12:00:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:00:16 --> Final output sent to browser
DEBUG - 2019-09-01 12:00:16 --> Total execution time: 1.2421
INFO - 2019-09-01 12:00:16 --> Config Class Initialized
INFO - 2019-09-01 12:00:16 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:00:16 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:00:16 --> Utf8 Class Initialized
INFO - 2019-09-01 12:00:16 --> URI Class Initialized
INFO - 2019-09-01 12:00:16 --> Router Class Initialized
INFO - 2019-09-01 12:00:16 --> Output Class Initialized
INFO - 2019-09-01 12:00:16 --> Security Class Initialized
DEBUG - 2019-09-01 12:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:00:16 --> Input Class Initialized
INFO - 2019-09-01 12:00:16 --> Language Class Initialized
INFO - 2019-09-01 12:00:16 --> Loader Class Initialized
INFO - 2019-09-01 12:00:16 --> Helper loaded: url_helper
INFO - 2019-09-01 12:00:16 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:00:23 --> Controller Class Initialized
DEBUG - 2019-09-01 12:00:23 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 12:00:23 --> Helper loaded: inflector_helper
INFO - 2019-09-01 12:00:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 12:00:23 --> Model "Form_model" initialized
INFO - 2019-09-01 12:00:29 --> Final output sent to browser
DEBUG - 2019-09-01 12:00:29 --> Total execution time: 12.7241
INFO - 2019-09-01 12:00:40 --> Config Class Initialized
INFO - 2019-09-01 12:00:40 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:00:40 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:00:40 --> Utf8 Class Initialized
INFO - 2019-09-01 12:00:40 --> URI Class Initialized
INFO - 2019-09-01 12:00:40 --> Router Class Initialized
INFO - 2019-09-01 12:00:40 --> Output Class Initialized
INFO - 2019-09-01 12:00:40 --> Security Class Initialized
DEBUG - 2019-09-01 12:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:00:40 --> Input Class Initialized
INFO - 2019-09-01 12:00:40 --> Language Class Initialized
INFO - 2019-09-01 12:00:40 --> Loader Class Initialized
INFO - 2019-09-01 12:00:40 --> Helper loaded: url_helper
INFO - 2019-09-01 12:00:40 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:00:46 --> Controller Class Initialized
INFO - 2019-09-01 12:00:46 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:00:46 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-09-01 12:00:46 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:00:46 --> Final output sent to browser
DEBUG - 2019-09-01 12:00:46 --> Total execution time: 6.3157
INFO - 2019-09-01 12:00:46 --> Config Class Initialized
INFO - 2019-09-01 12:00:46 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:00:46 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:00:46 --> Utf8 Class Initialized
INFO - 2019-09-01 12:00:46 --> URI Class Initialized
INFO - 2019-09-01 12:00:46 --> Router Class Initialized
INFO - 2019-09-01 12:00:46 --> Output Class Initialized
INFO - 2019-09-01 12:00:46 --> Security Class Initialized
DEBUG - 2019-09-01 12:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:00:46 --> Input Class Initialized
INFO - 2019-09-01 12:00:46 --> Language Class Initialized
INFO - 2019-09-01 12:00:46 --> Loader Class Initialized
INFO - 2019-09-01 12:00:46 --> Helper loaded: url_helper
INFO - 2019-09-01 12:00:46 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:00:55 --> Controller Class Initialized
DEBUG - 2019-09-01 12:00:55 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 12:00:55 --> Helper loaded: inflector_helper
INFO - 2019-09-01 12:00:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 12:00:55 --> Model "Form_model" initialized
INFO - 2019-09-01 12:00:59 --> Final output sent to browser
DEBUG - 2019-09-01 12:00:59 --> Total execution time: 12.7639
INFO - 2019-09-01 12:02:19 --> Config Class Initialized
INFO - 2019-09-01 12:02:19 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:02:19 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:02:19 --> Utf8 Class Initialized
INFO - 2019-09-01 12:02:19 --> URI Class Initialized
INFO - 2019-09-01 12:02:19 --> Router Class Initialized
INFO - 2019-09-01 12:02:19 --> Output Class Initialized
INFO - 2019-09-01 12:02:19 --> Security Class Initialized
DEBUG - 2019-09-01 12:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:02:19 --> Input Class Initialized
INFO - 2019-09-01 12:02:19 --> Language Class Initialized
INFO - 2019-09-01 12:02:19 --> Loader Class Initialized
INFO - 2019-09-01 12:02:19 --> Helper loaded: url_helper
INFO - 2019-09-01 12:02:19 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:02:25 --> Controller Class Initialized
INFO - 2019-09-01 12:02:25 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:02:25 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-09-01 12:02:25 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:02:25 --> Final output sent to browser
DEBUG - 2019-09-01 12:02:25 --> Total execution time: 6.1718
INFO - 2019-09-01 12:02:25 --> Config Class Initialized
INFO - 2019-09-01 12:02:25 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:02:25 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:02:25 --> Utf8 Class Initialized
INFO - 2019-09-01 12:02:25 --> URI Class Initialized
INFO - 2019-09-01 12:02:25 --> Router Class Initialized
INFO - 2019-09-01 12:02:25 --> Output Class Initialized
INFO - 2019-09-01 12:02:25 --> Security Class Initialized
DEBUG - 2019-09-01 12:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:02:25 --> Input Class Initialized
INFO - 2019-09-01 12:02:25 --> Language Class Initialized
INFO - 2019-09-01 12:02:25 --> Loader Class Initialized
INFO - 2019-09-01 12:02:25 --> Helper loaded: url_helper
INFO - 2019-09-01 12:02:25 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:02:26 --> Controller Class Initialized
DEBUG - 2019-09-01 12:02:26 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 12:02:26 --> Helper loaded: inflector_helper
INFO - 2019-09-01 12:02:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 12:02:26 --> Model "Form_model" initialized
INFO - 2019-09-01 12:02:52 --> Final output sent to browser
DEBUG - 2019-09-01 12:02:52 --> Total execution time: 26.8745
INFO - 2019-09-01 12:04:27 --> Config Class Initialized
INFO - 2019-09-01 12:04:27 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:04:27 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:04:27 --> Utf8 Class Initialized
INFO - 2019-09-01 12:04:27 --> URI Class Initialized
INFO - 2019-09-01 12:04:27 --> Router Class Initialized
INFO - 2019-09-01 12:04:27 --> Output Class Initialized
INFO - 2019-09-01 12:04:27 --> Security Class Initialized
DEBUG - 2019-09-01 12:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:04:27 --> Input Class Initialized
INFO - 2019-09-01 12:04:27 --> Language Class Initialized
INFO - 2019-09-01 12:04:27 --> Loader Class Initialized
INFO - 2019-09-01 12:04:27 --> Helper loaded: url_helper
INFO - 2019-09-01 12:04:27 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:04:42 --> Controller Class Initialized
INFO - 2019-09-01 12:04:42 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:04:42 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step8.php
INFO - 2019-09-01 12:04:42 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:04:42 --> Final output sent to browser
DEBUG - 2019-09-01 12:04:42 --> Total execution time: 15.1407
INFO - 2019-09-01 12:05:25 --> Config Class Initialized
INFO - 2019-09-01 12:05:25 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:05:25 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:05:25 --> Utf8 Class Initialized
INFO - 2019-09-01 12:05:25 --> URI Class Initialized
INFO - 2019-09-01 12:05:25 --> Router Class Initialized
INFO - 2019-09-01 12:05:25 --> Output Class Initialized
INFO - 2019-09-01 12:05:25 --> Security Class Initialized
DEBUG - 2019-09-01 12:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:05:25 --> Input Class Initialized
INFO - 2019-09-01 12:05:25 --> Language Class Initialized
INFO - 2019-09-01 12:05:25 --> Loader Class Initialized
INFO - 2019-09-01 12:05:25 --> Helper loaded: url_helper
INFO - 2019-09-01 12:05:25 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:05:31 --> Controller Class Initialized
DEBUG - 2019-09-01 12:05:31 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 12:05:31 --> Helper loaded: inflector_helper
INFO - 2019-09-01 12:05:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 12:05:31 --> Model "Value_model" initialized
INFO - 2019-09-01 12:05:31 --> Model "Form_model" initialized
INFO - 2019-09-01 12:05:31 --> Model "Meta_link_model" initialized
INFO - 2019-09-01 12:05:31 --> Model "List_ks_model" initialized
ERROR - 2019-09-01 12:05:31 --> Severity: Notice --> Undefined index: form_id D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php 19
ERROR - 2019-09-01 12:05:40 --> Severity: Notice --> Undefined index: form_id D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php 29
DEBUG - 2019-09-01 12:05:40 --> Form id:
ERROR - 2019-09-01 12:05:40 --> Severity: error --> Exception: Too few arguments to function List_ks_model::create_list(), 0 passed in D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php on line 88 and exactly 1 expected D:\Programs\Xampp\htdocs\hait\application\models\List_ks_model.php 26
INFO - 2019-09-01 12:24:37 --> Config Class Initialized
INFO - 2019-09-01 12:24:37 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:24:37 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:24:37 --> Utf8 Class Initialized
INFO - 2019-09-01 12:24:37 --> URI Class Initialized
INFO - 2019-09-01 12:24:37 --> Router Class Initialized
INFO - 2019-09-01 12:24:37 --> Output Class Initialized
INFO - 2019-09-01 12:24:37 --> Security Class Initialized
DEBUG - 2019-09-01 12:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:24:37 --> Input Class Initialized
INFO - 2019-09-01 12:24:37 --> Language Class Initialized
INFO - 2019-09-01 12:24:37 --> Loader Class Initialized
INFO - 2019-09-01 12:24:37 --> Helper loaded: url_helper
INFO - 2019-09-01 12:24:37 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:24:43 --> Controller Class Initialized
INFO - 2019-09-01 12:24:43 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:24:43 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step8.php
INFO - 2019-09-01 12:24:43 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:24:43 --> Final output sent to browser
DEBUG - 2019-09-01 12:24:43 --> Total execution time: 6.1774
INFO - 2019-09-01 12:24:45 --> Config Class Initialized
INFO - 2019-09-01 12:24:45 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:24:45 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:24:45 --> Utf8 Class Initialized
INFO - 2019-09-01 12:24:45 --> URI Class Initialized
INFO - 2019-09-01 12:24:45 --> Router Class Initialized
INFO - 2019-09-01 12:24:45 --> Output Class Initialized
INFO - 2019-09-01 12:24:45 --> Security Class Initialized
DEBUG - 2019-09-01 12:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:24:45 --> Input Class Initialized
INFO - 2019-09-01 12:24:45 --> Language Class Initialized
INFO - 2019-09-01 12:24:45 --> Loader Class Initialized
INFO - 2019-09-01 12:24:45 --> Helper loaded: url_helper
INFO - 2019-09-01 12:24:45 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:24:47 --> Controller Class Initialized
INFO - 2019-09-01 12:24:47 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:24:47 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step6.php
INFO - 2019-09-01 12:24:47 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:24:47 --> Final output sent to browser
DEBUG - 2019-09-01 12:24:47 --> Total execution time: 1.1260
INFO - 2019-09-01 12:24:48 --> Config Class Initialized
INFO - 2019-09-01 12:24:48 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:24:48 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:24:48 --> Utf8 Class Initialized
INFO - 2019-09-01 12:24:48 --> URI Class Initialized
INFO - 2019-09-01 12:24:48 --> Router Class Initialized
INFO - 2019-09-01 12:24:48 --> Output Class Initialized
INFO - 2019-09-01 12:24:48 --> Security Class Initialized
DEBUG - 2019-09-01 12:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:24:48 --> Input Class Initialized
INFO - 2019-09-01 12:24:48 --> Language Class Initialized
INFO - 2019-09-01 12:24:48 --> Loader Class Initialized
INFO - 2019-09-01 12:24:48 --> Helper loaded: url_helper
INFO - 2019-09-01 12:24:48 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:24:49 --> Controller Class Initialized
INFO - 2019-09-01 12:24:49 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:24:50 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step5.php
INFO - 2019-09-01 12:24:50 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:24:50 --> Final output sent to browser
DEBUG - 2019-09-01 12:24:50 --> Total execution time: 1.2483
INFO - 2019-09-01 12:24:55 --> Config Class Initialized
INFO - 2019-09-01 12:24:55 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:24:55 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:24:55 --> Utf8 Class Initialized
INFO - 2019-09-01 12:24:55 --> URI Class Initialized
INFO - 2019-09-01 12:24:55 --> Router Class Initialized
INFO - 2019-09-01 12:24:55 --> Output Class Initialized
INFO - 2019-09-01 12:24:55 --> Security Class Initialized
DEBUG - 2019-09-01 12:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:24:55 --> Input Class Initialized
INFO - 2019-09-01 12:24:55 --> Language Class Initialized
INFO - 2019-09-01 12:24:55 --> Loader Class Initialized
INFO - 2019-09-01 12:24:55 --> Helper loaded: url_helper
INFO - 2019-09-01 12:24:55 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:25:24 --> Controller Class Initialized
INFO - 2019-09-01 12:25:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:25:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step4.php
INFO - 2019-09-01 12:25:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:25:24 --> Final output sent to browser
DEBUG - 2019-09-01 12:25:24 --> Total execution time: 29.1981
INFO - 2019-09-01 12:25:43 --> Config Class Initialized
INFO - 2019-09-01 12:25:43 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:25:43 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:25:43 --> Utf8 Class Initialized
INFO - 2019-09-01 12:25:43 --> URI Class Initialized
INFO - 2019-09-01 12:25:43 --> Router Class Initialized
INFO - 2019-09-01 12:25:43 --> Output Class Initialized
INFO - 2019-09-01 12:25:43 --> Security Class Initialized
DEBUG - 2019-09-01 12:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:25:43 --> Input Class Initialized
INFO - 2019-09-01 12:25:43 --> Language Class Initialized
INFO - 2019-09-01 12:25:43 --> Loader Class Initialized
INFO - 2019-09-01 12:25:43 --> Helper loaded: url_helper
INFO - 2019-09-01 12:25:43 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:25:52 --> Controller Class Initialized
INFO - 2019-09-01 12:25:52 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:25:52 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step3.php
INFO - 2019-09-01 12:25:52 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:25:52 --> Final output sent to browser
DEBUG - 2019-09-01 12:25:52 --> Total execution time: 9.2063
INFO - 2019-09-01 12:26:15 --> Config Class Initialized
INFO - 2019-09-01 12:26:15 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:26:15 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:26:15 --> Utf8 Class Initialized
INFO - 2019-09-01 12:26:15 --> URI Class Initialized
INFO - 2019-09-01 12:26:15 --> Router Class Initialized
INFO - 2019-09-01 12:26:15 --> Output Class Initialized
INFO - 2019-09-01 12:26:15 --> Security Class Initialized
DEBUG - 2019-09-01 12:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:26:15 --> Input Class Initialized
INFO - 2019-09-01 12:26:15 --> Language Class Initialized
INFO - 2019-09-01 12:26:15 --> Loader Class Initialized
INFO - 2019-09-01 12:26:15 --> Helper loaded: url_helper
INFO - 2019-09-01 12:26:15 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:26:16 --> Controller Class Initialized
INFO - 2019-09-01 12:26:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:26:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 12:26:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:26:16 --> Final output sent to browser
DEBUG - 2019-09-01 12:26:16 --> Total execution time: 1.1426
INFO - 2019-09-01 12:26:16 --> Config Class Initialized
INFO - 2019-09-01 12:26:16 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:26:16 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:26:16 --> Utf8 Class Initialized
INFO - 2019-09-01 12:26:16 --> URI Class Initialized
INFO - 2019-09-01 12:26:16 --> Router Class Initialized
INFO - 2019-09-01 12:26:16 --> Output Class Initialized
INFO - 2019-09-01 12:26:16 --> Security Class Initialized
DEBUG - 2019-09-01 12:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:26:16 --> Input Class Initialized
INFO - 2019-09-01 12:26:16 --> Language Class Initialized
INFO - 2019-09-01 12:26:16 --> Loader Class Initialized
INFO - 2019-09-01 12:26:16 --> Helper loaded: url_helper
INFO - 2019-09-01 12:26:16 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:26:17 --> Controller Class Initialized
DEBUG - 2019-09-01 12:26:17 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 12:26:17 --> Helper loaded: inflector_helper
INFO - 2019-09-01 12:26:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 12:26:17 --> Model "Template_model" initialized
INFO - 2019-09-01 12:26:17 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 12:26:29 --> Final output sent to browser
DEBUG - 2019-09-01 12:26:29 --> Total execution time: 13.3539
INFO - 2019-09-01 12:27:08 --> Config Class Initialized
INFO - 2019-09-01 12:27:08 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:27:08 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:27:08 --> Utf8 Class Initialized
INFO - 2019-09-01 12:27:08 --> URI Class Initialized
INFO - 2019-09-01 12:27:08 --> Router Class Initialized
INFO - 2019-09-01 12:27:08 --> Output Class Initialized
INFO - 2019-09-01 12:27:08 --> Security Class Initialized
DEBUG - 2019-09-01 12:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:27:08 --> Input Class Initialized
INFO - 2019-09-01 12:27:08 --> Language Class Initialized
INFO - 2019-09-01 12:27:08 --> Loader Class Initialized
INFO - 2019-09-01 12:27:08 --> Helper loaded: url_helper
INFO - 2019-09-01 12:27:08 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:27:18 --> Controller Class Initialized
INFO - 2019-09-01 12:27:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:27:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 12:27:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:27:18 --> Final output sent to browser
DEBUG - 2019-09-01 12:27:18 --> Total execution time: 10.3928
INFO - 2019-09-01 12:27:20 --> Config Class Initialized
INFO - 2019-09-01 12:27:20 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:27:20 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:27:20 --> Utf8 Class Initialized
INFO - 2019-09-01 12:27:20 --> URI Class Initialized
INFO - 2019-09-01 12:27:20 --> Router Class Initialized
INFO - 2019-09-01 12:27:20 --> Output Class Initialized
INFO - 2019-09-01 12:27:20 --> Security Class Initialized
DEBUG - 2019-09-01 12:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:27:20 --> Input Class Initialized
INFO - 2019-09-01 12:27:20 --> Language Class Initialized
INFO - 2019-09-01 12:27:20 --> Loader Class Initialized
INFO - 2019-09-01 12:27:20 --> Helper loaded: url_helper
INFO - 2019-09-01 12:27:20 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:27:21 --> Controller Class Initialized
DEBUG - 2019-09-01 12:27:21 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 12:27:21 --> Helper loaded: inflector_helper
INFO - 2019-09-01 12:27:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 12:27:21 --> Model "Template_model" initialized
INFO - 2019-09-01 12:27:21 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 12:27:22 --> Final output sent to browser
DEBUG - 2019-09-01 12:27:22 --> Total execution time: 2.0436
INFO - 2019-09-01 12:28:26 --> Config Class Initialized
INFO - 2019-09-01 12:28:26 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:28:26 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:28:26 --> Utf8 Class Initialized
INFO - 2019-09-01 12:28:26 --> URI Class Initialized
INFO - 2019-09-01 12:28:26 --> Router Class Initialized
INFO - 2019-09-01 12:28:26 --> Output Class Initialized
INFO - 2019-09-01 12:28:26 --> Security Class Initialized
DEBUG - 2019-09-01 12:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:28:26 --> Input Class Initialized
INFO - 2019-09-01 12:28:26 --> Language Class Initialized
INFO - 2019-09-01 12:28:26 --> Loader Class Initialized
INFO - 2019-09-01 12:28:26 --> Helper loaded: url_helper
INFO - 2019-09-01 12:28:26 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:28:41 --> Controller Class Initialized
INFO - 2019-09-01 12:28:41 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:28:41 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step3.php
INFO - 2019-09-01 12:28:41 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:28:41 --> Final output sent to browser
DEBUG - 2019-09-01 12:28:41 --> Total execution time: 15.1386
INFO - 2019-09-01 12:28:50 --> Config Class Initialized
INFO - 2019-09-01 12:28:50 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:28:50 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:28:50 --> Utf8 Class Initialized
INFO - 2019-09-01 12:28:50 --> URI Class Initialized
INFO - 2019-09-01 12:28:50 --> Router Class Initialized
INFO - 2019-09-01 12:28:50 --> Output Class Initialized
INFO - 2019-09-01 12:28:50 --> Security Class Initialized
DEBUG - 2019-09-01 12:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:28:50 --> Input Class Initialized
INFO - 2019-09-01 12:28:50 --> Language Class Initialized
INFO - 2019-09-01 12:28:50 --> Loader Class Initialized
INFO - 2019-09-01 12:28:50 --> Helper loaded: url_helper
INFO - 2019-09-01 12:28:50 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:28:51 --> Controller Class Initialized
INFO - 2019-09-01 12:28:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:28:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step8.php
INFO - 2019-09-01 12:28:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:28:51 --> Final output sent to browser
DEBUG - 2019-09-01 12:28:51 --> Total execution time: 1.1674
INFO - 2019-09-01 12:29:16 --> Config Class Initialized
INFO - 2019-09-01 12:29:16 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:29:16 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:29:16 --> Utf8 Class Initialized
INFO - 2019-09-01 12:29:16 --> URI Class Initialized
INFO - 2019-09-01 12:29:16 --> Router Class Initialized
INFO - 2019-09-01 12:29:16 --> Output Class Initialized
INFO - 2019-09-01 12:29:16 --> Security Class Initialized
DEBUG - 2019-09-01 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:29:16 --> Input Class Initialized
INFO - 2019-09-01 12:29:16 --> Language Class Initialized
INFO - 2019-09-01 12:29:16 --> Loader Class Initialized
INFO - 2019-09-01 12:29:16 --> Helper loaded: url_helper
INFO - 2019-09-01 12:29:16 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:29:22 --> Controller Class Initialized
DEBUG - 2019-09-01 12:29:22 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 12:29:23 --> Helper loaded: inflector_helper
INFO - 2019-09-01 12:29:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 12:29:23 --> Model "Value_model" initialized
INFO - 2019-09-01 12:29:23 --> Model "Form_model" initialized
INFO - 2019-09-01 12:29:23 --> Model "Meta_link_model" initialized
INFO - 2019-09-01 12:29:23 --> Model "List_ks_model" initialized
ERROR - 2019-09-01 12:29:23 --> Severity: Notice --> Undefined index: form_id D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php 19
ERROR - 2019-09-01 12:29:27 --> Severity: Notice --> Undefined index: form_id D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php 29
DEBUG - 2019-09-01 12:29:27 --> Form id:
ERROR - 2019-09-01 12:29:27 --> Severity: error --> Exception: Too few arguments to function List_ks_model::create_list(), 0 passed in D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php on line 88 and exactly 1 expected D:\Programs\Xampp\htdocs\hait\application\models\List_ks_model.php 26
INFO - 2019-09-01 12:29:39 --> Config Class Initialized
INFO - 2019-09-01 12:29:39 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:29:39 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:29:39 --> Utf8 Class Initialized
INFO - 2019-09-01 12:29:39 --> URI Class Initialized
INFO - 2019-09-01 12:29:39 --> Router Class Initialized
INFO - 2019-09-01 12:29:39 --> Output Class Initialized
INFO - 2019-09-01 12:29:39 --> Security Class Initialized
DEBUG - 2019-09-01 12:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:29:39 --> Input Class Initialized
INFO - 2019-09-01 12:29:39 --> Language Class Initialized
INFO - 2019-09-01 12:29:39 --> Loader Class Initialized
INFO - 2019-09-01 12:29:39 --> Helper loaded: url_helper
INFO - 2019-09-01 12:29:39 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:29:40 --> Controller Class Initialized
INFO - 2019-09-01 12:29:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:29:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step8.php
INFO - 2019-09-01 12:29:40 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:29:40 --> Final output sent to browser
DEBUG - 2019-09-01 12:29:40 --> Total execution time: 1.1753
INFO - 2019-09-01 12:29:48 --> Config Class Initialized
INFO - 2019-09-01 12:29:48 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:29:48 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:29:48 --> Utf8 Class Initialized
INFO - 2019-09-01 12:29:48 --> URI Class Initialized
INFO - 2019-09-01 12:29:48 --> Router Class Initialized
INFO - 2019-09-01 12:29:48 --> Output Class Initialized
INFO - 2019-09-01 12:29:48 --> Security Class Initialized
DEBUG - 2019-09-01 12:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:29:48 --> Input Class Initialized
INFO - 2019-09-01 12:29:48 --> Language Class Initialized
INFO - 2019-09-01 12:29:48 --> Loader Class Initialized
INFO - 2019-09-01 12:29:48 --> Helper loaded: url_helper
INFO - 2019-09-01 12:29:48 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:29:49 --> Controller Class Initialized
DEBUG - 2019-09-01 12:29:49 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 12:29:49 --> Helper loaded: inflector_helper
INFO - 2019-09-01 12:29:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 12:29:49 --> Model "Value_model" initialized
INFO - 2019-09-01 12:29:49 --> Model "Form_model" initialized
INFO - 2019-09-01 12:29:49 --> Model "Meta_link_model" initialized
INFO - 2019-09-01 12:29:49 --> Model "List_ks_model" initialized
ERROR - 2019-09-01 12:29:49 --> Severity: Notice --> Undefined index: form_id D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php 19
ERROR - 2019-09-01 12:29:52 --> Severity: Notice --> Undefined index: form_id D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php 29
DEBUG - 2019-09-01 12:29:52 --> Form id:
ERROR - 2019-09-01 12:29:52 --> Severity: error --> Exception: Too few arguments to function List_ks_model::create_list(), 0 passed in D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php on line 88 and exactly 1 expected D:\Programs\Xampp\htdocs\hait\application\models\List_ks_model.php 26
INFO - 2019-09-01 12:30:24 --> Config Class Initialized
INFO - 2019-09-01 12:30:24 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:30:24 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:30:24 --> Utf8 Class Initialized
INFO - 2019-09-01 12:30:24 --> URI Class Initialized
INFO - 2019-09-01 12:30:24 --> Router Class Initialized
INFO - 2019-09-01 12:30:24 --> Output Class Initialized
INFO - 2019-09-01 12:30:24 --> Security Class Initialized
DEBUG - 2019-09-01 12:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:30:24 --> Input Class Initialized
INFO - 2019-09-01 12:30:24 --> Language Class Initialized
INFO - 2019-09-01 12:30:24 --> Loader Class Initialized
INFO - 2019-09-01 12:30:24 --> Helper loaded: url_helper
INFO - 2019-09-01 12:30:24 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:30:34 --> Controller Class Initialized
INFO - 2019-09-01 12:30:34 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:30:34 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step6.php
INFO - 2019-09-01 12:30:34 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:30:34 --> Final output sent to browser
DEBUG - 2019-09-01 12:30:34 --> Total execution time: 9.1420
INFO - 2019-09-01 12:31:34 --> Config Class Initialized
INFO - 2019-09-01 12:31:34 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:31:34 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:31:34 --> Utf8 Class Initialized
INFO - 2019-09-01 12:31:34 --> URI Class Initialized
INFO - 2019-09-01 12:31:34 --> Router Class Initialized
INFO - 2019-09-01 12:31:34 --> Output Class Initialized
INFO - 2019-09-01 12:31:34 --> Security Class Initialized
DEBUG - 2019-09-01 12:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:31:34 --> Input Class Initialized
INFO - 2019-09-01 12:31:34 --> Language Class Initialized
INFO - 2019-09-01 12:31:34 --> Loader Class Initialized
INFO - 2019-09-01 12:31:34 --> Helper loaded: url_helper
INFO - 2019-09-01 12:31:34 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:31:35 --> Controller Class Initialized
INFO - 2019-09-01 12:31:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:31:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_1.php
INFO - 2019-09-01 12:31:35 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:31:35 --> Final output sent to browser
DEBUG - 2019-09-01 12:31:35 --> Total execution time: 1.2562
INFO - 2019-09-01 12:31:37 --> Config Class Initialized
INFO - 2019-09-01 12:31:37 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:31:37 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:31:37 --> Utf8 Class Initialized
INFO - 2019-09-01 12:31:37 --> URI Class Initialized
INFO - 2019-09-01 12:31:37 --> Router Class Initialized
INFO - 2019-09-01 12:31:37 --> Output Class Initialized
INFO - 2019-09-01 12:31:37 --> Security Class Initialized
DEBUG - 2019-09-01 12:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:31:37 --> Input Class Initialized
INFO - 2019-09-01 12:31:37 --> Language Class Initialized
INFO - 2019-09-01 12:31:37 --> Loader Class Initialized
INFO - 2019-09-01 12:31:37 --> Helper loaded: url_helper
INFO - 2019-09-01 12:31:37 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:31:38 --> Controller Class Initialized
DEBUG - 2019-09-01 12:31:38 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 12:31:38 --> Helper loaded: inflector_helper
INFO - 2019-09-01 12:31:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 12:31:38 --> Model "Template_model" initialized
INFO - 2019-09-01 12:31:38 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 12:31:38 --> Final output sent to browser
DEBUG - 2019-09-01 12:31:38 --> Total execution time: 1.6226
INFO - 2019-09-01 12:32:19 --> Config Class Initialized
INFO - 2019-09-01 12:32:19 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:32:19 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:32:19 --> Utf8 Class Initialized
INFO - 2019-09-01 12:32:19 --> URI Class Initialized
INFO - 2019-09-01 12:32:19 --> Router Class Initialized
INFO - 2019-09-01 12:32:19 --> Output Class Initialized
INFO - 2019-09-01 12:32:19 --> Security Class Initialized
DEBUG - 2019-09-01 12:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:32:19 --> Input Class Initialized
INFO - 2019-09-01 12:32:19 --> Language Class Initialized
INFO - 2019-09-01 12:32:19 --> Loader Class Initialized
INFO - 2019-09-01 12:32:19 --> Helper loaded: url_helper
INFO - 2019-09-01 12:32:19 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:32:25 --> Controller Class Initialized
INFO - 2019-09-01 12:32:25 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:32:25 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step8.php
INFO - 2019-09-01 12:32:25 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:32:25 --> Final output sent to browser
DEBUG - 2019-09-01 12:32:25 --> Total execution time: 6.1869
INFO - 2019-09-01 12:32:28 --> Config Class Initialized
INFO - 2019-09-01 12:32:28 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:32:28 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:32:28 --> Utf8 Class Initialized
INFO - 2019-09-01 12:32:28 --> URI Class Initialized
INFO - 2019-09-01 12:32:28 --> Router Class Initialized
INFO - 2019-09-01 12:32:28 --> Output Class Initialized
INFO - 2019-09-01 12:32:28 --> Security Class Initialized
DEBUG - 2019-09-01 12:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:32:28 --> Input Class Initialized
INFO - 2019-09-01 12:32:28 --> Language Class Initialized
INFO - 2019-09-01 12:32:28 --> Loader Class Initialized
INFO - 2019-09-01 12:32:28 --> Helper loaded: url_helper
INFO - 2019-09-01 12:32:28 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:32:58 --> Controller Class Initialized
DEBUG - 2019-09-01 12:32:58 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 12:32:58 --> Helper loaded: inflector_helper
INFO - 2019-09-01 12:32:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 12:32:58 --> Model "Value_model" initialized
INFO - 2019-09-01 12:32:58 --> Model "Form_model" initialized
INFO - 2019-09-01 12:32:58 --> Model "Meta_link_model" initialized
INFO - 2019-09-01 12:32:58 --> Model "List_ks_model" initialized
ERROR - 2019-09-01 12:32:58 --> Severity: Notice --> Undefined index: form_id D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php 19
ERROR - 2019-09-01 12:33:01 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 307
INFO - 2019-09-01 12:34:27 --> Config Class Initialized
INFO - 2019-09-01 12:34:27 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:34:27 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:34:27 --> Utf8 Class Initialized
INFO - 2019-09-01 12:34:27 --> URI Class Initialized
INFO - 2019-09-01 12:34:27 --> Router Class Initialized
INFO - 2019-09-01 12:34:27 --> Output Class Initialized
INFO - 2019-09-01 12:34:27 --> Security Class Initialized
DEBUG - 2019-09-01 12:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:34:27 --> Input Class Initialized
INFO - 2019-09-01 12:34:27 --> Language Class Initialized
INFO - 2019-09-01 12:34:27 --> Loader Class Initialized
INFO - 2019-09-01 12:34:27 --> Helper loaded: url_helper
INFO - 2019-09-01 12:34:27 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:34:29 --> Controller Class Initialized
INFO - 2019-09-01 12:34:29 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:34:29 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step8.php
INFO - 2019-09-01 12:34:29 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:34:29 --> Final output sent to browser
DEBUG - 2019-09-01 12:34:29 --> Total execution time: 1.3059
INFO - 2019-09-01 12:34:31 --> Config Class Initialized
INFO - 2019-09-01 12:34:31 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:34:31 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:34:31 --> Utf8 Class Initialized
INFO - 2019-09-01 12:34:31 --> URI Class Initialized
INFO - 2019-09-01 12:34:31 --> Router Class Initialized
INFO - 2019-09-01 12:34:31 --> Output Class Initialized
INFO - 2019-09-01 12:34:31 --> Security Class Initialized
DEBUG - 2019-09-01 12:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:34:31 --> Input Class Initialized
INFO - 2019-09-01 12:34:31 --> Language Class Initialized
INFO - 2019-09-01 12:34:31 --> Loader Class Initialized
INFO - 2019-09-01 12:34:31 --> Helper loaded: url_helper
INFO - 2019-09-01 12:34:31 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:34:52 --> Controller Class Initialized
DEBUG - 2019-09-01 12:34:52 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 12:34:52 --> Helper loaded: inflector_helper
INFO - 2019-09-01 12:34:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 12:34:52 --> Model "Value_model" initialized
INFO - 2019-09-01 12:34:52 --> Model "Form_model" initialized
INFO - 2019-09-01 12:34:52 --> Model "Meta_link_model" initialized
INFO - 2019-09-01 12:34:52 --> Model "List_ks_model" initialized
ERROR - 2019-09-01 12:34:52 --> Severity: Notice --> Undefined index: form_id D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php 19
ERROR - 2019-09-01 12:34:55 --> Severity: Notice --> Undefined index: form_id D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php 29
DEBUG - 2019-09-01 12:34:55 --> Form id:
ERROR - 2019-09-01 12:34:55 --> Severity: error --> Exception: Too few arguments to function List_ks_model::create_list(), 0 passed in D:\Programs\Xampp\htdocs\hait\application\controllers\ajax\Update_form.php on line 88 and exactly 1 expected D:\Programs\Xampp\htdocs\hait\application\models\List_ks_model.php 26
INFO - 2019-09-01 12:48:38 --> Config Class Initialized
INFO - 2019-09-01 12:48:38 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:48:38 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:48:38 --> Utf8 Class Initialized
INFO - 2019-09-01 12:48:38 --> URI Class Initialized
INFO - 2019-09-01 12:48:38 --> Router Class Initialized
INFO - 2019-09-01 12:48:38 --> Output Class Initialized
INFO - 2019-09-01 12:48:38 --> Security Class Initialized
DEBUG - 2019-09-01 12:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:48:38 --> Input Class Initialized
INFO - 2019-09-01 12:48:38 --> Language Class Initialized
INFO - 2019-09-01 12:48:38 --> Loader Class Initialized
INFO - 2019-09-01 12:48:38 --> Helper loaded: url_helper
INFO - 2019-09-01 12:48:38 --> Database Driver Class Initialized
INFO - 2019-09-01 12:48:38 --> Config Class Initialized
INFO - 2019-09-01 12:48:38 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:48:38 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:48:38 --> Utf8 Class Initialized
INFO - 2019-09-01 12:48:38 --> URI Class Initialized
INFO - 2019-09-01 12:48:38 --> Router Class Initialized
INFO - 2019-09-01 12:48:38 --> Output Class Initialized
INFO - 2019-09-01 12:48:38 --> Security Class Initialized
DEBUG - 2019-09-01 12:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:48:38 --> Input Class Initialized
INFO - 2019-09-01 12:48:38 --> Language Class Initialized
INFO - 2019-09-01 12:48:38 --> Loader Class Initialized
INFO - 2019-09-01 12:48:38 --> Helper loaded: url_helper
INFO - 2019-09-01 12:48:38 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:48:39 --> Controller Class Initialized
INFO - 2019-09-01 12:48:39 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:48:39 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step8.php
INFO - 2019-09-01 12:48:39 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:48:39 --> Final output sent to browser
DEBUG - 2019-09-01 12:48:39 --> Total execution time: 1.1693
DEBUG - 2019-09-01 12:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:48:39 --> Controller Class Initialized
INFO - 2019-09-01 12:48:39 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:48:39 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step8.php
INFO - 2019-09-01 12:48:39 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:48:39 --> Final output sent to browser
DEBUG - 2019-09-01 12:48:39 --> Total execution time: 1.1245
INFO - 2019-09-01 12:48:54 --> Config Class Initialized
INFO - 2019-09-01 12:48:54 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:48:54 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:48:54 --> Utf8 Class Initialized
INFO - 2019-09-01 12:48:54 --> URI Class Initialized
INFO - 2019-09-01 12:48:54 --> Router Class Initialized
INFO - 2019-09-01 12:48:54 --> Output Class Initialized
INFO - 2019-09-01 12:48:54 --> Security Class Initialized
DEBUG - 2019-09-01 12:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:48:54 --> Input Class Initialized
INFO - 2019-09-01 12:48:54 --> Language Class Initialized
INFO - 2019-09-01 12:48:54 --> Loader Class Initialized
INFO - 2019-09-01 12:48:54 --> Helper loaded: url_helper
INFO - 2019-09-01 12:48:54 --> Database Driver Class Initialized
INFO - 2019-09-01 12:48:55 --> Config Class Initialized
INFO - 2019-09-01 12:48:55 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:48:55 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:48:55 --> Utf8 Class Initialized
INFO - 2019-09-01 12:48:55 --> URI Class Initialized
INFO - 2019-09-01 12:48:55 --> Router Class Initialized
INFO - 2019-09-01 12:48:55 --> Output Class Initialized
INFO - 2019-09-01 12:48:55 --> Security Class Initialized
DEBUG - 2019-09-01 12:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:48:55 --> Input Class Initialized
INFO - 2019-09-01 12:48:55 --> Language Class Initialized
INFO - 2019-09-01 12:48:55 --> Loader Class Initialized
INFO - 2019-09-01 12:48:55 --> Helper loaded: url_helper
INFO - 2019-09-01 12:48:55 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:48:56 --> Controller Class Initialized
INFO - 2019-09-01 12:48:56 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:48:56 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 12:48:56 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:48:56 --> Final output sent to browser
DEBUG - 2019-09-01 12:48:56 --> Total execution time: 1.1827
INFO - 2019-09-01 12:48:57 --> Config Class Initialized
INFO - 2019-09-01 12:48:57 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:48:57 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:48:57 --> Utf8 Class Initialized
INFO - 2019-09-01 12:48:57 --> URI Class Initialized
INFO - 2019-09-01 12:48:57 --> Router Class Initialized
INFO - 2019-09-01 12:48:57 --> Output Class Initialized
INFO - 2019-09-01 12:48:57 --> Security Class Initialized
DEBUG - 2019-09-01 12:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:48:57 --> Input Class Initialized
INFO - 2019-09-01 12:48:57 --> Language Class Initialized
INFO - 2019-09-01 12:48:57 --> Loader Class Initialized
INFO - 2019-09-01 12:48:57 --> Helper loaded: url_helper
INFO - 2019-09-01 12:48:57 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:48:58 --> Controller Class Initialized
DEBUG - 2019-09-01 12:48:58 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 12:48:58 --> Helper loaded: inflector_helper
INFO - 2019-09-01 12:48:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 12:48:58 --> Model "Template_model" initialized
INFO - 2019-09-01 12:48:58 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 12:48:59 --> Final output sent to browser
DEBUG - 2019-09-01 12:48:59 --> Total execution time: 2.4514
DEBUG - 2019-09-01 12:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:49:18 --> Controller Class Initialized
INFO - 2019-09-01 12:49:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:49:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 12:49:18 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:49:18 --> Final output sent to browser
DEBUG - 2019-09-01 12:49:18 --> Total execution time: 23.2145
INFO - 2019-09-01 12:58:54 --> Config Class Initialized
INFO - 2019-09-01 12:58:54 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:58:54 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:58:54 --> Utf8 Class Initialized
INFO - 2019-09-01 12:58:54 --> URI Class Initialized
INFO - 2019-09-01 12:58:54 --> Router Class Initialized
INFO - 2019-09-01 12:58:54 --> Output Class Initialized
INFO - 2019-09-01 12:58:54 --> Security Class Initialized
DEBUG - 2019-09-01 12:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:58:54 --> Input Class Initialized
INFO - 2019-09-01 12:58:54 --> Language Class Initialized
INFO - 2019-09-01 12:58:54 --> Loader Class Initialized
INFO - 2019-09-01 12:58:54 --> Helper loaded: url_helper
INFO - 2019-09-01 12:58:54 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:59:24 --> Controller Class Initialized
INFO - 2019-09-01 12:59:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:59:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 12:59:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:59:24 --> Final output sent to browser
DEBUG - 2019-09-01 12:59:24 --> Total execution time: 29.2878
INFO - 2019-09-01 12:59:25 --> Config Class Initialized
INFO - 2019-09-01 12:59:25 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:59:25 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:59:25 --> Utf8 Class Initialized
INFO - 2019-09-01 12:59:25 --> URI Class Initialized
INFO - 2019-09-01 12:59:25 --> Router Class Initialized
INFO - 2019-09-01 12:59:25 --> Output Class Initialized
INFO - 2019-09-01 12:59:25 --> Security Class Initialized
DEBUG - 2019-09-01 12:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:59:25 --> Input Class Initialized
INFO - 2019-09-01 12:59:25 --> Language Class Initialized
INFO - 2019-09-01 12:59:25 --> Loader Class Initialized
INFO - 2019-09-01 12:59:25 --> Helper loaded: url_helper
INFO - 2019-09-01 12:59:25 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:59:34 --> Controller Class Initialized
DEBUG - 2019-09-01 12:59:34 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 12:59:34 --> Helper loaded: inflector_helper
INFO - 2019-09-01 12:59:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 12:59:34 --> Model "Template_model" initialized
INFO - 2019-09-01 12:59:34 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 12:59:41 --> Final output sent to browser
DEBUG - 2019-09-01 12:59:41 --> Total execution time: 16.2298
INFO - 2019-09-01 12:59:57 --> Config Class Initialized
INFO - 2019-09-01 12:59:57 --> Hooks Class Initialized
DEBUG - 2019-09-01 12:59:57 --> UTF-8 Support Enabled
INFO - 2019-09-01 12:59:57 --> Utf8 Class Initialized
INFO - 2019-09-01 12:59:57 --> URI Class Initialized
INFO - 2019-09-01 12:59:57 --> Router Class Initialized
INFO - 2019-09-01 12:59:57 --> Output Class Initialized
INFO - 2019-09-01 12:59:57 --> Security Class Initialized
DEBUG - 2019-09-01 12:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 12:59:57 --> Input Class Initialized
INFO - 2019-09-01 12:59:57 --> Language Class Initialized
INFO - 2019-09-01 12:59:57 --> Loader Class Initialized
INFO - 2019-09-01 12:59:57 --> Helper loaded: url_helper
INFO - 2019-09-01 12:59:57 --> Database Driver Class Initialized
DEBUG - 2019-09-01 12:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 12:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 12:59:58 --> Controller Class Initialized
INFO - 2019-09-01 12:59:58 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 12:59:58 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-09-01 12:59:58 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 12:59:58 --> Final output sent to browser
DEBUG - 2019-09-01 12:59:58 --> Total execution time: 1.1631
INFO - 2019-09-01 13:00:02 --> Config Class Initialized
INFO - 2019-09-01 13:00:02 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:00:02 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:00:02 --> Utf8 Class Initialized
INFO - 2019-09-01 13:00:02 --> URI Class Initialized
INFO - 2019-09-01 13:00:02 --> Router Class Initialized
INFO - 2019-09-01 13:00:02 --> Output Class Initialized
INFO - 2019-09-01 13:00:02 --> Security Class Initialized
DEBUG - 2019-09-01 13:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:00:02 --> Input Class Initialized
INFO - 2019-09-01 13:00:02 --> Language Class Initialized
INFO - 2019-09-01 13:00:02 --> Loader Class Initialized
INFO - 2019-09-01 13:00:02 --> Helper loaded: url_helper
INFO - 2019-09-01 13:00:02 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:00:12 --> Controller Class Initialized
INFO - 2019-09-01 13:00:12 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 13:00:12 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 13:00:12 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 13:00:12 --> Final output sent to browser
DEBUG - 2019-09-01 13:00:12 --> Total execution time: 9.1855
INFO - 2019-09-01 13:00:12 --> Config Class Initialized
INFO - 2019-09-01 13:00:12 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:00:12 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:00:12 --> Utf8 Class Initialized
INFO - 2019-09-01 13:00:12 --> URI Class Initialized
INFO - 2019-09-01 13:00:12 --> Router Class Initialized
INFO - 2019-09-01 13:00:12 --> Output Class Initialized
INFO - 2019-09-01 13:00:12 --> Security Class Initialized
DEBUG - 2019-09-01 13:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:00:12 --> Input Class Initialized
INFO - 2019-09-01 13:00:12 --> Language Class Initialized
INFO - 2019-09-01 13:00:13 --> Loader Class Initialized
INFO - 2019-09-01 13:00:13 --> Helper loaded: url_helper
INFO - 2019-09-01 13:00:13 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:00:14 --> Controller Class Initialized
DEBUG - 2019-09-01 13:00:14 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 13:00:14 --> Helper loaded: inflector_helper
INFO - 2019-09-01 13:00:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 13:00:14 --> Model "Template_model" initialized
INFO - 2019-09-01 13:00:14 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 13:00:15 --> Final output sent to browser
DEBUG - 2019-09-01 13:00:15 --> Total execution time: 2.3959
INFO - 2019-09-01 13:00:36 --> Config Class Initialized
INFO - 2019-09-01 13:00:36 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:00:36 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:00:36 --> Utf8 Class Initialized
INFO - 2019-09-01 13:00:36 --> URI Class Initialized
INFO - 2019-09-01 13:00:36 --> Router Class Initialized
INFO - 2019-09-01 13:00:36 --> Output Class Initialized
INFO - 2019-09-01 13:00:36 --> Security Class Initialized
DEBUG - 2019-09-01 13:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:00:36 --> Input Class Initialized
INFO - 2019-09-01 13:00:36 --> Language Class Initialized
INFO - 2019-09-01 13:00:36 --> Loader Class Initialized
INFO - 2019-09-01 13:00:36 --> Helper loaded: url_helper
INFO - 2019-09-01 13:00:36 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:00:51 --> Controller Class Initialized
INFO - 2019-09-01 13:00:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 13:00:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 13:00:51 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 13:00:51 --> Final output sent to browser
DEBUG - 2019-09-01 13:00:51 --> Total execution time: 15.1844
INFO - 2019-09-01 13:00:53 --> Config Class Initialized
INFO - 2019-09-01 13:00:53 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:00:53 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:00:53 --> Utf8 Class Initialized
INFO - 2019-09-01 13:00:53 --> URI Class Initialized
INFO - 2019-09-01 13:00:53 --> Router Class Initialized
INFO - 2019-09-01 13:00:53 --> Output Class Initialized
INFO - 2019-09-01 13:00:53 --> Security Class Initialized
DEBUG - 2019-09-01 13:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:00:53 --> Input Class Initialized
INFO - 2019-09-01 13:00:53 --> Language Class Initialized
INFO - 2019-09-01 13:00:53 --> Loader Class Initialized
INFO - 2019-09-01 13:00:53 --> Helper loaded: url_helper
INFO - 2019-09-01 13:00:53 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:00:59 --> Controller Class Initialized
DEBUG - 2019-09-01 13:00:59 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 13:00:59 --> Helper loaded: inflector_helper
INFO - 2019-09-01 13:00:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 13:00:59 --> Model "Template_model" initialized
INFO - 2019-09-01 13:00:59 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 13:01:10 --> Config Class Initialized
INFO - 2019-09-01 13:01:10 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:01:10 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:01:10 --> Utf8 Class Initialized
INFO - 2019-09-01 13:01:10 --> URI Class Initialized
INFO - 2019-09-01 13:01:10 --> Router Class Initialized
INFO - 2019-09-01 13:01:10 --> Output Class Initialized
INFO - 2019-09-01 13:01:10 --> Security Class Initialized
DEBUG - 2019-09-01 13:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:01:10 --> Input Class Initialized
INFO - 2019-09-01 13:01:10 --> Language Class Initialized
INFO - 2019-09-01 13:01:10 --> Loader Class Initialized
INFO - 2019-09-01 13:01:10 --> Helper loaded: url_helper
INFO - 2019-09-01 13:01:10 --> Database Driver Class Initialized
INFO - 2019-09-01 13:01:10 --> Final output sent to browser
DEBUG - 2019-09-01 13:01:10 --> Total execution time: 17.7735
DEBUG - 2019-09-01 13:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:01:16 --> Controller Class Initialized
INFO - 2019-09-01 13:01:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 13:01:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-09-01 13:01:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 13:01:16 --> Final output sent to browser
DEBUG - 2019-09-01 13:01:16 --> Total execution time: 6.1361
INFO - 2019-09-01 13:02:08 --> Config Class Initialized
INFO - 2019-09-01 13:02:08 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:02:08 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:02:08 --> Utf8 Class Initialized
INFO - 2019-09-01 13:02:08 --> URI Class Initialized
INFO - 2019-09-01 13:02:08 --> Router Class Initialized
INFO - 2019-09-01 13:02:08 --> Output Class Initialized
INFO - 2019-09-01 13:02:08 --> Security Class Initialized
DEBUG - 2019-09-01 13:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:02:08 --> Input Class Initialized
INFO - 2019-09-01 13:02:08 --> Language Class Initialized
INFO - 2019-09-01 13:02:08 --> Loader Class Initialized
INFO - 2019-09-01 13:02:08 --> Helper loaded: url_helper
INFO - 2019-09-01 13:02:08 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:02:14 --> Controller Class Initialized
INFO - 2019-09-01 13:02:14 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 13:02:14 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 13:02:14 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 13:02:14 --> Final output sent to browser
DEBUG - 2019-09-01 13:02:14 --> Total execution time: 6.1373
INFO - 2019-09-01 13:02:15 --> Config Class Initialized
INFO - 2019-09-01 13:02:15 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:02:15 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:02:15 --> Utf8 Class Initialized
INFO - 2019-09-01 13:02:15 --> URI Class Initialized
INFO - 2019-09-01 13:02:15 --> Router Class Initialized
INFO - 2019-09-01 13:02:15 --> Output Class Initialized
INFO - 2019-09-01 13:02:15 --> Security Class Initialized
DEBUG - 2019-09-01 13:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:02:15 --> Input Class Initialized
INFO - 2019-09-01 13:02:15 --> Language Class Initialized
INFO - 2019-09-01 13:02:15 --> Loader Class Initialized
INFO - 2019-09-01 13:02:15 --> Helper loaded: url_helper
INFO - 2019-09-01 13:02:15 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:02:16 --> Controller Class Initialized
DEBUG - 2019-09-01 13:02:16 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 13:02:16 --> Helper loaded: inflector_helper
INFO - 2019-09-01 13:02:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 13:02:16 --> Model "Template_model" initialized
INFO - 2019-09-01 13:02:16 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 13:02:22 --> Final output sent to browser
DEBUG - 2019-09-01 13:02:22 --> Total execution time: 7.2107
INFO - 2019-09-01 13:05:13 --> Config Class Initialized
INFO - 2019-09-01 13:05:13 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:05:13 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:05:13 --> Utf8 Class Initialized
INFO - 2019-09-01 13:05:13 --> URI Class Initialized
INFO - 2019-09-01 13:05:13 --> Router Class Initialized
INFO - 2019-09-01 13:05:13 --> Output Class Initialized
INFO - 2019-09-01 13:05:13 --> Security Class Initialized
DEBUG - 2019-09-01 13:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:05:13 --> Input Class Initialized
INFO - 2019-09-01 13:05:13 --> Language Class Initialized
INFO - 2019-09-01 13:05:13 --> Loader Class Initialized
INFO - 2019-09-01 13:05:13 --> Helper loaded: url_helper
INFO - 2019-09-01 13:05:13 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:05:14 --> Controller Class Initialized
INFO - 2019-09-01 13:05:14 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 13:05:14 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step3.php
INFO - 2019-09-01 13:05:14 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 13:05:14 --> Final output sent to browser
DEBUG - 2019-09-01 13:05:14 --> Total execution time: 1.1717
INFO - 2019-09-01 13:05:14 --> Config Class Initialized
INFO - 2019-09-01 13:05:14 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:05:14 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:05:14 --> Utf8 Class Initialized
INFO - 2019-09-01 13:05:14 --> URI Class Initialized
INFO - 2019-09-01 13:05:14 --> Router Class Initialized
INFO - 2019-09-01 13:05:14 --> Output Class Initialized
INFO - 2019-09-01 13:05:14 --> Security Class Initialized
DEBUG - 2019-09-01 13:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:05:14 --> Input Class Initialized
INFO - 2019-09-01 13:05:14 --> Language Class Initialized
INFO - 2019-09-01 13:05:14 --> Loader Class Initialized
INFO - 2019-09-01 13:05:14 --> Helper loaded: url_helper
INFO - 2019-09-01 13:05:14 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:05:16 --> Controller Class Initialized
INFO - 2019-09-01 13:05:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 13:05:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step3.php
INFO - 2019-09-01 13:05:16 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 13:05:16 --> Final output sent to browser
DEBUG - 2019-09-01 13:05:16 --> Total execution time: 1.2613
INFO - 2019-09-01 13:05:18 --> Config Class Initialized
INFO - 2019-09-01 13:05:18 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:05:18 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:05:18 --> Utf8 Class Initialized
INFO - 2019-09-01 13:05:18 --> URI Class Initialized
INFO - 2019-09-01 13:05:18 --> Router Class Initialized
INFO - 2019-09-01 13:05:18 --> Output Class Initialized
INFO - 2019-09-01 13:05:18 --> Security Class Initialized
DEBUG - 2019-09-01 13:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:05:18 --> Input Class Initialized
INFO - 2019-09-01 13:05:18 --> Language Class Initialized
INFO - 2019-09-01 13:05:18 --> Loader Class Initialized
INFO - 2019-09-01 13:05:18 --> Helper loaded: url_helper
INFO - 2019-09-01 13:05:18 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:05:19 --> Controller Class Initialized
INFO - 2019-09-01 13:05:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 13:05:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 13:05:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 13:05:19 --> Final output sent to browser
DEBUG - 2019-09-01 13:05:19 --> Total execution time: 1.2523
INFO - 2019-09-01 13:05:19 --> Config Class Initialized
INFO - 2019-09-01 13:05:19 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:05:19 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:05:19 --> Utf8 Class Initialized
INFO - 2019-09-01 13:05:19 --> URI Class Initialized
INFO - 2019-09-01 13:05:19 --> Router Class Initialized
INFO - 2019-09-01 13:05:19 --> Output Class Initialized
INFO - 2019-09-01 13:05:19 --> Security Class Initialized
DEBUG - 2019-09-01 13:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:05:19 --> Input Class Initialized
INFO - 2019-09-01 13:05:19 --> Language Class Initialized
INFO - 2019-09-01 13:05:19 --> Loader Class Initialized
INFO - 2019-09-01 13:05:19 --> Helper loaded: url_helper
INFO - 2019-09-01 13:05:19 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:05:20 --> Controller Class Initialized
DEBUG - 2019-09-01 13:05:20 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 13:05:20 --> Helper loaded: inflector_helper
INFO - 2019-09-01 13:05:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 13:05:20 --> Model "Template_model" initialized
INFO - 2019-09-01 13:05:20 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 13:05:21 --> Final output sent to browser
DEBUG - 2019-09-01 13:05:21 --> Total execution time: 1.7514
INFO - 2019-09-01 13:08:56 --> Config Class Initialized
INFO - 2019-09-01 13:08:56 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:08:56 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:08:56 --> Utf8 Class Initialized
INFO - 2019-09-01 13:08:56 --> URI Class Initialized
INFO - 2019-09-01 13:08:56 --> Router Class Initialized
INFO - 2019-09-01 13:08:56 --> Output Class Initialized
INFO - 2019-09-01 13:08:56 --> Security Class Initialized
DEBUG - 2019-09-01 13:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:08:56 --> Input Class Initialized
INFO - 2019-09-01 13:08:56 --> Language Class Initialized
INFO - 2019-09-01 13:08:56 --> Loader Class Initialized
INFO - 2019-09-01 13:08:56 --> Helper loaded: url_helper
INFO - 2019-09-01 13:08:56 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:09:05 --> Controller Class Initialized
INFO - 2019-09-01 13:09:05 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 13:09:05 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 13:09:05 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 13:09:05 --> Final output sent to browser
DEBUG - 2019-09-01 13:09:05 --> Total execution time: 9.1379
INFO - 2019-09-01 13:09:06 --> Config Class Initialized
INFO - 2019-09-01 13:09:06 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:09:06 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:09:06 --> Utf8 Class Initialized
INFO - 2019-09-01 13:09:06 --> URI Class Initialized
INFO - 2019-09-01 13:09:06 --> Router Class Initialized
INFO - 2019-09-01 13:09:06 --> Output Class Initialized
INFO - 2019-09-01 13:09:06 --> Security Class Initialized
DEBUG - 2019-09-01 13:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:09:06 --> Input Class Initialized
INFO - 2019-09-01 13:09:06 --> Language Class Initialized
INFO - 2019-09-01 13:09:06 --> Loader Class Initialized
INFO - 2019-09-01 13:09:06 --> Helper loaded: url_helper
INFO - 2019-09-01 13:09:06 --> Database Driver Class Initialized
INFO - 2019-09-01 13:09:15 --> Config Class Initialized
INFO - 2019-09-01 13:09:15 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:09:15 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:09:15 --> Utf8 Class Initialized
INFO - 2019-09-01 13:09:15 --> URI Class Initialized
INFO - 2019-09-01 13:09:15 --> Router Class Initialized
INFO - 2019-09-01 13:09:15 --> Output Class Initialized
INFO - 2019-09-01 13:09:15 --> Security Class Initialized
DEBUG - 2019-09-01 13:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:09:15 --> Input Class Initialized
INFO - 2019-09-01 13:09:15 --> Language Class Initialized
INFO - 2019-09-01 13:09:15 --> Loader Class Initialized
INFO - 2019-09-01 13:09:15 --> Helper loaded: url_helper
INFO - 2019-09-01 13:09:15 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:09:15 --> Controller Class Initialized
DEBUG - 2019-09-01 13:09:15 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 13:09:15 --> Helper loaded: inflector_helper
INFO - 2019-09-01 13:09:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 13:09:15 --> Model "Template_model" initialized
INFO - 2019-09-01 13:09:15 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 13:09:17 --> Final output sent to browser
DEBUG - 2019-09-01 13:09:17 --> Total execution time: 10.5905
DEBUG - 2019-09-01 13:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:09:24 --> Controller Class Initialized
INFO - 2019-09-01 13:09:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 13:09:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-09-01 13:09:24 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 13:09:24 --> Final output sent to browser
DEBUG - 2019-09-01 13:09:24 --> Total execution time: 9.1803
INFO - 2019-09-01 13:09:29 --> Config Class Initialized
INFO - 2019-09-01 13:09:29 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:09:29 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:09:29 --> Utf8 Class Initialized
INFO - 2019-09-01 13:09:29 --> URI Class Initialized
INFO - 2019-09-01 13:09:29 --> Router Class Initialized
INFO - 2019-09-01 13:09:29 --> Output Class Initialized
INFO - 2019-09-01 13:09:29 --> Security Class Initialized
DEBUG - 2019-09-01 13:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:09:29 --> Input Class Initialized
INFO - 2019-09-01 13:09:29 --> Language Class Initialized
INFO - 2019-09-01 13:09:29 --> Loader Class Initialized
INFO - 2019-09-01 13:09:29 --> Helper loaded: url_helper
INFO - 2019-09-01 13:09:29 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:09:30 --> Controller Class Initialized
INFO - 2019-09-01 13:09:30 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 13:09:30 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 13:09:30 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 13:09:30 --> Final output sent to browser
DEBUG - 2019-09-01 13:09:30 --> Total execution time: 1.1353
INFO - 2019-09-01 13:09:30 --> Config Class Initialized
INFO - 2019-09-01 13:09:30 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:09:30 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:09:30 --> Utf8 Class Initialized
INFO - 2019-09-01 13:09:30 --> URI Class Initialized
INFO - 2019-09-01 13:09:30 --> Router Class Initialized
INFO - 2019-09-01 13:09:30 --> Output Class Initialized
INFO - 2019-09-01 13:09:30 --> Security Class Initialized
DEBUG - 2019-09-01 13:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:09:30 --> Input Class Initialized
INFO - 2019-09-01 13:09:30 --> Language Class Initialized
INFO - 2019-09-01 13:09:30 --> Loader Class Initialized
INFO - 2019-09-01 13:09:30 --> Helper loaded: url_helper
INFO - 2019-09-01 13:09:30 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:09:31 --> Controller Class Initialized
DEBUG - 2019-09-01 13:09:31 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 13:09:31 --> Helper loaded: inflector_helper
INFO - 2019-09-01 13:09:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 13:09:31 --> Model "Template_model" initialized
INFO - 2019-09-01 13:09:31 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 13:09:33 --> Final output sent to browser
DEBUG - 2019-09-01 13:09:33 --> Total execution time: 2.7448
INFO - 2019-09-01 13:09:54 --> Config Class Initialized
INFO - 2019-09-01 13:09:54 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:09:54 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:09:54 --> Utf8 Class Initialized
INFO - 2019-09-01 13:09:54 --> URI Class Initialized
INFO - 2019-09-01 13:09:54 --> Router Class Initialized
INFO - 2019-09-01 13:09:54 --> Output Class Initialized
INFO - 2019-09-01 13:09:54 --> Security Class Initialized
DEBUG - 2019-09-01 13:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:09:54 --> Input Class Initialized
INFO - 2019-09-01 13:09:54 --> Language Class Initialized
INFO - 2019-09-01 13:09:54 --> Loader Class Initialized
INFO - 2019-09-01 13:09:54 --> Helper loaded: url_helper
INFO - 2019-09-01 13:09:54 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:09:55 --> Controller Class Initialized
INFO - 2019-09-01 13:09:55 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 13:09:55 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step3.php
INFO - 2019-09-01 13:09:55 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 13:09:55 --> Final output sent to browser
DEBUG - 2019-09-01 13:09:55 --> Total execution time: 1.1934
INFO - 2019-09-01 13:10:01 --> Config Class Initialized
INFO - 2019-09-01 13:10:01 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:10:01 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:10:01 --> Utf8 Class Initialized
INFO - 2019-09-01 13:10:01 --> URI Class Initialized
INFO - 2019-09-01 13:10:01 --> Router Class Initialized
INFO - 2019-09-01 13:10:01 --> Output Class Initialized
INFO - 2019-09-01 13:10:01 --> Security Class Initialized
DEBUG - 2019-09-01 13:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:10:01 --> Input Class Initialized
INFO - 2019-09-01 13:10:01 --> Language Class Initialized
INFO - 2019-09-01 13:10:01 --> Loader Class Initialized
INFO - 2019-09-01 13:10:01 --> Helper loaded: url_helper
INFO - 2019-09-01 13:10:01 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:10:07 --> Controller Class Initialized
INFO - 2019-09-01 13:10:07 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 13:10:07 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 13:10:07 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 13:10:07 --> Final output sent to browser
DEBUG - 2019-09-01 13:10:07 --> Total execution time: 6.1927
INFO - 2019-09-01 13:10:08 --> Config Class Initialized
INFO - 2019-09-01 13:10:08 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:10:08 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:10:08 --> Utf8 Class Initialized
INFO - 2019-09-01 13:10:08 --> URI Class Initialized
INFO - 2019-09-01 13:10:08 --> Router Class Initialized
INFO - 2019-09-01 13:10:08 --> Output Class Initialized
INFO - 2019-09-01 13:10:08 --> Security Class Initialized
DEBUG - 2019-09-01 13:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:10:08 --> Input Class Initialized
INFO - 2019-09-01 13:10:08 --> Language Class Initialized
INFO - 2019-09-01 13:10:08 --> Loader Class Initialized
INFO - 2019-09-01 13:10:08 --> Helper loaded: url_helper
INFO - 2019-09-01 13:10:08 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:10:38 --> Controller Class Initialized
DEBUG - 2019-09-01 13:10:38 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 13:10:38 --> Helper loaded: inflector_helper
INFO - 2019-09-01 13:10:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 13:10:38 --> Model "Template_model" initialized
INFO - 2019-09-01 13:10:38 --> Model "Khang_sinh_model" initialized
ERROR - 2019-09-01 13:10:44 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 307
INFO - 2019-09-01 13:11:08 --> Config Class Initialized
INFO - 2019-09-01 13:11:08 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:11:08 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:11:08 --> Utf8 Class Initialized
INFO - 2019-09-01 13:11:08 --> URI Class Initialized
INFO - 2019-09-01 13:11:08 --> Router Class Initialized
INFO - 2019-09-01 13:11:08 --> Output Class Initialized
INFO - 2019-09-01 13:11:08 --> Security Class Initialized
DEBUG - 2019-09-01 13:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:11:08 --> Input Class Initialized
INFO - 2019-09-01 13:11:08 --> Language Class Initialized
INFO - 2019-09-01 13:11:08 --> Loader Class Initialized
INFO - 2019-09-01 13:11:08 --> Helper loaded: url_helper
INFO - 2019-09-01 13:11:08 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:11:09 --> Controller Class Initialized
INFO - 2019-09-01 13:11:09 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 13:11:09 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step1.php
INFO - 2019-09-01 13:11:09 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 13:11:09 --> Final output sent to browser
DEBUG - 2019-09-01 13:11:09 --> Total execution time: 1.1716
INFO - 2019-09-01 13:11:23 --> Config Class Initialized
INFO - 2019-09-01 13:11:23 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:11:23 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:11:23 --> Utf8 Class Initialized
INFO - 2019-09-01 13:11:23 --> URI Class Initialized
INFO - 2019-09-01 13:11:23 --> Router Class Initialized
INFO - 2019-09-01 13:11:23 --> Output Class Initialized
INFO - 2019-09-01 13:11:23 --> Security Class Initialized
DEBUG - 2019-09-01 13:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:11:23 --> Input Class Initialized
INFO - 2019-09-01 13:11:23 --> Language Class Initialized
INFO - 2019-09-01 13:11:23 --> Loader Class Initialized
INFO - 2019-09-01 13:11:23 --> Helper loaded: url_helper
INFO - 2019-09-01 13:11:23 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:11:39 --> Controller Class Initialized
INFO - 2019-09-01 13:11:39 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 13:11:39 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 13:11:39 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 13:11:39 --> Final output sent to browser
DEBUG - 2019-09-01 13:11:39 --> Total execution time: 15.4557
INFO - 2019-09-01 13:11:40 --> Config Class Initialized
INFO - 2019-09-01 13:11:40 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:11:40 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:11:40 --> Utf8 Class Initialized
INFO - 2019-09-01 13:11:40 --> URI Class Initialized
INFO - 2019-09-01 13:11:40 --> Router Class Initialized
INFO - 2019-09-01 13:11:40 --> Output Class Initialized
INFO - 2019-09-01 13:11:40 --> Security Class Initialized
DEBUG - 2019-09-01 13:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:11:40 --> Input Class Initialized
INFO - 2019-09-01 13:11:40 --> Language Class Initialized
INFO - 2019-09-01 13:11:40 --> Loader Class Initialized
INFO - 2019-09-01 13:11:40 --> Helper loaded: url_helper
INFO - 2019-09-01 13:11:40 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:11:41 --> Controller Class Initialized
DEBUG - 2019-09-01 13:11:41 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 13:11:41 --> Helper loaded: inflector_helper
INFO - 2019-09-01 13:11:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 13:11:41 --> Model "Template_model" initialized
INFO - 2019-09-01 13:11:41 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 13:11:47 --> Final output sent to browser
DEBUG - 2019-09-01 13:11:47 --> Total execution time: 7.0802
INFO - 2019-09-01 13:13:00 --> Config Class Initialized
INFO - 2019-09-01 13:13:00 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:13:00 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:13:00 --> Utf8 Class Initialized
INFO - 2019-09-01 13:13:00 --> URI Class Initialized
INFO - 2019-09-01 13:13:00 --> Router Class Initialized
INFO - 2019-09-01 13:13:00 --> Output Class Initialized
INFO - 2019-09-01 13:13:00 --> Security Class Initialized
DEBUG - 2019-09-01 13:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:13:00 --> Input Class Initialized
INFO - 2019-09-01 13:13:00 --> Language Class Initialized
INFO - 2019-09-01 13:13:00 --> Loader Class Initialized
INFO - 2019-09-01 13:13:00 --> Helper loaded: url_helper
INFO - 2019-09-01 13:13:00 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:13:01 --> Controller Class Initialized
INFO - 2019-09-01 13:13:01 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 13:13:01 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 13:13:01 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 13:13:01 --> Final output sent to browser
DEBUG - 2019-09-01 13:13:01 --> Total execution time: 1.1322
INFO - 2019-09-01 13:13:02 --> Config Class Initialized
INFO - 2019-09-01 13:13:02 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:13:02 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:13:02 --> Utf8 Class Initialized
INFO - 2019-09-01 13:13:02 --> URI Class Initialized
INFO - 2019-09-01 13:13:02 --> Router Class Initialized
INFO - 2019-09-01 13:13:02 --> Output Class Initialized
INFO - 2019-09-01 13:13:02 --> Security Class Initialized
DEBUG - 2019-09-01 13:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:13:02 --> Input Class Initialized
INFO - 2019-09-01 13:13:02 --> Language Class Initialized
INFO - 2019-09-01 13:13:02 --> Loader Class Initialized
INFO - 2019-09-01 13:13:02 --> Helper loaded: url_helper
INFO - 2019-09-01 13:13:02 --> Database Driver Class Initialized
INFO - 2019-09-01 13:13:06 --> Config Class Initialized
INFO - 2019-09-01 13:13:06 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:13:06 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:13:06 --> Utf8 Class Initialized
INFO - 2019-09-01 13:13:06 --> URI Class Initialized
INFO - 2019-09-01 13:13:06 --> Router Class Initialized
INFO - 2019-09-01 13:13:06 --> Output Class Initialized
INFO - 2019-09-01 13:13:06 --> Security Class Initialized
DEBUG - 2019-09-01 13:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:13:06 --> Input Class Initialized
INFO - 2019-09-01 13:13:06 --> Language Class Initialized
INFO - 2019-09-01 13:13:06 --> Loader Class Initialized
INFO - 2019-09-01 13:13:06 --> Helper loaded: url_helper
INFO - 2019-09-01 13:13:06 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:13:22 --> Controller Class Initialized
DEBUG - 2019-09-01 13:13:22 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 13:13:22 --> Helper loaded: inflector_helper
INFO - 2019-09-01 13:13:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 13:13:22 --> Model "Template_model" initialized
INFO - 2019-09-01 13:13:22 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 13:13:26 --> Final output sent to browser
DEBUG - 2019-09-01 13:13:26 --> Total execution time: 24.6864
DEBUG - 2019-09-01 13:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:13:29 --> Controller Class Initialized
INFO - 2019-09-01 13:13:29 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 13:13:29 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step2.php
INFO - 2019-09-01 13:13:29 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 13:13:29 --> Final output sent to browser
DEBUG - 2019-09-01 13:13:29 --> Total execution time: 23.1737
INFO - 2019-09-01 13:13:31 --> Config Class Initialized
INFO - 2019-09-01 13:13:31 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:13:31 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:13:31 --> Utf8 Class Initialized
INFO - 2019-09-01 13:13:31 --> URI Class Initialized
INFO - 2019-09-01 13:13:31 --> Router Class Initialized
INFO - 2019-09-01 13:13:31 --> Output Class Initialized
INFO - 2019-09-01 13:13:31 --> Security Class Initialized
DEBUG - 2019-09-01 13:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:13:31 --> Input Class Initialized
INFO - 2019-09-01 13:13:31 --> Language Class Initialized
INFO - 2019-09-01 13:13:31 --> Loader Class Initialized
INFO - 2019-09-01 13:13:31 --> Helper loaded: url_helper
INFO - 2019-09-01 13:13:31 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:13:32 --> Controller Class Initialized
DEBUG - 2019-09-01 13:13:32 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-09-01 13:13:32 --> Helper loaded: inflector_helper
INFO - 2019-09-01 13:13:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-09-01 13:13:32 --> Model "Template_model" initialized
INFO - 2019-09-01 13:13:32 --> Model "Khang_sinh_model" initialized
INFO - 2019-09-01 13:13:32 --> Final output sent to browser
DEBUG - 2019-09-01 13:13:32 --> Total execution time: 1.4271
INFO - 2019-09-01 13:13:40 --> Config Class Initialized
INFO - 2019-09-01 13:13:40 --> Hooks Class Initialized
DEBUG - 2019-09-01 13:13:40 --> UTF-8 Support Enabled
INFO - 2019-09-01 13:13:40 --> Utf8 Class Initialized
INFO - 2019-09-01 13:13:40 --> URI Class Initialized
INFO - 2019-09-01 13:13:40 --> Router Class Initialized
INFO - 2019-09-01 13:13:40 --> Output Class Initialized
INFO - 2019-09-01 13:13:40 --> Security Class Initialized
DEBUG - 2019-09-01 13:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-01 13:13:40 --> Input Class Initialized
INFO - 2019-09-01 13:13:40 --> Language Class Initialized
INFO - 2019-09-01 13:13:40 --> Loader Class Initialized
INFO - 2019-09-01 13:13:40 --> Helper loaded: url_helper
INFO - 2019-09-01 13:13:40 --> Database Driver Class Initialized
DEBUG - 2019-09-01 13:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-01 13:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-01 13:13:46 --> Controller Class Initialized
INFO - 2019-09-01 13:13:46 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-09-01 13:13:46 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step3.php
INFO - 2019-09-01 13:13:46 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-09-01 13:13:46 --> Final output sent to browser
DEBUG - 2019-09-01 13:13:46 --> Total execution time: 6.1526
