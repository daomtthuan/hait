<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-08-29 21:52:56 --> Config Class Initialized
INFO - 2019-08-29 21:52:56 --> Hooks Class Initialized
DEBUG - 2019-08-29 21:52:56 --> UTF-8 Support Enabled
INFO - 2019-08-29 21:52:56 --> Utf8 Class Initialized
INFO - 2019-08-29 21:52:56 --> URI Class Initialized
INFO - 2019-08-29 21:52:56 --> Router Class Initialized
INFO - 2019-08-29 21:52:56 --> Output Class Initialized
INFO - 2019-08-29 21:52:56 --> Security Class Initialized
DEBUG - 2019-08-29 21:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 21:52:56 --> Input Class Initialized
INFO - 2019-08-29 21:52:56 --> Language Class Initialized
INFO - 2019-08-29 21:52:56 --> Loader Class Initialized
INFO - 2019-08-29 21:52:56 --> Helper loaded: url_helper
INFO - 2019-08-29 21:52:56 --> Database Driver Class Initialized
ERROR - 2019-08-29 21:53:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-08-29 21:53:00 --> Unable to connect to the database
DEBUG - 2019-08-29 21:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 21:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 21:53:00 --> Controller Class Initialized
INFO - 2019-08-29 21:53:00 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-29 21:53:00 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step3.php
INFO - 2019-08-29 21:53:00 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-29 21:53:00 --> Final output sent to browser
DEBUG - 2019-08-29 21:53:00 --> Total execution time: 4.1210
INFO - 2019-08-29 21:53:09 --> Config Class Initialized
INFO - 2019-08-29 21:53:09 --> Hooks Class Initialized
DEBUG - 2019-08-29 21:53:09 --> UTF-8 Support Enabled
INFO - 2019-08-29 21:53:09 --> Utf8 Class Initialized
INFO - 2019-08-29 21:53:09 --> URI Class Initialized
INFO - 2019-08-29 21:53:09 --> Router Class Initialized
INFO - 2019-08-29 21:53:09 --> Output Class Initialized
INFO - 2019-08-29 21:53:09 --> Security Class Initialized
DEBUG - 2019-08-29 21:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 21:53:09 --> Input Class Initialized
INFO - 2019-08-29 21:53:09 --> Language Class Initialized
INFO - 2019-08-29 21:53:09 --> Loader Class Initialized
INFO - 2019-08-29 21:53:09 --> Helper loaded: url_helper
INFO - 2019-08-29 21:53:09 --> Database Driver Class Initialized
ERROR - 2019-08-29 21:53:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-08-29 21:53:13 --> Unable to connect to the database
DEBUG - 2019-08-29 21:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 21:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 21:53:13 --> Controller Class Initialized
INFO - 2019-08-29 21:53:13 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-29 21:53:13 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step4.php
INFO - 2019-08-29 21:53:13 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-29 21:53:13 --> Final output sent to browser
DEBUG - 2019-08-29 21:53:13 --> Total execution time: 4.0317
INFO - 2019-08-29 21:53:19 --> Config Class Initialized
INFO - 2019-08-29 21:53:19 --> Hooks Class Initialized
DEBUG - 2019-08-29 21:53:19 --> UTF-8 Support Enabled
INFO - 2019-08-29 21:53:19 --> Utf8 Class Initialized
INFO - 2019-08-29 21:53:19 --> URI Class Initialized
INFO - 2019-08-29 21:53:19 --> Router Class Initialized
INFO - 2019-08-29 21:53:19 --> Output Class Initialized
INFO - 2019-08-29 21:53:19 --> Security Class Initialized
DEBUG - 2019-08-29 21:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 21:53:19 --> Input Class Initialized
INFO - 2019-08-29 21:53:19 --> Language Class Initialized
INFO - 2019-08-29 21:53:19 --> Loader Class Initialized
INFO - 2019-08-29 21:53:19 --> Helper loaded: url_helper
INFO - 2019-08-29 21:53:19 --> Database Driver Class Initialized
ERROR - 2019-08-29 21:53:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-08-29 21:53:23 --> Unable to connect to the database
DEBUG - 2019-08-29 21:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 21:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 21:53:23 --> Controller Class Initialized
INFO - 2019-08-29 21:53:23 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-29 21:53:23 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step5.php
INFO - 2019-08-29 21:53:23 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-29 21:53:23 --> Final output sent to browser
DEBUG - 2019-08-29 21:53:23 --> Total execution time: 4.0355
INFO - 2019-08-29 21:53:34 --> Config Class Initialized
INFO - 2019-08-29 21:53:34 --> Hooks Class Initialized
DEBUG - 2019-08-29 21:53:34 --> UTF-8 Support Enabled
INFO - 2019-08-29 21:53:34 --> Utf8 Class Initialized
INFO - 2019-08-29 21:53:34 --> URI Class Initialized
INFO - 2019-08-29 21:53:34 --> Router Class Initialized
INFO - 2019-08-29 21:53:34 --> Output Class Initialized
INFO - 2019-08-29 21:53:34 --> Security Class Initialized
DEBUG - 2019-08-29 21:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 21:53:34 --> Input Class Initialized
INFO - 2019-08-29 21:53:34 --> Language Class Initialized
INFO - 2019-08-29 21:53:34 --> Loader Class Initialized
INFO - 2019-08-29 21:53:34 --> Helper loaded: url_helper
INFO - 2019-08-29 21:53:34 --> Database Driver Class Initialized
ERROR - 2019-08-29 21:53:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-08-29 21:53:38 --> Unable to connect to the database
DEBUG - 2019-08-29 21:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 21:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 21:53:38 --> Controller Class Initialized
INFO - 2019-08-29 21:53:38 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-29 21:53:38 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step6.php
INFO - 2019-08-29 21:53:38 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-29 21:53:38 --> Final output sent to browser
DEBUG - 2019-08-29 21:53:38 --> Total execution time: 4.0468
INFO - 2019-08-29 21:53:43 --> Config Class Initialized
INFO - 2019-08-29 21:53:43 --> Hooks Class Initialized
DEBUG - 2019-08-29 21:53:43 --> UTF-8 Support Enabled
INFO - 2019-08-29 21:53:43 --> Utf8 Class Initialized
INFO - 2019-08-29 21:53:43 --> URI Class Initialized
INFO - 2019-08-29 21:53:43 --> Router Class Initialized
INFO - 2019-08-29 21:53:43 --> Output Class Initialized
INFO - 2019-08-29 21:53:43 --> Security Class Initialized
DEBUG - 2019-08-29 21:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 21:53:43 --> Input Class Initialized
INFO - 2019-08-29 21:53:43 --> Language Class Initialized
INFO - 2019-08-29 21:53:43 --> Loader Class Initialized
INFO - 2019-08-29 21:53:43 --> Helper loaded: url_helper
INFO - 2019-08-29 21:53:43 --> Database Driver Class Initialized
ERROR - 2019-08-29 21:53:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-08-29 21:53:47 --> Unable to connect to the database
DEBUG - 2019-08-29 21:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 21:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 21:53:47 --> Controller Class Initialized
INFO - 2019-08-29 21:53:47 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-29 21:53:47 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_2.php
INFO - 2019-08-29 21:53:47 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-29 21:53:47 --> Final output sent to browser
DEBUG - 2019-08-29 21:53:47 --> Total execution time: 4.0429
INFO - 2019-08-29 21:53:47 --> Config Class Initialized
INFO - 2019-08-29 21:53:47 --> Hooks Class Initialized
DEBUG - 2019-08-29 21:53:47 --> UTF-8 Support Enabled
INFO - 2019-08-29 21:53:47 --> Utf8 Class Initialized
INFO - 2019-08-29 21:53:47 --> URI Class Initialized
INFO - 2019-08-29 21:53:47 --> Router Class Initialized
INFO - 2019-08-29 21:53:47 --> Output Class Initialized
INFO - 2019-08-29 21:53:47 --> Security Class Initialized
DEBUG - 2019-08-29 21:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 21:53:47 --> Input Class Initialized
INFO - 2019-08-29 21:53:47 --> Language Class Initialized
INFO - 2019-08-29 21:53:48 --> Loader Class Initialized
INFO - 2019-08-29 21:53:48 --> Helper loaded: url_helper
INFO - 2019-08-29 21:53:48 --> Database Driver Class Initialized
ERROR - 2019-08-29 21:53:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-08-29 21:53:52 --> Unable to connect to the database
DEBUG - 2019-08-29 21:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 21:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 21:53:52 --> Controller Class Initialized
DEBUG - 2019-08-29 21:53:52 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-29 21:53:52 --> Helper loaded: inflector_helper
INFO - 2019-08-29 21:53:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-29 21:53:52 --> Model "Template_model" initialized
INFO - 2019-08-29 21:53:52 --> Model "Khang_sinh_model" initialized
ERROR - 2019-08-29 21:53:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-08-29 21:53:56 --> Unable to connect to the database
ERROR - 2019-08-29 21:53:56 --> Query error: No connection could be made because the target machine actively refused it.
 - Invalid query: SELECT `ma_khang_sinh`, `ten_khang_sinh`
FROM `khang_sinh`
ERROR - 2019-08-29 21:53:56 --> Severity: error --> Exception: Call to a member function result_array() on bool D:\Programs\Xampp\htdocs\hait\application\models\Khang_sinh_model.php 16
INFO - 2019-08-29 21:54:15 --> Config Class Initialized
INFO - 2019-08-29 21:54:15 --> Hooks Class Initialized
DEBUG - 2019-08-29 21:54:15 --> UTF-8 Support Enabled
INFO - 2019-08-29 21:54:15 --> Utf8 Class Initialized
INFO - 2019-08-29 21:54:15 --> URI Class Initialized
INFO - 2019-08-29 21:54:15 --> Router Class Initialized
INFO - 2019-08-29 21:54:15 --> Output Class Initialized
INFO - 2019-08-29 21:54:15 --> Security Class Initialized
DEBUG - 2019-08-29 21:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 21:54:15 --> Input Class Initialized
INFO - 2019-08-29 21:54:15 --> Language Class Initialized
INFO - 2019-08-29 21:54:15 --> Loader Class Initialized
INFO - 2019-08-29 21:54:15 --> Helper loaded: url_helper
INFO - 2019-08-29 21:54:15 --> Database Driver Class Initialized
ERROR - 2019-08-29 21:54:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-08-29 21:54:19 --> Unable to connect to the database
DEBUG - 2019-08-29 21:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 21:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 21:54:19 --> Controller Class Initialized
INFO - 2019-08-29 21:54:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\user/sidebar.php
INFO - 2019-08-29 21:54:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\tools/form/step7_2.php
INFO - 2019-08-29 21:54:19 --> File loaded: D:\Programs\Xampp\htdocs\hait\application\views\general/layout.php
INFO - 2019-08-29 21:54:19 --> Final output sent to browser
DEBUG - 2019-08-29 21:54:19 --> Total execution time: 4.0449
INFO - 2019-08-29 21:54:20 --> Config Class Initialized
INFO - 2019-08-29 21:54:20 --> Hooks Class Initialized
DEBUG - 2019-08-29 21:54:20 --> UTF-8 Support Enabled
INFO - 2019-08-29 21:54:20 --> Utf8 Class Initialized
INFO - 2019-08-29 21:54:20 --> URI Class Initialized
INFO - 2019-08-29 21:54:20 --> Router Class Initialized
INFO - 2019-08-29 21:54:20 --> Output Class Initialized
INFO - 2019-08-29 21:54:20 --> Security Class Initialized
DEBUG - 2019-08-29 21:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 21:54:20 --> Input Class Initialized
INFO - 2019-08-29 21:54:20 --> Language Class Initialized
INFO - 2019-08-29 21:54:20 --> Loader Class Initialized
INFO - 2019-08-29 21:54:20 --> Helper loaded: url_helper
INFO - 2019-08-29 21:54:20 --> Database Driver Class Initialized
ERROR - 2019-08-29 21:54:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-08-29 21:54:24 --> Unable to connect to the database
DEBUG - 2019-08-29 21:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 21:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 21:54:24 --> Controller Class Initialized
DEBUG - 2019-08-29 21:54:24 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-29 21:54:24 --> Helper loaded: inflector_helper
INFO - 2019-08-29 21:54:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-29 21:54:24 --> Model "Template_model" initialized
INFO - 2019-08-29 21:54:24 --> Model "Khang_sinh_model" initialized
ERROR - 2019-08-29 21:54:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-08-29 21:54:28 --> Unable to connect to the database
ERROR - 2019-08-29 21:54:28 --> Query error: No connection could be made because the target machine actively refused it.
 - Invalid query: SELECT `ma_khang_sinh`, `ten_khang_sinh`
FROM `khang_sinh`
ERROR - 2019-08-29 21:54:28 --> Severity: error --> Exception: Call to a member function result_array() on bool D:\Programs\Xampp\htdocs\hait\application\models\Khang_sinh_model.php 16
INFO - 2019-08-29 21:54:57 --> Config Class Initialized
INFO - 2019-08-29 21:54:57 --> Hooks Class Initialized
DEBUG - 2019-08-29 21:54:57 --> UTF-8 Support Enabled
INFO - 2019-08-29 21:54:57 --> Utf8 Class Initialized
INFO - 2019-08-29 21:54:57 --> URI Class Initialized
INFO - 2019-08-29 21:54:57 --> Router Class Initialized
INFO - 2019-08-29 21:54:57 --> Output Class Initialized
INFO - 2019-08-29 21:54:57 --> Security Class Initialized
DEBUG - 2019-08-29 21:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-08-29 21:54:57 --> Input Class Initialized
INFO - 2019-08-29 21:54:57 --> Language Class Initialized
INFO - 2019-08-29 21:54:57 --> Loader Class Initialized
INFO - 2019-08-29 21:54:57 --> Helper loaded: url_helper
INFO - 2019-08-29 21:54:57 --> Database Driver Class Initialized
ERROR - 2019-08-29 21:55:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-08-29 21:55:01 --> Unable to connect to the database
DEBUG - 2019-08-29 21:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-08-29 21:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-08-29 21:55:01 --> Controller Class Initialized
DEBUG - 2019-08-29 21:55:01 --> Config file loaded: D:\Programs\Xampp\htdocs\hait\application\config/rest.php
INFO - 2019-08-29 21:55:01 --> Helper loaded: inflector_helper
INFO - 2019-08-29 21:55:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2019-08-29 21:55:01 --> Model "Template_model" initialized
INFO - 2019-08-29 21:55:01 --> Model "Khang_sinh_model" initialized
ERROR - 2019-08-29 21:55:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\Programs\Xampp\htdocs\hait\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-08-29 21:55:05 --> Unable to connect to the database
ERROR - 2019-08-29 21:55:05 --> Query error: No connection could be made because the target machine actively refused it.
 - Invalid query: SELECT `ma_khang_sinh`, `ten_khang_sinh`
FROM `khang_sinh`
ERROR - 2019-08-29 21:55:05 --> Severity: error --> Exception: Call to a member function result_array() on bool D:\Programs\Xampp\htdocs\hait\application\models\Khang_sinh_model.php 16
